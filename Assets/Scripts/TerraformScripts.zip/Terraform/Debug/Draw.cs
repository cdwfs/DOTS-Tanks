﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DebugUtils
{
    public class Draw
    {
        public static void Box(Vector3 min, Vector3 max, Color colour)
        {
            /*            5________6  max
             *      1_____|__2     |
             *      |     |  |     |
             *      |     7__|_____8  
             *  min 3________4 
             */

            Vector3 p1 = new Vector3(min.x, max.y, min.z);
            Vector3 p2 = new Vector3(max.x, max.y, min.z);
            Vector3 p3 = new Vector3(min.x, min.y, min.z);
            Vector3 p4 = new Vector3(max.x, min.y, min.z);

            Vector3 p5 = new Vector3(min.x, max.y, max.z);
            Vector3 p6 = new Vector3(max.x, max.y, max.z);
            Vector3 p7 = new Vector3(min.x, min.y, max.z);
            Vector3 p8 = new Vector3(max.x, min.y, max.z);

            Debug.DrawLine(p1, p3, colour);
            Debug.DrawLine(p1, p2, colour);
            Debug.DrawLine(p2, p4, colour);
            Debug.DrawLine(p4, p3, colour);

            Debug.DrawLine(p5, p6, colour);
            Debug.DrawLine(p6, p8, colour);
            Debug.DrawLine(p8, p7, colour);
            Debug.DrawLine(p7, p5, colour);

            Debug.DrawLine(p1, p5, colour);
            Debug.DrawLine(p2, p6, colour);
            Debug.DrawLine(p4, p8, colour);
            Debug.DrawLine(p3, p7, colour);
        }
    }
}
