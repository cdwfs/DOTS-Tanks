﻿using System;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using Debug = UnityEngine.Debug;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Playdemic
{
    /// <summary>Static configurable debug logging class
    /// <para>Use Dbg.Init(...) before using other calls</para>
    /// <para>Use Dbg.Shutdown() when game client/server is shutting down</para>
    /// <para>If you have a console for output (in-game UI or OS console) then set forwardToConsole to true</para>
    /// <para>------------------------------------------------</para>
    /// <para>Basic API</para>
    /// <para>------------------------------------------------</para>
    /// <para>Dbg.Log(...)</para>
    /// <para>Dbg.LogWarning(...)</para>
    /// <para>Dbg.LogError(...)</para>
    /// <para>Dbg.LogException(...)</para>
    /// <para>Dbg.Assert(...)</para>
    /// <para>Dbg.FatalError(...)</para>
    /// </summary>
    /// <remarks>Most code will be compiled OUT in release build</remarks>
    public static class Dbg
    {

        public static readonly string Line40 = "----------------------------------------";

        private static StreamWriter logFile;
        private static bool initDone;
        private static bool forwardToUnity;
        private static bool forwardToFile;
        internal static bool ForwardToConsole = true; //can also be set from Boot when setting up console
        private static readonly bool logFrameTime = true;

        #region INIT / SHUTDOWN


        /// <summary>
        /// Initialise the Dbg class and its interaction with logging and unity editor
        /// </summary>
        /// <param name="logFilePath">the base folder for the log file</param>
        /// <param name="logBaseName">the base filename for the log file (numbers and .log will be added automatically)</param>
        public static void Init(string logFilePath, string logBaseName)
        {
#if DEVELOPMENT_BUILD || UNITY_EDITOR
            Application.SetStackTraceLogType(LogType.Log, StackTraceLogType.ScriptOnly);
            Application.SetStackTraceLogType(LogType.Warning, StackTraceLogType.Full);
            Application.SetStackTraceLogType(LogType.Error, StackTraceLogType.Full);
            Application.SetStackTraceLogType(LogType.Exception, StackTraceLogType.Full);
            forwardToUnity = Application.isEditor;
            Application.logMessageReceived += ApplicationOnLogMessageReceived;
#else
            // Set stack tracing options - we don't need all the extra info for simple logs and warnings
            Application.SetStackTraceLogType(LogType.Log, StackTraceLogType.None);
            Application.SetStackTraceLogType(LogType.Warning, StackTraceLogType.None);
            Application.SetStackTraceLogType(LogType.Error,StackTraceLogType.Full);
            Application.SetStackTraceLogType(LogType.Exception,StackTraceLogType.Full);
#endif

            // Try creating log file attempt 9 suffixes
            string absoluteFilePath = "";
            for (var i = 0; i < 10; i++)
            {
                var fileName = logBaseName + (i == 0 ? "" : "_" + i) + ".log";
                try
                {
                    string relativeFilePath = Path.Combine(logFilePath, fileName);
                    absoluteFilePath = Path.GetFullPath(relativeFilePath);
                    logFile = File.CreateText(relativeFilePath);
                    logFile.AutoFlush = true;
                    forwardToFile = true;
                    break;
                }
                catch
                {
                    logFile = null;
                    forwardToFile = false;
                    LogInternal($"[DBG] File logging disabled due to error creating files in [{logFilePath}]");
                }
            }

            if (forwardToFile)
            {
                LogInternal($"[DBG] Logging to {absoluteFilePath}");
            }

            initDone = true;
            LogInternal("[DBG] Initialised");
        }

        public static void Shutdown()
        {
#if DEVELOPMENT_BUILD || UNITY_EDITOR
            Application.logMessageReceived -= ApplicationOnLogMessageReceived;
#endif
            LogInternal("[DBG] SHUTDOWN");

            logFile?.Close();
            logFile = null;
        }

        #endregion

        #region LOGGING

        /// <summary>
        /// This function will be called by Unity when in the Editor and calling Debug.Logxxx
        /// </summary>
        /// <param name="message"></param>
        /// <param name="stacktrace"></param>
        /// <param name="logtype"></param>
        private static void ApplicationOnLogMessageReceived(string message, string stacktrace, LogType logtype)
        {
            LogToConsoleAndFile(message);
        }

        [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
        public static void Log(string msg)
        {
            LogInternal(msg);
        }

        //[Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
        public static void LogError(string s)
        {
            LogInternal(s, LogType.Error);
        }

        [Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
        public static void LogWarning(string s)
        {
            LogInternal(s, LogType.Warning);
        }

        //[Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
        public static void LogException(string s)
        {
            LogInternal(s, LogType.Exception);
        }

        //[Conditional("UNITY_EDITOR"), Conditional("DEVELOPMENT_BUILD")]
        private static void LogInternal(string msg, LogType logType = LogType.Log)
        {
            // disabled check below so that the local Init() function can call LogInternal when setting up
            //if (!initDone) return;

            switch (logType)
            {
                case LogType.Error:
                    msg = "[ERROR] " + msg;
                    break;
                case LogType.Warning:
                    msg = "[WARNING] " + msg;
                    break;
                case LogType.Assert:
                    msg = "[ASSERT] " + msg;
                    break;
                case LogType.Exception:
                    msg = "[EXCEPTION] " + msg;
                    break;
                default:
                    break;
            }

            // Add Timestamp
            if (logFrameTime)
            {
                msg = $"{Time.frameCount:D5} :: {msg}"; //OPT: Boxing
            }

            // Log to unity
            if (forwardToUnity)
            {
                switch (logType)
                {
                    case LogType.Log:
                        Debug.Log(msg);
                        break;
                    case LogType.Error:
                        Debug.LogError(msg);
                        break;
                    case LogType.Warning:
                        Debug.LogWarning(msg);
                        break;
                    case LogType.Assert:
                        Debug.LogAssertion(msg);
                        break;
                    case LogType.Exception:
                        Debug.LogException(new ApplicationException(msg));
                        break;
                    default:
                        break;
                }
            }

            // Only log to the console and file if we are outside the editor
            // otherwise we'll get duplicate lines due to the editor forwarding back to use via ApplicationOnLogMessageReceived
            if (!forwardToUnity) LogToConsoleAndFile(msg);
        }

        private static void LogToConsoleAndFile(string s)
        {
            if (ForwardToConsole)
            {
                Console.WriteLine(s);
            }

            if (forwardToFile)
            {
                logFile.WriteLine(s);
            }
        }

        /// Log Fatal Error - will not be compiled out during release build
        public static void FatalError(string msg)
        {
            Debug.LogError($"[FATAL] : {msg}\r\n{GetBasicStackTraceString()}");
#if UNITY_EDITOR
            EditorApplication.ExitPlaymode();
#else
            //TODO: this will still run to the end of the "PlayerLoop" - we could use OS process API to kill it
            Application.Quit();
#endif
        }

        #endregion

        #region ASSERTIONS

        /// <summary>
        /// Returns a string made from the calling method's caller and its filename and line number
        /// </summary>
        private static string GetBasicStackTraceString()
        {
            var stackFrame = new StackFrame(2, true);
            var method = stackFrame.GetMethod();
            var fileNameWithoutExtension = Path.GetFileNameWithoutExtension(stackFrame.GetFileName());
            var fileLineNumber = stackFrame.GetFileLineNumber();
            var s = $"{method.Name} [{fileNameWithoutExtension}] ({fileLineNumber.ToString()})";
            return s;
        }


        /// <summary>
        /// Basic assert without a specific message (will dump caller stack trace)
        /// </summary>
        /// <param name="condition">Condition to test</param>
        public static void Assert(bool condition)
        {
            if (condition) return;

            var s = GetBasicStackTraceString();
            throw new ApplicationException("[ASSERT] : " + s);
        }

        /// <summary>
        /// Basic assert with a custom message
        /// </summary>
        /// <param name="condition">Condition to test</param>
        /// <param name="msg">The custom message to print when condition is false</param>
        public static void Assert(bool condition, string msg)
        {
            if (condition) return;
            throw new ApplicationException("[ASSERT] : " + msg);
        }

        public static void Assert<T>(bool condition, string format, T arg1)
        {
            if (condition) return;
            throw new ApplicationException("[ASSERT] : " + string.Format(format, arg1));
        }

        public static void Assert<T1, T2>(bool condition, string format, T1 arg1, T2 arg2)
        {
            if (condition) return;
            throw new ApplicationException("[ASSERT] : " + string.Format(format, arg1, arg2));
        }

        public static void Assert<T1, T2, T3>(bool condition, string format, T1 arg1, T2 arg2, T3 arg3)
        {
            if (condition) return;
            throw new ApplicationException("[ASSERT] : " + string.Format(format, arg1, arg2, arg3));
        }

        public static void Assert<T1, T2, T3, T4>(bool condition, string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4)
        {
            if (condition) return;
            throw new ApplicationException("[ASSERT] : " + string.Format(format, arg1, arg2, arg3, arg4));
        }

        public static void Assert<T1, T2, T3, T4, T5>(bool condition, string format, T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5)
        {
            if (condition) return;
            throw new ApplicationException("[ASSERT] : " + string.Format(format, arg1, arg2, arg3, arg4, arg5));
        }

        #endregion
    }
}