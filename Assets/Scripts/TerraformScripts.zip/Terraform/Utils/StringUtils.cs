﻿using System;

namespace Playdemic
{
    /// <summary>
    /// General utilities for String
    /// </summary>
    public static class StringUtils
    {
        internal static string[] CommandLineArgumentsCache = Environment.GetCommandLineArgs();

        ///<summary>Gets the value of a param on the command line if using the format
        ///<para>exename server=192.168.1.1</para>
        ///<para>if using command switches/flags (such as -batchmode) use GetCommandLineSwitchValue or IsCommandLineSwitchPresent</para>
        ///</summary>
        public static string GetParamEqualsValue(string op)
        {
            //var args = System.Environment.GetCommandLineArgs();
            foreach (string argument in CommandLineArgumentsCache)
            {
                //Convert both sides to lower for comparison
                string argLower = argument.ToLower();
                string opLower = op.ToLower();

                //if this arg is not the requested one then continue the loop
                if (!argLower.StartsWithFast(opLower)) continue;

                //validate the delimiter
                int delimPos = op.Length;
                char delim = argLower[delimPos];
                //delimiter should be either = or :
                bool delimOk = (delim == '=');
                //bad delimiter, inform user of correct method and return an empty
                if (!delimOk)
                {
                    Dbg.LogError($"Error: invalid delimiter in param {op}\r\nUse an equal sign to separate op from value");
                    return "";
                }

                //get right hand side of delim and return as the value requested
                string right = argument.Substring(delimPos + 1);
                return right;
            }
            //No value found for the param specified
            return "";
        }

        ///<summary>Returns true if the requested flag is part of the command line
        ///<para>Example: <code>if (IsCommandLineSwitchPresent("-batchmode") {}</code></para></summary>
        ///<remarks>For switches with params/values (such as -map [mapname]) use GetCommandLineSwitchValue</remarks>
        public static bool IsCommandLineSwitchPresent(string flagName)
        {
            return Array.IndexOf(CommandLineArgumentsCache, flagName) >= 0;
        }

        ///<summary>Returns the value of a command line switch
        ///<para>i.e. if args = exename -flag value</para>
        ///<para>this will return "value" if you specify "-flag"</para>
        ///</summary>
        public static string GetCommandLineSwitchValue(string paramName)
        {
            int paramNameIndex = Array.IndexOf(CommandLineArgumentsCache, paramName);
            if (paramNameIndex < 0) return "";
            int paramValueIndex = paramNameIndex + 1;
            return paramValueIndex > (CommandLineArgumentsCache.Length - 1) ? "" : CommandLineArgumentsCache[paramNameIndex + 1];
        }

        ///<summary>Get a command line value as an integer for a switch type param (i.e. -number 123 will return 123)
        /// <para>Will return 0 if the integer is invalid or missing</para></summary>
        public static int GetCommandLineSwitchIntegerValue(string paramName)
        {
            string s = GetCommandLineSwitchValue(paramName);
            if (s == "") return 0;
            int.TryParse(s, out int i);
            return i;
        }


        /// <summary>Faster version of string.Endswith (10 x faster than ordinal comparison)
        /// <para>Usage: StringUtils.EndsWith("Hello World", "World") -- will return true</para>
        /// </summary>
        public static bool EndsWith(string a, string b)
        {
            int aLength = a.Length;
            int bLength = b.Length;

            int ap = aLength - 1;
            int bp = bLength - 1;

            while (ap >= 0 && bp >= 0 && a[ap] == b[bp])
            {
                ap--;
                bp--;
            }
            return (bp < 0 && aLength >= bLength) || (ap < 0 && bLength >= aLength);
        }


        /// <summary>Extension method - EndsWith but much faster</summary>
        public static bool EndsWithFast(this string a, string b)
        {
            int aLength = a.Length;
            int bLength = b.Length;

            int ap = aLength - 1;
            int bp = bLength - 1;

            while (ap >= 0 && bp >= 0 && a[ap] == b[bp])
            {
                ap--;
                bp--;
            }
            return (bp < 0 && aLength >= bLength) || (ap < 0 && bLength >= aLength);
        }


        /// <summary>Faster version of string.StartsWith - much faster
        /// <para>Usage: StringUtils.StartsWith("Hello World", "Hello") -- will return true</para></summary>
        public static bool StartsWith(string a, string b)
        {
            int aLength = a.Length;
            int bLength = b.Length;
            int ap = 0;
            int bp = 0;

            while (ap < aLength && bp < bLength && a[ap] == b[bp])
            {
                ap++;
                bp++;
            }
            return (bp == bLength && aLength >= bLength) || (ap == aLength && bLength >= aLength);
        }

        /// <summary>Extension method for faster version of string.StartsWith(string)</summary>
        public static bool StartsWithFast(this string a, string b)
        {
            int aLength = a.Length;
            int bLength = b.Length;
            int ap = 0;
            int bp = 0;

            while (ap < aLength && bp < bLength && a[ap] == b[bp])
            {
                ap++;
                bp++;
            }
            return (bp == bLength && aLength >= bLength) || (ap == aLength && bLength >= aLength);
        }

        /// <summary>Convert an ascii string to lower case</summary>
        public static string ToLowerAscii(string src)
        {
            int srcLen = src.Length;
            char[] newChars = new char[srcLen]; //OPT: Shared memory array?

            for (int i = 0; i < srcLen; i++)
            {
                newChars[i] = ToLowerAscii(src[i]);
            }

            return new string(newChars);
        }

        /// <summary>convert an ascii char to lower case, if not ascii then send back unharmed</summary>
        private static char ToUpperAscii(char c)
        {
            if ('a' <= c && c <= 'z')
            {
                c = (char)(c & ~0x20);
            }
            return c;
        }

        /// <summary>convert an ascii char to upper case, if not ascii the send back unharmed</summary>
        private static char ToLowerAscii(char c)
        {
            if ('A' <= c && c <= 'Z')
            {
                c = (char)(c | 0x20);
            }
            return c;
        }

        /// <summary>return true if char is ascii, otherwise return false</summary>
        private static bool IsAscii(Char c)
        {
            return c < 0x80;
        }


        /// <summary>
        /// Returns the remainder of the <paramref name="sourceString"/> after the last <paramref name="subString"/> is found
        /// <para>Example: "Hello Hello World".AfterLast("Hello") will return " World" (notice the space before W is still there)</para>
        /// </summary>
        /// <param name="sourceString">The source string</param>
        /// <param name="subString">The sub-string to search for</param>
        public static string AfterLast(this string sourceString, string subString)
        {
            int idx = sourceString.LastIndexOf(subString, StringComparison.Ordinal);
            return idx < 0 ? "" : sourceString.Substring(idx + subString.Length);
        }

        /// <summary>
        /// Returns the portion of <paramref name="sourceString"/> before the last occurrence of <paramref name="subString"/>
        /// <para>Example: "Hello Hello World".BeforeLast("Hello") will return "Hello " (notice the space after Hello is still there)</para>
        /// </summary>
        /// <param name="sourceString">The source string</param>
        /// <param name="subString">The sub-string to searh for</param>
        public static string BeforeLast(this string sourceString, string subString)
        {
            int idx = sourceString.LastIndexOf(subString, StringComparison.Ordinal);
            return idx < 0 ? "" : sourceString.Substring(0, idx);
        }

        /// <summary>
        /// Returns the remainder of sourceString after the first occurrence of subString
        /// </summary>
        /// <param name="sourceString"></param>
        /// <param name="subString"></param>
        public static string AfterFirst(this string sourceString, string subString)
        {
            int idx = sourceString.IndexOf(subString, StringComparison.Ordinal);
            return idx < 0 ? "" : sourceString.Substring(idx + subString.Length);
        }

        public static string BeforeFirst(this string str, string sub)
        {
            int idx = str.IndexOf(sub, StringComparison.Ordinal);
            return idx < 0 ? "" : str.Substring(0, idx);
        }

        public static int PrefixMatch(this string str, string prefix)
        {
            int l = 0, slen = str.Length, plen = prefix.Length;
            while (l < slen && l < plen)
            {
                if (str[l] != prefix[l])
                    break;
                l++;
            }
            return l;
        }
    }
}