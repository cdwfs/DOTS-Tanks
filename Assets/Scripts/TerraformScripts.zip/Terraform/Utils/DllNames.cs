﻿using System;

public class DllNames
{
#if UNITY_IPHONE && !UNITY_EDITOR
    public const String Nu2ApiComponentsDllName = "__Internal";
#else
    public const String Nu2ApiComponentsDllName = "Nu2ApiComponentsPlugin";
#endif
}