﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class HashUtils
{
    public static UInt32 CalcZOrder(UInt16 xPos, UInt16 yPos)
    {
        UInt32[] MASKS = new UInt32[] { 0x55555555, 0x33333333, 0x0F0F0F0F, 0x00FF00FF };
        Int32[] SHIFTS = new Int32[] { 1, 2, 4, 8 };

        UInt32 x = xPos;  // Interleave lower 16 bits of x and y, so the bits of x
        UInt32 y = yPos;  // are in the even positions and bits from y in the odd;

        x = (x | (x << SHIFTS[3])) & MASKS[3];
        x = (x | (x << SHIFTS[2])) & MASKS[2];
        x = (x | (x << SHIFTS[1])) & MASKS[1];
        x = (x | (x << SHIFTS[0])) & MASKS[0];

        y = (y | (y << SHIFTS[3])) & MASKS[3];
        y = (y | (y << SHIFTS[2])) & MASKS[2];
        y = (y | (y << SHIFTS[1])) & MASKS[1];
        y = (y | (y << SHIFTS[0])) & MASKS[0];

        UInt32 result = x | (y << 1);
        return result;
    }
}
