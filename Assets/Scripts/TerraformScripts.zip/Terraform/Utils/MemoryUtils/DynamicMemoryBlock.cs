﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using Unity.Collections;

namespace MemoryUtils
{
    /// <summary>
    /// Will create new blocks of memory with the use of MemoryBlock when data that is requested is not available. 
    /// </summary>
    public class DynMemoryBlock<T> where T : struct
    {
        public readonly int dataPerBlock;

        private LinkedList<MemoryBlock<T>> blocks;

        public int blocksCreated
        {
            get
            {
                return blocks.Count;
            }
        }

        public DynMemoryBlock(int dataPerBlock)
        {
            this.blocks = new LinkedList<MemoryBlock<T>>();

            this.dataPerBlock = dataPerBlock;
            AddNewBlock();
        }

        private LinkedListNode<MemoryBlock<T>> AddNewBlock()
        {
            return blocks.AddLast(new MemoryBlock<T>(dataPerBlock));
        }

        public bool PushData(ref NativeSlice<T> slice)
        {
            for (LinkedListNode<MemoryBlock<T>> node = blocks.First; node != null; node = node.Next)
            {
                if (node.Value.PushData(ref slice))
                {
                    return true;
                }
            }

            return false;
        }

        public void GetData(in int size, out NativeSlice<T> slice)
        {
            for (LinkedListNode<MemoryBlock<T>> node = blocks.First; node != null; node = node.Next)
            {
                if (node.Value.GetData(size, out slice))
                {
                    return;
                }
            }

            // no space found. Create new block.
            AddNewBlock().Value.GetData(size, out slice);
        }
    }
}