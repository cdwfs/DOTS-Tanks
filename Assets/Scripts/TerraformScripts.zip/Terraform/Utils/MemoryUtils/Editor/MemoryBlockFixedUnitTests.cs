﻿using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using MemoryUtils;
using Unity.Collections;

namespace Tests
{
    namespace MemoryBlockFixedUnitTests
    {
        public class Tests
        {
            [Test]
            public void grabbingAndReturningSingleData()
            {
                const int TestSize = 32;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize);
              
                Assert.AreEqual(block.spaceAvailable, TestSize, "no data grabbed");

                NativeSlice<Int32> slice;
                block.GetData(out slice);
              
                Assert.AreEqual(block.spaceAvailable, TestSize - 1, "Grabbed 1 piece of data");
                Assert.AreNotEqual(0, slice.Length, "memory not freed");

                block.PushData(ref slice);
                
                Assert.AreEqual(block.spaceAvailable, TestSize, "data returned");
            }

            [Test]
            public void grabbingAndReturningAllData()
            {
                const int TestSize = 32;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize);

                Stack<NativeSlice<Int32>> slices = new Stack<NativeSlice<Int32>>(TestSize);
              
                Assert.AreEqual(block.spaceAvailable, TestSize, "no data grabbed");
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    slices.Push(slice);
                  
                    Assert.AreEqual(block.spaceAvailable, TestSize - slices.Count, "data grabbed : " + slices.Count);

                }

                while(slices.Count > 0)
                {
                    NativeSlice<Int32> slice = slices.Pop();
                    block.PushData(ref slice);

                    Assert.AreEqual(block.spaceAvailable, TestSize - slices.Count, "data freed : " + (TestSize - slices.Count));
                }
              
                Assert.AreEqual(block.spaceAvailable, TestSize, "all data freed");
            }

            [Test]
            public void WritingToAllData()
            {
                const int TestSize = 32;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize);


                List<NativeSlice<Int32>> slices = new List<NativeSlice<Int32>>(TestSize);

                // grab data
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    slices.Add(slice);
                }

                // write data
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    slice[0] = i;
                }

                // test data
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    Assert.AreEqual(slice[0], i, "writen data at index : " + i);
                }

                // free data
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    block.PushData(ref slice);
                }

                Assert.AreEqual(block.spaceAvailable, TestSize, "all data freed");
            }

            [Test]
            public void grabbingAndReturningSingleDataWithStride()
            {
                const int TestSize = 32;
                const int Stride = 16;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize, Stride);

                Assert.AreEqual(block.spaceAvailable, TestSize, "no data grabbed");

                NativeSlice<Int32> slice;
                block.GetData(out slice);

                Assert.AreEqual(block.spaceAvailable, TestSize - 1, "Grabbed 1 piece of data");
                Assert.AreEqual(slice.Length, Stride, "testing stride length of slice");

                block.PushData(ref slice);

                Assert.AreEqual(block.spaceAvailable, TestSize, "data returned");
            }

            [Test]
            public void grabbingAndReturningAllDataWithStride()
            {
                const int TestSize = 32;
                const int Stride = 16;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize, Stride);

                Stack<NativeSlice<Int32>> slices = new Stack<NativeSlice<Int32>>(TestSize);

                Assert.AreEqual(block.spaceAvailable, TestSize, "no data grabbed");
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    slices.Push(slice);

                    Assert.AreEqual(block.spaceAvailable, TestSize - slices.Count, "data grabbed : " + slices.Count);
                }

                while (slices.Count > 0)
                {
                    NativeSlice<Int32> slice = slices.Pop();
                    block.PushData(ref slice);

                    Assert.AreEqual(block.spaceAvailable, TestSize - slices.Count, "data freed : " + (TestSize - slices.Count));
                }

                Assert.AreEqual(block.spaceAvailable, TestSize, "all data freed");
            }

            [Test]
            public void grabbingAndReturningRandomDataWithStride()
            {
                const int TestSize = 32;
                const int Stride = 16;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize, Stride);

                List<NativeSlice<Int32>> slices = new List<NativeSlice<Int32>>(TestSize);

                Assert.AreEqual(block.spaceAvailable, TestSize, "no data grabbed");
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    slices.Add(slice);

                    Assert.AreEqual(block.spaceAvailable, TestSize - slices.Count, "data grabbed : " + slices.Count);
                }

                // free random data
                int[] randomIndexes = new int[] { 24, 8, 3, 14, 29 };
                int dataFreed = 0;
                for (int i = 0; i < randomIndexes.Length; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    block.PushData(ref slice);
                    ++dataFreed;
                    Assert.AreEqual(block.spaceAvailable, dataFreed, "random data freed");
                }
              
                // grab new data. 
                for (int i = 0; i < randomIndexes.Length; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    slices[randomIndexes[i]] = slice;
                    --dataFreed;
                    Assert.AreEqual(block.spaceAvailable, dataFreed, "new data grabbed");
                }

                // free all data
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    block.PushData(ref slice);
                    ++dataFreed;
                    Assert.AreEqual(block.spaceAvailable, dataFreed, "data freed : " + (TestSize - slices.Count));
                }

                Assert.AreEqual(block.spaceAvailable, TestSize, "all data freed");
            }

            [Test]
            public void WritingToSingleDataWithStride()
            {
                int dataCounter = 0;
                const int TestSize = 32;
                const int Stride = 16;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize, Stride);

                NativeSlice<Int32> slice;
                block.GetData(out slice);
         
                // write data
                for (int i = 0; i < Stride; ++i)
                {
                    slice[i] = ++dataCounter;
                }
         
                dataCounter = 0;
         
                // test data
                for (int i = 0; i < Stride; ++i)
                {
                    Assert.AreEqual(slice[i], ++dataCounter, "testing piece of stride data at index : " + i);
                }
                
                block.PushData(ref slice);
         
                Assert.AreEqual(block.spaceAvailable, TestSize, "data returned");
            }
         
            [Test]
            public void WritingToAllDataWithStride()
            {
                int dataCounter = 0;
         
                const int TestSize = 32;
                const int Stride = 16;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize, Stride);
         
                List<NativeSlice<Int32>> slices = new List<NativeSlice<Int32>>(TestSize);
         
                // grab data
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    slices.Add(slice);
                }
         
                // write data
                for (int i = 0; i < TestSize; ++i)
                {
                    for (int s = 0; s < Stride; ++s)
                    {
                        NativeSlice<Int32> slice = slices[i];
                        slice[s] = ++dataCounter;
                    }
                }
         
                dataCounter = 0;
            
                // test data
                for (int i = 0; i < TestSize; ++i)
                {
                    for (int s = 0; s < Stride; ++s)
                    {
                        NativeSlice<Int32> slice = slices[i];
                        Assert.AreEqual(slice[s], ++dataCounter, "testing piece of stride data at index : " + i);
                    }
                }
         
                // free data
                for (int i = 0; i < TestSize; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    block.PushData(ref slice);
                }
         
                Assert.AreEqual(block.spaceAvailable, TestSize, "all data freed");
            }
         
            [Test]
            public void AllocatingMillionSizeMemoryBLockWithStride64()
            {
                const int TestSize = 1000000;
                const int Stride = 64;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize, Stride);
         
                Assert.AreEqual(block.spaceAvailable, TestSize, "data allocated");
            }
         
            [Test]
            public void AllocatingEmptyMemoryBlock()
            {
                const int TestSize = 0;
                const int Stride = 0;
                MemoryBlockFixed<Int32> block = new MemoryBlockFixed<Int32>(TestSize, Stride);
         
                Assert.AreEqual(block.spaceAvailable, TestSize, "block created");

                NativeSlice<Int32> slice;

                Assert.IsFalse(block.GetData(out slice), "getting data from size 0 block");
            }
         
            [Test]
            public void AllocatingDynamicMemoryBlock()
            {
                const int TestSize = 32;
                const int Stride = 16;
                DynMemoryBlockFixed<Int32> block = new DynMemoryBlockFixed<int>(TestSize, Stride);
            
                Assert.AreEqual(block.spaceAvailable, TestSize, "block created");
            }
         
            [Test]
            public void ForceDynamicMemoryBlockToGrow()
            {
                const int TestSize = 100;
                const int Stride = 32;
                const int blocksToForce = 100;
                const int testdataToCreate = (blocksToForce * TestSize);
                DynMemoryBlockFixed<Int32> block = new DynMemoryBlockFixed<int>(TestSize, Stride);

                Stack<NativeSlice<Int32>> slices = new Stack<NativeSlice<Int32>>();
         
                for (int i = 0; i < testdataToCreate; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    slices.Push(slice);
                }
         
                Assert.AreEqual(blocksToForce, block.blocksCreated, "testing if blocks have been created");
         
                while (slices.Count > 0)
                {
                    NativeSlice<Int32> slice = slices.Pop();
                    block.PushData(ref slice);

                    Assert.AreEqual(block.spaceAvailable, testdataToCreate - slices.Count, "data freed");
                }
         
                Assert.AreEqual(block.spaceAvailable, testdataToCreate, "all data freed");
            }
         
            [Test]
            public void WriteAndReadToDynamicMemoryBlock()
            {
                int dataPool = 0;
                const int TestSize = 100;
                const int Stride = 32;
                const int blocksToForce = 10;
                const int testdataToCreate = (blocksToForce * TestSize);
                DynMemoryBlockFixed<Int32> block = new DynMemoryBlockFixed<int>(TestSize, Stride);

                List<NativeSlice<Int32>> slices = new List<NativeSlice<Int32>>();
         
                // writing data.
                for (int i = 0; i < testdataToCreate; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);

                    for (int s = 0; s < Stride; ++s)
                    {
                        slice[s] = ++dataPool;
                    }
                    slices.Add(slice);
                }
         
                // reset data pool.
                dataPool = 0;
         
                // testing data. 
                for (int i = 0; i < slices.Count; ++i)
                {
                    for (int s = 0; s < Stride; ++s)
                    {
                        NativeSlice<Int32> slice = slices[i];
                        Assert.AreEqual(++dataPool, slice[s], "testing data is correct");
                    }
                }
         
                for (int i = 0; i < slices.Count; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    block.PushData(ref slice);
                }
         
                Assert.AreEqual(block.spaceAvailable, testdataToCreate, "all data freed");
            }
         
            [Test]
            public void WriteAndReadToDynamicMemoryBlockRandomly()
            {
                int dataPool = 0;
                const int TestSize = 100;
                const int Stride = 32;
                const int blocksToForce = 10;
                const int testdataToCreate = (blocksToForce * TestSize);
                DynMemoryBlockFixed<Int32> block = new DynMemoryBlockFixed<int>(TestSize, Stride);

                List<NativeSlice<Int32>> slices = new List<NativeSlice<Int32>>();
         
                // writing data.
                for (int i = 0; i < testdataToCreate; ++i)
                {
                    NativeSlice<Int32> slice;
                    block.GetData(out slice);
                    for (int s = 0; s < Stride; ++s)
                    {
                        slice[s] = ++dataPool;
                    }
                    slices.Add(slice);
                }
         
                //free random indexes
                int[] randomIndexes = new int[] { 34, 65, 101, 265, 301, 366, 388, 394, 421, 430 }; // assuming 100s of data instances are created.
            
                Int32[] randomIndexData = new Int32[randomIndexes.Length * Stride];
         
                // we store the random data because once we free the data, when we grab them back the data should stay the same. 
                for (int i = 0; i < randomIndexes.Length; ++i)
                {
                    for (int s = 0; s < Stride; ++s)
                    {
                        int index = (i * Stride) + s;
                        randomIndexData[index] = i + s + dataPool;
                        
                        NativeSlice<Int32> slice = slices[randomIndexes[i]];
                        slice[s] = randomIndexData[index];
                    }
                }
         
                // regrab and test data.
                for (int i = 0; i < randomIndexes.Length; ++i)
                {
                    for (int s = 0; s < Stride; ++s)
                    {
                        int index = (i * Stride) + s;
                        NativeSlice<Int32> slice = slices[randomIndexes[i]];
                        Assert.AreEqual(randomIndexData[index], slice[s], "testing if data is the same");
                    }
                }
         
                for (int i = 0; i < slices.Count; ++i)
                {
                    NativeSlice<Int32> slice = slices[i];
                    block.PushData(ref slice);
                }
         
                Assert.AreEqual(block.spaceAvailable, testdataToCreate, "all data freed");
            }
        }
    }
}
