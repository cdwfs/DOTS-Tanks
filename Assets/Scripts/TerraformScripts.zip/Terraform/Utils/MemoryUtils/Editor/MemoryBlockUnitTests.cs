﻿using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using MemoryUtils;
using Unity.Collections;

namespace Tests
{
    namespace MemoryBlockUnitTests
    {
        public class Tests
        {
            [Test]
            public void CreateMemoryBlock()
            {
                const int size = 32;
                MemoryBlock<int> block = new MemoryBlock<int>(size);

                int largestSpace = block.largestSpace;
                int count = block.count;
                Assert.AreEqual(largestSpace, size, "largest space on new empty block is not equal to overall memory block size");
                Assert.AreEqual(count, size, "memory block count is not equal to size we passed to memory block constrructor");
            }

            [Test]
            public void GetDataFromMemoryBlockAndReturnIt()
            {
                const int size = 32;
                MemoryBlock<int> block = new MemoryBlock<int>(size);

                // grabbing data
                NativeSlice<int> s0;
                block.GetData(6, out s0);
                Assert.AreEqual(block.space, size - 6, "largest space avaible in memory block is wrong after pulling data from the block");

                NativeSlice<int> s1;
                block.GetData(12, out s1);
                Assert.AreEqual(block.space, size - 6 - 12, "largest space avaible in memory block is wrong after pulling data from the block");

                NativeSlice<int> s2;
                block.GetData(1, out s2);
                Assert.AreEqual(block.space, size - 6 - 12 - 1, "largest space avaible in memory block is wrong after pulling data from the block");

                // get all of remaining data
                NativeSlice<int> s3;
                block.GetData(13, out s3);
                Assert.AreEqual(block.space, 0, "largest space avaible in memory block is wrong after pulling data from the block");
                Assert.AreEqual(block.largestSpace, 0, "largest space avaible in memory block is wrong after pulling data from the block");

                // pushing data back
                block.PushData(ref s0);
                Assert.AreEqual(block.space, size - 12 - 1 - 13, "failed to put data back");

                block.PushData(ref s1);
                Assert.AreEqual(block.space, size - 1 - 13, "failed to put data back");

                block.PushData(ref s2);
                Assert.AreEqual(block.space, size - 13, "failed to put data back");

                block.PushData(ref s3);
                Assert.AreEqual(block.space, size, "failed to put data back");
            }

            [Test]
            public void GetDataFromMemoryBlockAndReturnItNotInOrder()
            {
                const int size = 32;
                MemoryBlock<int> block = new MemoryBlock<int>(size);

                // grabbing data
                NativeSlice<int> s0;
                block.GetData(6, out s0);
                Assert.AreEqual(block.space, size - 6, "largest space avaible in memory block is wrong after pulling data from the block");

                NativeSlice<int> s1;
                block.GetData(12, out s1);
                Assert.AreEqual(block.space, size - 6 - 12, "largest space avaible in memory block is wrong after pulling data from the block");

                NativeSlice<int> s2;
                block.GetData(1, out s2);
                Assert.AreEqual(block.space, size - 6 - 12 - 1, "largest space avaible in memory block is wrong after pulling data from the block");

                // get all of remaining data
                NativeSlice<int> s3;
                block.GetData(13, out s3);
                Assert.AreEqual(block.space, 0, "largest space avaible in memory block is wrong after pulling data from the block");
                Assert.AreEqual(block.largestSpace, 0, "largest space avaible in memory block is wrong after pulling data from the block");

                // pushing data back
                block.PushData(ref s1);
                Assert.AreEqual(block.space, size - 6 - 1 - 13, "failed to put data back");

                block.PushData(ref s0);
                Assert.AreEqual(block.space, size - 1 - 13, "failed to put data back");

                block.PushData(ref s3);
                Assert.AreEqual(block.space, size - 1, "failed to put data back");

                block.PushData(ref s2);
                Assert.AreEqual(block.space, size, "failed to put data back");
            }

            [Test]
            public void TryGetDataFromMemoryBlockLargerThanWhatIsAvailable()
            {
                const int size = 32;
                MemoryBlock<int> block = new MemoryBlock<int>(size);

                NativeSlice<int> s0;
                Assert.False(block.GetData(100, out s0), "managed to pull data larger than what was aviable in the block");
                Assert.AreEqual(s0, MemoryBlock<int>.NULL, "slice is not equal to NULL");
            }

            [Test]
            public void CreateDynamicMemoryBlock()
            {
                const int size = 32;
                DynMemoryBlock<int> block = new DynMemoryBlock<int>(size);

                Assert.AreEqual(block.blocksCreated, 1, "memory block not created");
            }

            [Test]
            public void MakeDynamicMemoryBlockGrow()
            {
                const int size = 32;
                DynMemoryBlock<int> block = new DynMemoryBlock<int>(size);

                NativeSlice<int> s0;
                block.GetData(28, out s0);

                NativeSlice<int> s1;
                block.GetData(28, out s1);

                NativeSlice<int> s2;
                block.GetData(28, out s2);

                Assert.AreEqual(block.blocksCreated, 3, "data blocks failed to be created");

                // grab data that should now not invoke new memory to be made

                NativeSlice<int> s3;
                block.GetData(4, out s3);

                NativeSlice<int> s4;
                block.GetData(4, out s4);

                NativeSlice<int> s5;
                block.GetData(4, out s5);

                Assert.AreEqual(block.blocksCreated, 3, "data blocks were created when not needed");

                // 1 piece of data should force a new block to be made
                NativeSlice<int> s6;
                block.GetData(1, out s6);

                Assert.AreEqual(block.blocksCreated, 4, "data blocks failed to be created");
            }

            [Test]
            public void GrabDataInDynamicBlockAndGiveItBack()
            {
                const int size = 32;
                DynMemoryBlock<int> block = new DynMemoryBlock<int>(size);

                NativeSlice<int> s0;
                block.GetData(28, out s0);

                NativeSlice<int> s1;
                block.GetData(28, out s1);

                NativeSlice<int> s2;
                block.GetData(28, out s2);

                Assert.AreEqual(block.blocksCreated, 3, "data blocks failed to be created");

                // return data
                Assert.True(block.PushData(ref s0), "failed to give data back");
                Assert.True(block.PushData(ref s1), "failed to give data back");
                Assert.True(block.PushData(ref s2), "failed to give data back");

                Assert.AreEqual(s0, MemoryBlock<int>.NULL, "slice is not equal to NULL");
                Assert.AreEqual(s1, MemoryBlock<int>.NULL, "slice is not equal to NULL");
                Assert.AreEqual(s2, MemoryBlock<int>.NULL, "slice is not equal to NULL");

                //take data back, no new blocks should be created
                block.GetData(28, out s0);
                block.GetData(28, out s1);
                block.GetData(28, out s2);

                Assert.AreEqual(block.blocksCreated, 3, "data blocks failed to be created");
            }

            [Test]
            public void GrabDataFromOneMemoryBlockAndTryToGiveItToAnother()
            {
                const int size = 32;
                DynMemoryBlock<int> block1 = new DynMemoryBlock<int>(size);
                DynMemoryBlock<int> block2 = new DynMemoryBlock<int>(size);

                NativeSlice<int> s0;
                block1.GetData(28, out s0);

                Assert.False(block2.PushData(ref s0), "managed to give data back to wrong block");
                Assert.True(block1.PushData(ref s0), "failed to give data back");
            }
        }
    }
}