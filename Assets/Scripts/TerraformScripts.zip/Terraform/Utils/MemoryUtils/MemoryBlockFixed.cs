﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using Unity.Collections;
using UnityEngine;
using Unity.Collections.LowLevel.Unsafe;

namespace MemoryUtils
{
    /// <summary>
    /// similar to the MemoryBlock type, except this memory block can only provide data handles to a fixed slice size. This makes it less flexable than the MemoryBlock type, but is more performance friendly.
    /// </summary>
    public unsafe class MemoryBlockFixed<T> where T : struct
    {
        public static readonly NativeSlice<T> NULL = new NativeSlice<T>();

        public readonly int count;      // how many instances there are
        public readonly int stride;     // how many elements consist per instance
        public readonly int size;       // the number of elements in the memory block

        private NativeArray<T> block;
        private Stack<NativeSlice<T>> slices;
        private List<NativeSlice<T>> checkedOutSlices;

        public int spaceAvailable { get { return slices.Count; } set { } }

        public MemoryBlockFixed(int count, int stride = 1)
        {
            int size = count * stride;
            this.block = new NativeArray<T>(size, Allocator.Persistent);
            this.slices = new Stack<NativeSlice<T>>(count);
            this.checkedOutSlices = new List<NativeSlice<T>>(count);

            this.size = size;
            this.count = count;
            this.stride = stride;

            // create all slices of memory.
            for (int i = 0; i < size; i += stride)
            {
                this.slices.Push(new NativeSlice<T>(this.block, i, stride));
            }
        }

        ~MemoryBlockFixed()
        {
            block.Dispose();
        }

        public bool GetData(out NativeSlice<T> slice)
        {
            if (spaceAvailable == 0)
            {
                slice = new NativeSlice<T>();   // need to assign empty slice.
                return false;
            }

            slice = slices.Pop();
            checkedOutSlices.Add(slice);

            return true;
        }

        public bool PushData(ref NativeSlice<T> slice)
        {
            if (slices.Count == count)
                return false;
            
            for (int i = 0; i < checkedOutSlices.Count; ++i)
            {
                if (slice == checkedOutSlices[i])
                {
                    slices.Push(slice);
                    return true;
                }
            }

            return false;
        }
    }
}
