﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using Unity.Collections;

namespace MemoryUtils
{
    /// <summary>
    /// Will create new blocks of memory with the use of MemoryBlockFixed when data that is requested is not available. 
    /// </summary>
    public class DynMemoryBlockFixed<T> where T : struct
    {
        public readonly int dataPerBlock;
        public readonly int stride;

        private LinkedList<MemoryBlockFixed<T>> blocks;

        public int blocksCreated
        {
            get
            {
                return blocks.Count;
            }
        }

        public int spaceAvailable
        {
            get
            {
                int val = 0;
                for (LinkedListNode<MemoryBlockFixed<T>> node = blocks.First; node != null; node = node.Next)
                {
                    val += node.Value.spaceAvailable;
                }
                return val;
            }
        }

        public DynMemoryBlockFixed(int dataPerBlock, int stride = 1)
        {
            this.blocks = new LinkedList<MemoryBlockFixed<T>>();

            this.dataPerBlock = dataPerBlock;
            this.stride = stride;

            AddNewBlock();
        }

        private LinkedListNode<MemoryBlockFixed<T>> AddNewBlock()
        {
            return blocks.AddLast(new MemoryBlockFixed<T>(dataPerBlock, stride));
        }

        public bool GetData(out NativeSlice<T> slice)
        {
            // attempt to find data in existing memory blocks. 
            for (LinkedListNode<MemoryBlockFixed<T>> node = blocks.First; node != null; node = node.Next)
            {
                if (node.Value.GetData(out slice))
                {
                    return true;
                }
            }

            // no space found. Create new block.
            LinkedListNode<MemoryBlockFixed<T>> newBlock = AddNewBlock();
            if (newBlock != null)
            {
                return newBlock.Value.GetData(out slice);
            }

            slice = new NativeSlice<T>(); // need to assign an empty slice. 
            return false;
        }

        public bool PushData(ref NativeSlice<T> slice)
        {
            for (LinkedListNode<MemoryBlockFixed<T>> node = blocks.First; node != null; node = node.Next)
            {
                if (node.Value.PushData(ref slice))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
