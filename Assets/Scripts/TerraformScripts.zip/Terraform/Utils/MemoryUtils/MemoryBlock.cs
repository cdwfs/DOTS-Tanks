﻿using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;

namespace MemoryUtils
{
    /// <summary>
    /// used in a linked list to define the state of a memory block.
    /// </summary>
    public struct DataState
    {
        public static readonly DataState Zero = new DataState(0, 0, true);

        public int dataIndex;  // the starting index in the data
        public int size;
        public bool free;

        public DataState(in int dataIndex, in int size, in bool free)
        {
            this.dataIndex = dataIndex;
            this.size = size;
            this.free = free;
        }

        public DataState(in DataState dataState, in bool free)
        {
            this.dataIndex = dataState.dataIndex;
            this.size = dataState.size;
            this.free = free;
        }

        /// <summary>
        /// cut a new data state from this data state.
        /// </summary>
        public bool Cut(in int cutSize, out DataState cutData)
        {
            // cannot cut data that is not free, or a size >= the size of the data.
            if (!free || cutSize >= size)
            {
                Debug.LogError("attempted to a data size of " + cutSize + " from a data state of size " + size + " (cannot cut data that is >= the size of the data we are cutting from)");
                cutData = Zero;
                return false;
            }

            cutData = new DataState(dataIndex, cutSize, false);
            this.dataIndex += cutSize;
            this.size -= cutSize;

            return true;
        }
    }

    /// <summary>
    /// initiates a native array as a memory block of the passed type which can return slices of memory at the given size, if that given size is available somewhere in the block. 
    /// </summary>
    public class MemoryBlock<T> where T : struct
    {
        public static readonly NativeSlice<T> NULL = new NativeSlice<T>();

        private NativeArray<T> block;
        private LinkedList<DataState> dataState;                    // represents the state of the data in order of the data.
        private LinkedList<LinkedListNode<DataState>> freeData;     // stores the nodes of the above linked list that represent free memory in order of size of the memory (front = largest block, back = smallest block)
        private Dictionary<NativeSlice<T>, LinkedListNode<DataState>> dataMap;  // allows native slices to find the node that represents them in the memory block

        public int count { get { return block.Length; } }

        public int space
        {
            get
            {
                if (freeData.Count == 0)
                {
                    return 0;
                }
                else
                {
                    int val = 0;
                    LinkedListNode<LinkedListNode<DataState>> n = freeData.First;
                    while (n != null)
                    {
                        val += n.Value.Value.size;
                        n = n.Next;
                    }

                    return val;
                }
            }
        }

        public int largestSpace
        {
            get
            {
                if (freeData.Count == 0)
                {
                    return 0;
                }
                else
                {
                    return freeData.First.Value.Value.size;
                }
            }
        }

        public MemoryBlock(int count)
        {
            this.block = new NativeArray<T>(count, Allocator.Persistent);

            this.dataState = new LinkedList<DataState>();
            this.freeData = new LinkedList<LinkedListNode<DataState>>();
            this.dataMap = new Dictionary<NativeSlice<T>, LinkedListNode<DataState>>();

            freeData.AddFirst(this.dataState.AddFirst(new DataState(0, count, true)));
        }

        ~MemoryBlock()
        {
            block.Dispose();
        }

        /// <summary>
        /// return a taken native slice to the memory block.
        /// </summary>
        public bool PushData(ref NativeSlice<T> slice)
        {
            LinkedListNode<DataState> dataStateNode;
            if (dataMap.TryGetValue(slice, out dataStateNode))
            {
                dataMap.Remove(slice);

                // attempt to combine the newly freed data with its direct neighbours in order to compress the data representation and make a bigger piece of available data.
                bool prevFree = (dataStateNode.Previous != null && dataStateNode.Previous.Value.free);
                bool nextFree = (dataStateNode.Next != null && dataStateNode.Next.Value.free);

                // calculate the data start index based on if the prev nood neighbour has its data freed.
                int dataIndex = prevFree ? dataStateNode.Previous.Value.dataIndex : dataStateNode.Value.dataIndex;
                int size = dataStateNode.Value.size;

                // if either neighbours are free then combine there size and remove there references from the arrays.
                if (prevFree)
                {
                    size += dataStateNode.Previous.Value.size;
                    freeData.Remove(dataStateNode.Previous);
                    dataState.Remove(dataStateNode.Previous);
                }
                if (nextFree)
                {
                    size += dataStateNode.Next.Value.size;
                    freeData.Remove(dataStateNode.Next);
                    dataState.Remove(dataStateNode.Next);
                }

                dataStateNode.Value = new DataState(dataIndex, size, true);
                AddFreeNode(dataStateNode);

                slice = NULL;
                return true;
            }

            return false;
        }

        /// <summary>
        /// attempt to get a slice of data of passed size. if there is no pieces of data within the memory block that can fill the request then false is returned and slice is set to NULL.
        /// </summary>
        public bool GetData(in int size, out NativeSlice<T> slice)
        {
            if (freeData.Count == 0 || largestSpace < size)
            {
                slice = NULL;
                return false;
            }

            // iterate from last as we want to utilise the smallest block of memory possible so we can minimise fragmenting the memory as much as possible. ;
            for (LinkedListNode<LinkedListNode<DataState>> n = freeData.Last; n != null; n = n.Previous)
            {
                if (size == n.Value.Value.size)
                {
                    GetWholeData(out slice, n);
                    return true;
                }
                if (size <= n.Value.Value.size)
                {
                    CutData(out slice, size, n);
                    return true;
                }
            }

            Debug.LogError("Should have found data in the memory block. Checks for size were passed.");
            slice = NULL;
            return false;
        }

        /// <summary>
        /// grabs a whole free space of data and flips it to taken.
        /// </summary>
        private bool GetWholeData(out NativeSlice<T> slice, LinkedListNode<LinkedListNode<DataState>> freeNode)
        {
            LinkedListNode<DataState> node = freeNode.Value;

            if (!node.Value.free)
            {
                slice = NULL;
                return false;
            }

            DataState newDataState = node.Value;
            newDataState.free = false;
            node.Value = newDataState;

            slice = new NativeSlice<T>(block, node.Value.dataIndex, node.Value.size);
            dataMap.Add(slice, node);
            freeData.Remove(freeNode);

            return true;
        }

        /// <summary>
        /// cut an amount of data off from a node describing a data state. If you are cutting data it must be because 
        /// you are assigning it. Cannot have 2 free data states next to each other.
        /// </summary>
        private bool CutData(out NativeSlice<T> slice, in int size, LinkedListNode<LinkedListNode<DataState>> freeNode)
        {
            LinkedListNode<DataState> node = freeNode.Value;

            DataState newDataState;
            DataState cutFrom = node.Value;
            if (!cutFrom.Cut(size, out newDataState))
            {
                slice = NULL;
                return false;
            }

            node.Value = cutFrom;

            LinkedListNode<DataState> newNode = dataState.AddBefore(node, newDataState);
            slice = new NativeSlice<T>(block, newDataState.dataIndex, newDataState.size);
            dataMap.Add(slice, newNode);

            SortFreeNode(freeNode);
            return true;
        }

        /// <summary>
        /// used to sort an existing free node by comparing to its neighbours.
        /// </summary>
        private void SortFreeNode(LinkedListNode<LinkedListNode<DataState>> freeNode)
        {
            int size = freeNode.Value.Value.size;
            if (freeNode.Next != null && size < freeNode.Next.Value.Value.size)
            {
                freeData.Remove(freeNode);

                LinkedListNode<LinkedListNode<DataState>> n = freeNode.Next;
                while (n != null)
                {
                    if (size >= n.Value.Value.size)
                    {
                        freeData.AddBefore(n, freeNode);
                        return;
                    }

                    n = n.Next;
                }

                // add to end.
                freeData.AddLast(freeNode);
                return;
            }
            if (freeNode.Previous != null && size > freeNode.Previous.Value.Value.size)
            {
                freeData.Remove(freeNode);

                LinkedListNode<LinkedListNode<DataState>> n = freeNode.Previous;
                while (n != null)
                {
                    if (size >= n.Value.Value.size)
                    {
                        freeData.AddAfter(n, freeNode);
                        return;
                    }

                    n = n.Previous;
                }

                // add to start.
                freeData.AddFirst(freeNode);
                return;
            }
        }

        // add a new free node.
        private void AddFreeNode(LinkedListNode<DataState> node)
        {
            int size = node.Value.size;

            LinkedListNode<LinkedListNode<DataState>> n = freeData.First;
            while (n != null)
            {
                if (size >= n.Value.Value.size)
                {
                    freeData.AddBefore(n, node);
                    return;
                }

                n = n.Next;
            }

            // add to end.
            freeData.AddLast(node);
            return;
        }
    }
}