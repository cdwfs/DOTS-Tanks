﻿/* ======================================================================
File:			SingletonBase.cs
Author:			Adrian Gordon
Date:			01/02/2019

Description:	A basic singleton class that self-instantialises 
=====================================================================*/

using UnityEngine;

public abstract class SingletonBase<T> : MonoBehaviour where T : MonoBehaviour
{
	protected static bool s_isShuttingDown = false;
	private static object s_lock = new object();
	private static T s_instance;

	public static T Instance
	{
		get
		{
			if (s_instance == null)
			{
				s_instance = (T)FindObjectOfType(typeof(T));

				if (s_instance == null)
				{
					var singletonObject = new GameObject(typeof(T).ToString());
					s_instance = singletonObject.AddComponent<T>();

#if !UNITY_EDITOR
                    DontDestroyOnLoad(singletonObject);
#endif
				}
			}

			return s_instance;
		}
	}

    void Awake()
    {
        T[] instances = (T[])FindObjectsOfType(typeof(T));
        if (instances.Length > 1)
        {
            Debug.LogError("Error: Could not initialize Singleton( + " + (typeof(T).ToString()) + ") as one already exists.");
            DestroyImmediate(gameObject);
        }
        else
        {
            OnInit();
        }
    }

    protected abstract void OnInit();

	private void OnApplicationQuit()
	{
		s_isShuttingDown = true;
	}

	private void OnDestroy()
	{
		s_isShuttingDown = true;
	}
}
