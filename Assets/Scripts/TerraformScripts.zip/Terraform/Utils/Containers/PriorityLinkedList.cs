﻿
/// <summary>
/// linked list that sorts contained nodes by priority defined by the IPriority interface (lower val the higher the priority). Nodes also have the ability to be stored elsewhere and be self managed 
/// once stored inside the list. e.g. if the priority of a node changes it can sort itself relative to its neighbours to its new location based on its new priority value.
/// </summary>
public class PriorityLinkedList<T> where T : class, IPriority
{
    public class Node
    {
        public PriorityLinkedList<T> parent;

        public T val;
        public Node next;
        public Node prev;

        public Node(T val)
        {
            this.val = val;
            this.parent = null;
            this.prev = null;
            this.next = null;
        }

        public void Remove()
        {
            if (parent != null)
            {
                parent.Remove(this);
            }
        }

        public void InsertAfter(Node node)
        {
            if (node.parent != null)
            {
                node.parent.InsertAfter(this, node);
            }
        }

        public void InsertBefore(Node node)
        {
            if (node.parent != null)
            {
                node.parent.InsertBefore(this, node);
            }
        }

        /// <summary>
        /// sorts the node locally to its own nighbours. And will move itself up or down the linked list to the location it fits in to.
        /// </summary>
        public void Sort()
        {
            int priority = val.Priority();

            if (prev != null)
            {
                if (priority < prev.val.Priority())
                {
                    Node node = prev.prev;

                    while (node != null)
                    {
                        if (priority >= node.val.Priority())
                        {
                            InsertAfter(node);
                            return;
                        }

                        node = node.prev;
                    }

                    // insert at front
                    InsertBefore(parent.front);
                    return;
                }
            }
            if (next != null)
            {
                if (priority > next.val.Priority())
                {
                    Node node = next.next;

                    while (node != null)
                    {
                        if (priority <= node.val.Priority())
                        {
                            InsertBefore(node);
                            return;
                        }

                        node = node.next;
                    }

                    // insert at back
                    InsertAfter(parent.back);
                    return;
                }
            }
        }
    }

    public Node front;
    public Node back;

    private int _count = 0;
    public int count { get { return _count; } }

    public Node Insert(T val)
    {
        int priority = val.Priority();

        Node newNode = new Node(val);

        if (_count == 0)
        {
            front = newNode;
            back = newNode;
            newNode.parent = this;
            ++_count;
        }
        else
        {
            Node node = front;

            while (node != null)
            {
                if (priority <= node.val.Priority())
                {
                    newNode.InsertBefore(node);
                    return newNode;
                }

                node = node.next;
            }

            // insert at end.
            newNode.InsertAfter(back);
        }

        return newNode;
    }

    private void Remove(Node node)
    {
        if (node.parent != this)
        {
            return;
        }

        if (node.prev != null)
        {
            node.prev.next = node.next;
        }
        else if (front == node)
        {
            front = node.next;
        }

        if (node.next != null)
        {
            node.next.prev = node.prev;
        }
        else if (back == node)
        {
            back = node.prev;
        }

        node.prev = null;
        node.next = null;

        _count = _count - 1;
        node.parent = null;
    }

    private void InsertAfter(Node node, Node target)
    {
        node.Remove();

        if (back == target)
        {
            back = node;
        }

        node.next = target.next;
        node.prev = target;

        if (node.next != null)
        {
            node.next.prev = node;
        }
        if (node.prev != null)
        {
            node.prev.next = node;
        }

        _count = _count + 1;
        node.parent = this;
    }

    private void InsertBefore(Node node, Node target)
    {
        node.Remove();

        if (front == target)
        {
            front = node;
        }

        node.prev = target.prev;
        node.next = target;
        if (node.next != null)
        {
            node.next.prev = node;
        }
        if (node.prev != null)
        {
            node.prev.next = node;
        }

        _count = _count + 1;
        node.parent = this;
    }

    public T PopFront()
    {
        if (_count == 0)
        {
            return null;
        }

        T val = front.val;
        front.Remove();

        return val;
    }

    public T PopBack()
    {
        if (_count == 0)
        {
            return null;
        }

        T val = back.val;
        back.Remove();

        return val;
    }

    public T PeekFront()
    {
        if (_count == 0)
        {
            return null;
        }

        return front.val;
    }

    public T PeekBack()
    {
        if (_count == 0)
        {
            return null;
        }

        return back.val;
    }
}
