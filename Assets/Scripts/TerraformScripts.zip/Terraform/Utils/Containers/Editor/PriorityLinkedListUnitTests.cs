﻿
using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using MemoryUtils;
using Unity.Collections;

namespace Tests.PriorityLinkedListUnitTests
{
    public class Tests
    {
        public class IntP : IPriority
        {
            public int val;

            public int Priority()
            {
                return val;
            }
        }

        [Test]
        public void CreatingListAndNodes()
        {
            PriorityLinkedList<IntP> list = new PriorityLinkedList<IntP>();

            Assert.AreEqual(0, list.count, "list count is not correct");
            PriorityLinkedList<IntP>.Node n1 = list.Insert(new IntP() { val = 5 });
            Assert.AreEqual(1, list.count, "list count is not correct");
            PriorityLinkedList<IntP>.Node n0 = list.Insert(new IntP() { val = 0 });
            Assert.AreEqual(2, list.count, "list count is not correct");
            PriorityLinkedList<IntP>.Node n2 = list.Insert(new IntP() { val = 10 });
            Assert.AreEqual(3, list.count, "list count is not correct");
        }

        [Test]
        public void CreatingListAndInsertingAndRemovingNodes()
        {
            PriorityLinkedList<IntP> list = new PriorityLinkedList<IntP>();

            PriorityLinkedList<IntP>.Node n1 = list.Insert(new IntP() { val = 5 });
            PriorityLinkedList<IntP>.Node n0 = list.Insert(new IntP() { val = 0 });
            PriorityLinkedList<IntP>.Node n2 = list.Insert(new IntP() { val = 10 });

            Assert.AreSame(n0, list.front, "node at front of list is not the not we want.");
            Assert.AreSame(n1, list.front.next, "node in middle of list is not the not we want.");
            Assert.AreSame(n2, list.back, "node at back of list is not the not we want.");

            Assert.AreEqual(3, list.count, "list count is not correct");

            // insert new node and test to make sure it ended up with the right neighbours. 
            PriorityLinkedList<IntP>.Node n3 = list.Insert(new IntP() { val = 7 });

            Assert.AreEqual(list.count, 4, "list count is not correct");
            Assert.AreSame(n2.prev, n3, "node n2 prev neighbour is not correct.");
            Assert.AreSame(n1.next, n3, "node n1 next neighbour is not correct.");

            Assert.AreSame(n3.prev, n1, "node n3 prev neighbour is not correct.");
            Assert.AreSame(n3.next, n2, "node n3 next neighbour is not correct.");

            // remove that new node.
            n3.Remove();

            Assert.AreEqual(list.count, 3, "list count is not correct after removal");
            Assert.AreSame(n1.next, n2, "node n1 next neighbour is not correct.");
            Assert.AreSame(n2.prev, n1, "node n2 prev neighbour is not correct.");
        }

        [Test]
        public void ChangingThePriorityValueOfANodeAndReSortingIt()
        {
            PriorityLinkedList<IntP> list = new PriorityLinkedList<IntP>();
            
            PriorityLinkedList<IntP>.Node n0 = list.Insert(new IntP() { val = 0 });
            PriorityLinkedList<IntP>.Node n1 = list.Insert(new IntP() { val = 25 });
            PriorityLinkedList<IntP>.Node n2 = list.Insert(new IntP() { val = 50 });
            PriorityLinkedList<IntP>.Node n3 = list.Insert(new IntP() { val = 75 });
            PriorityLinkedList<IntP>.Node n4 = list.Insert(new IntP() { val = 100 });

            Assert.AreSame(list.back.prev.prev, n2, "node n2 not in correct place.");

            // change node 2 priority
            n2.val.val = 80;
            n2.Sort();

            Assert.AreSame(list.back.prev, n2, "node n2 not in correct place after 1 move");
            
            // change node 2 priority so it is at front
            n2.val.val = -1;
            n2.Sort();

            Assert.AreSame(list.front, n2, "node n2 not in correct place after move to front");

            // change node 2 priority so it is at back
            n2.val.val = 200;
            n2.Sort();

            Assert.AreSame(list.back, n2, "node n2 not in correct place after move to back");
            Assert.AreSame(list.front, n0, "node n0 was not moved back to front correcty");

            // change node 2 priority so it is in the middle again
            n2.val.val = 50;
            n2.Sort();

            Assert.AreSame(list.front.next.next, n2, "node n2 not in correct place after move to back");
            Assert.AreSame(list.back, n4, "node n4 was not moved back to the back correcty");
        }
    }
}