﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;


/*
 * TODO: Integrate with nu2api ?
 * BE AWARE! - it seems that SYSTEM.IO.FILEINFO etc is also mirrored in nu2 api as it uses global namespace
 * DO NOT USE THIS CLASS ON NON-DESKTOP PLATFORMS !
 */

namespace Playdemic
{
    public static class FileUtils
    {
        /// <summary>File repository type (pre-defined folder locations)</summary>
        public enum RepositoryType
        {
            GeneratedData,
            StaticGameData,
            SavedGameData,
            DefaultConfigData,
            UserConfigData,
            Custom,
            EditorAssets,
            LogFiles
        }

        /// <summary>Returns a pre-defined file system path given a <see cref="RepositoryType"/> value</summary>
        public static string GetRepositoryPath(RepositoryType repoType)
        {
            string result;
            switch (repoType)
            {
                case RepositoryType.StaticGameData:
                    result = Application.streamingAssetsPath;
                    break;
                case RepositoryType.SavedGameData:
                    result = Application.persistentDataPath;
                    break;
                case RepositoryType.DefaultConfigData:
                    result = Application.streamingAssetsPath;
                    break;
                case RepositoryType.UserConfigData:
                    result = Application.persistentDataPath;
                    break;
                case RepositoryType.Custom:
                    result = Application.persistentDataPath;
                    break;
                case RepositoryType.GeneratedData:
                    result = $"{Application.streamingAssetsPath}/Data";
                    break;
                case RepositoryType.EditorAssets:
                    result = Application.dataPath;
                    break;
                case RepositoryType.LogFiles:
                    result = Application.isEditor ? "." : Application.persistentDataPath;
                    break;
                default:
                    result = "";
                    break;
            }

            return result;
        }

        /// <summary>Replace all text in the passed StringBuilder with the contents of a text file
        /// <para>If the file does not exist, the StringBuilder contents will be cleared.</para></summary>
        public static StringBuilder ReadTextFileIntoStringBuilder(
                string fileName,
                RepositoryType repoType,
                StringBuilder sb = null)
        {
            StringBuilder result = sb;
            result?.Clear();

            var file = Path.Combine(GetRepositoryPath(repoType), fileName);

            var fileInfo = new System.IO.FileInfo(file);
            var fileExists = fileInfo.Exists;

            if (!fileExists)
            {
                Dbg.Log($"FileUtils::ReadTextFileIntoStringBuilder - File not found [{file}]");
                return result;
            }

            long fileLength = fileInfo.Length;
            //File length is 64bit and StringBuilder uses 32bit int so check file will fit
            var maxFileSize = int.MaxValue;
            if (fileLength > maxFileSize)
            {
                const int MB = 1024 * 1024;
                var maxFileSizeString = $"{maxFileSize / MB:N}";
                Dbg.Log($"File [{file}] is too big .. current maximum size is {maxFileSizeString} MB");
                return result;
            }

            if (result == null) result = new StringBuilder((int)fileLength);
            result.Append(File.ReadAllBytes(file));
            return result;
        }

        /// <summary>Read full text file as a string from one of the pre-defined locations
        /// <para>returns the string or an empty string if the file is not available to read</para>
        /// <para>The repository type determines where the file is written to</para></summary>
        public static string ReadTextFileAsString(string fileName, RepositoryType repoType)
        {
            var result = "";
            var file = Path.Combine(GetRepositoryPath(repoType), fileName);

            //If file doesn't exist, report it and return empty string
            if (!File.Exists(file))
            {
                Dbg.Log($"FileUtils::ReadTextFileAsString - File not found [{file}]");
                return result;
            }

            Dbg.Log($"FileUtils::ReadTextFileAsString - Reading Text File [{file}]");
            result = File.ReadAllText(file);

            return result;
        }

        /// <summary>Read a text file from the repository into a List of strings</summary>
        /// <remarks><paramref name="list"/> can be null if you would like a list creating for you and returned</remarks>
        public static List<string> ReadTextFileIntoList(string fileName, RepositoryType repoType, List<string> list = null)
        {
            var result = list ?? new List<string>();

            var file = Path.Combine(GetRepositoryPath(repoType), fileName);

            //If file doesn't exist, report it and return empty list
            if (!File.Exists(file))
            {
                Dbg.Log($"FileUtils::ReadTextFileIntoList - File not found [{file}]");
                return result;
            }

            var fileSize = new System.IO.FileInfo(file).Length;
            Dbg.Log($"FileUtils::ReadTextFileIntoList - Reading {fileSize.ToString()} bytes from text file [{file}]");
            result.AddRange(File.ReadAllLines(file));
            Dbg.Log($"FileUtils::ReadTextFileIntoList - Resulting list entry count = {result.Count.ToString()}");
            return result;
        }


        /// <summary>Write a text file containing the string passed in
        /// <para>The repository type determines where the file is written to</para>
        /// <para>If repository type is CUSTOM then the last parameter should supply the path</para></summary>
        public static void WriteTextFile(string s, string fileName, RepositoryType repoType, string customPath = "")
        {
            var folder = repoType != RepositoryType.Custom ? GetRepositoryPath(repoType) : customPath;
            var file = Path.Combine(folder, fileName);

            Dbg.Log($"FileUtils::WriteTextFile - Writing text file [{file}]");

            try
            {
                CheckFolder(folder);
                File.WriteAllText(file, s);
            }
            catch (Exception e) { Dbg.LogException(e.ToString()); }
        }

        /// <summary>Check if "folder" exists, create it if not</summary>
        /// <remarks>Will cause an exception if an invalid path is provided</remarks>
        private static void CheckFolder(string folder)
        {
            if (Directory.Exists(folder)) return;
            Dbg.Log($"FileUtils::CheckFolder - Creating folder [{folder}]");
            Directory.CreateDirectory(folder);
        }

        /// <summary>Delete all files and folders under the specified root path</summary>
        /// <remarks> will also delete read-only files</remarks>
        public static void RecursiveDelete(string rootPath)
        {
            foreach (string directory in Directory.GetDirectories(rootPath))
            {
                RecursiveDelete(directory);
                Directory.Delete(directory);
            }

            foreach (string file in Directory.GetFiles(rootPath))
            {
                File.SetAttributes(file, System.IO.FileAttributes.Normal);
                File.Delete(file);
            }
        }
    }
}