﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;

public interface ICopyFrom<T>
{
	void CopyFrom(in T src);
}

public struct ReferenceCount
{
	public void IncReferences()
	{
		Interlocked.Increment(ref numReferences);
	}

	public void DecReferences()
	{
		Interlocked.Decrement(ref numReferences);
#if UNITY_EDITOR
		Debug.AssertFormat(numReferences >= 0, "{0}.{1}: -ve reference count.", this.GetType().Name, MethodBase.GetCurrentMethod().Name);
#endif
	}

	public bool IsStale()
	{
		return numReferences == 0;
	}

	public int GetReferenceCount()
	{
		return numReferences;
	}

	private int numReferences;
}

public struct RevisionId
{
	public RevisionId(int origId)
	{
		revisionId = origId;
	}

	public void SetRevision(int newRevision)
	{
		revisionId = newRevision;
	}

	public int GetRevisionId()
	{
		return revisionId;
	}

	public const int UnsetRevision = -1; // const objects are always static
	private int revisionId;
}

public class CopyOnWriteObject<T> : IDisposable where T : struct, ICopyFrom<T>, IDisposable
{
	public class Admin
	{
		public CopyOnWriteObject<T> managingObj;
		public ReferenceCount refCount;
		public RevisionId revisionId;
		public T cowObj;
	}

	// Simple sentinel class that ensures Read/WriteAccessHandles are released properly before they go out of scope
	// Simpler version of the Unity DisposeSentinel for NativeContainers
	protected class AccessHandleSentinel : IDisposable
	{
		public AccessHandleSentinel()
		{
			// keep the stack trace for debugging purposes (so can work out where the unreleased handle was created)
			stackTraceWhenAllocated = Environment.StackTrace;
		}

		public class NotReleasedException : Exception
		{
			public NotReleasedException(string message) : base(message)
			{
			}
		}

		public class ReleasedAgainException : Exception
		{
			public ReleasedAgainException(string message) : base(message)
			{
			}
		}

		// Will be called by the GC after the AccessHandle it belonged to is gone.
		~AccessHandleSentinel()
		{
			if (!beenDisposed)
			{
				// AccessHandle did not properly clean up before it went out of scope.
				Debug.LogErrorFormat("A Read/Write handle was not released properly.\n {0}", stackTraceWhenAllocated);
			}
		}

		// AccessHandle should dispose of the sentinel when it has been released
		public void Dispose()
		{
			if (!beenDisposed)
			{
				beenDisposed = true;
			}
			else
			{
				throw new ReleasedAgainException(string.Format("Attempting to release an already released Read/Write handle.\n {0}", stackTraceWhenAllocated));
			}
		}

		private bool beenDisposed = false;
		private readonly string stackTraceWhenAllocated;
	}

	public struct ReadAccessHandle
	{
		public ReadAccessHandle(in UpdateableReadAccess other)
		{
			var managingObj = other.referenceObj.managingObj;

			// Get Read lock on reference list (make sure latest version doesn't change during setup
			managingObj.revisionListLock.EnterReadLock();

			adminObjHandle = GCHandle.Alloc(other.referenceObj, GCHandleType.Pinned);
			((Admin) adminObjHandle.Target).refCount.IncReferences();
			managingObj.revisionListLock.ExitReadLock();
#if UNITY_EDITOR
            sentinel = new AccessHandleSentinel();
#endif
        }

		public ReadAccessHandle(in ReadAccessHandle other)
		{
#if UNITY_EDITOR
			sentinel = new AccessHandleSentinel();
#endif

			var adminObj = (Admin) other.adminObjHandle.Target;
			var managingObj = adminObj.managingObj;

			// Get Read lock on reference list (make sure latest version doesn't change during setup
			managingObj.revisionListLock.EnterReadLock();
			adminObjHandle = GCHandle.Alloc(other.adminObjHandle.Target, GCHandleType.Pinned);
			((Admin)adminObjHandle.Target).refCount.IncReferences();
			managingObj.revisionListLock.ExitReadLock();
		}

		public void ReleaseHandle()
		{
#if UNITY_EDITOR
			sentinel.Dispose();
#endif
			var adminObj = (Admin) adminObjHandle.Target;
			adminObj.refCount.DecReferences();
			if (adminObj.refCount.IsStale())
			{
				// nothing references the obj anymore, is now stale
				adminObj.managingObj.MoveToStaleList(adminObj);
			}

			adminObjHandle.Free();
		}

		public bool IsLatestRevision()
		{
			var adminObj = (Admin) adminObjHandle.Target;
			return (adminObj.revisionId.GetRevisionId() == adminObj.managingObj.latestRevisionId);
		}

		public int GetRevisionId()
		{
			return ((Admin)adminObjHandle.Target).revisionId.GetRevisionId();
		}

		public int GetReferenceCount()
		{
			return ((Admin)adminObjHandle.Target).refCount.GetReferenceCount();
		}

		public ref readonly T Get()
		{
			return ref ((Admin)adminObjHandle.Target).cowObj;
		}
		
		// GCHandle to the Admin object that manages the revision of T being read.
		// Pin the Admin object in memory whilst the read handle is in use, unpin when finished.
		// Implemented as GCHandle to allow AccessHandles to be passed to Unity jobs
		private GCHandle adminObjHandle;

#if UNITY_EDITOR
		[NativeSetClassTypeToNullOnScheduleAttribute] // needed to allow ReadAccessHandles to be passed to jobs.
		private readonly AccessHandleSentinel sentinel; // Editor only error checking - ensures that the ReadAccessHandle is released properly before going out of scope.
#endif
	}

	public class UpdateableReadAccess // should only be used inside class, but no friend keyword in c#, so needs to be public for now - intended for storing the latest revision and allowing easy update as it changes
	{
		public UpdateableReadAccess(CopyOnWriteObject<T> srcObject)
		{
			referenceObj = new Admin { cowObj = new T(), refCount = new ReferenceCount(), revisionId = new RevisionId(RevisionId.UnsetRevision), managingObj = srcObject };
#if UNITY_EDITOR
			sentinel = new AccessHandleSentinel();
#endif
			Update(referenceObj);
		}

		public void Update(Admin newRef)
		{
			if (newRef != null && newRef.managingObj != null)
			{
#if UNITY_EDITOR
				Debug.AssertFormat(referenceObj == null || newRef.managingObj == referenceObj.managingObj, "{0}.{1}: Updating latest revision with handle owned by different object", GetType().Name, MethodBase.GetCurrentMethod().Name);
#endif

				// Clean up old ref
				if (referenceObj != null && referenceObj != newRef)
				{
					referenceObj.refCount.DecReferences();
					if (referenceObj.refCount.IsStale())
					{
						referenceObj.managingObj.MoveToStaleList(referenceObj);
					}
				}

				// Add new ref
#if UNITY_EDITOR
				Debug.AssertFormat(!referenceObj.managingObj.revisionList.Contains(newRef), "{0}.{1}: New Object is already on reference list", GetType().Name, MethodBase.GetCurrentMethod().Name);
				Debug.AssertFormat(newRef.revisionId.GetRevisionId() == RevisionId.UnsetRevision, "{0}.{1}: New Object already has a revision id {2}", GetType().Name, MethodBase.GetCurrentMethod().Name, newRef.revisionId.GetRevisionId());
				Debug.AssertFormat(newRef.refCount.GetReferenceCount() == 0, "{0}.{1}: New Object is already referenced", GetType().Name, MethodBase.GetCurrentMethod().Name);
#endif
				referenceObj.managingObj.revisionListLock.EnterWriteLock();
				referenceObj.managingObj.revisionList.Add(newRef);
				referenceObj = newRef;
				++referenceObj.managingObj.latestRevisionId;
				referenceObj.revisionId.SetRevision(referenceObj.managingObj.latestRevisionId);
				referenceObj.refCount.IncReferences();
				referenceObj.managingObj.revisionListLock.ExitWriteLock();
			}
		}

		public void ReleaseHandle()
		{
#if UNITY_EDITOR
			sentinel.Dispose();
#endif
			referenceObj.refCount.DecReferences();
			if (referenceObj.refCount.IsStale())
			{
				// nothing references the obj anymore, is now stale
				referenceObj.managingObj.MoveToStaleList(referenceObj);
			}

			referenceObj = null;
		}

		public Admin referenceObj;

#if UNITY_EDITOR
		[NativeSetClassTypeToNullOnScheduleAttribute] // needed to allow ReadAccessHandles to be passed to jobs.
		private readonly AccessHandleSentinel sentinel; // Editor only error checking - ensures that the ReadAccessHandle is released properly before going out of scope.
#endif
	}

	public struct WriteAccessHandle
	{
		public WriteAccessHandle(CopyOnWriteObject<T> srcObject)
		{
			// Get Write lock on working obj (make sure only one handle ever has write access)
			srcObject.workingObjLock.EnterWriteLock();

			wasAccessed = false;
			shouldDiscard = false;

			// Get latest revision for copying
			var workingObj = new Admin()
			{
				cowObj = new T(),
				revisionId = new RevisionId(RevisionId.UnsetRevision),
				refCount = new ReferenceCount(),
				managingObj = srcObject,
			};

			ReadAccessHandle latestRefObj = srcObject.GetHandleForReading();
			workingObj.cowObj.CopyFrom(latestRefObj.Get());
			latestRefObj.ReleaseHandle();
			workingObj.refCount.IncReferences();

			adminObjHandle = GCHandle.Alloc(workingObj, GCHandleType.Pinned);

#if UNITY_EDITOR
			sentinel = new AccessHandleSentinel();
#endif
		}

		public void ReleaseHandle()
		{
#if UNITY_EDITOR
			sentinel.Dispose();
#endif

			var workingObj = (Admin) adminObjHandle.Target;
			var managingObj = workingObj.managingObj;

			managingObj.revisionListLock.EnterWriteLock(); // going to want lock moving to either the revision or stale list
			workingObj.refCount.DecReferences();

			// Discard changes if requested externally, if the workingObj was never accessed (and thus never edited) or the workingObj contents are equal to the current revision
			// Shouldn't have to get read access handle as we've locked the object for writing
			if (shouldDiscard || !wasAccessed || managingObj.latestRevision.referenceObj.cowObj.GetHashCode() == workingObj.cowObj.GetHashCode())
			{
				// move to stale list
				if (!managingObj.staleList.Contains(workingObj))
				{
					managingObj.staleList.Add(workingObj);
				}
#if UNITY_EDITOR
				else
				{
					Debug.LogErrorFormat("{0}.{1}: Object already on state list", GetType().Name, MethodBase.GetCurrentMethod().Name);
				}
#endif
			}
			else
			{
				// move to reference list
				managingObj.latestRevision.Update(workingObj);
			}

			managingObj.revisionListLock.ExitWriteLock();

			managingObj.workingObjLock.ExitWriteLock();

			managingObj = null;
			workingObj = null;
			adminObjHandle.Free();
		}

		public ref T Get()
		{
			wasAccessed = true;
			return ref ((Admin) adminObjHandle.Target).cowObj;
		}

		public int GetRevisionId()
		{
			return ((Admin)adminObjHandle.Target).revisionId.GetRevisionId();
		}

		public int GetReferenceCount()
		{
			return ((Admin)adminObjHandle.Target).refCount.GetReferenceCount();
		}

		public void DiscardChanges()
		{
			shouldDiscard = true;
		}

		// GCHandle to the Admin object that manages the working revision of T.
		// Pin the Admin object in memory whilst the write handle is in use, unpin when finished.
		// Implemented as GCHandle to allow AccessHandles to be passed to Unity jobs
		private GCHandle adminObjHandle; // pin whilst got lock

		private bool wasAccessed;
		private bool shouldDiscard;
#if UNITY_EDITOR
		[NativeSetClassTypeToNullOnScheduleAttribute] // needed to allow ReadAccessHandles to be passed to jobs.
		private readonly AccessHandleSentinel sentinel; // Editor only error checking - ensures that the ReadAccessHandle is released properly before going out of scope.
#endif
	}

	public CopyOnWriteObject()
	{
		latestRevision = new UpdateableReadAccess(this);
	}

	private void MoveToStaleList(Admin staleObj)
	{
#if UNITY_EDITOR
		Debug.Assert(staleObj.refCount.IsStale(), this.GetType().Name + ": Object is not stale");
#endif

		// get write lock on reference list - moving current obj to stale list
		revisionListLock.EnterWriteLock();

		if (revisionList.Contains(staleObj))
		{
			revisionList.Remove(staleObj);
		}
#if UNITY_EDITOR
		else
		{
			Debug.LogErrorFormat("{0}.{1}: Trying to move object to stale grid which wasn't on reference list.", this.GetType().Name, MethodBase.GetCurrentMethod().Name);
		}
#endif

		if (!staleList.Contains(staleObj))
		{
			staleList.Add(staleObj);
		}
#if UNITY_EDITOR
		else
		{
			Debug.LogErrorFormat("{0}.{1}: Object already on stale list.", this.GetType().Name, MethodBase.GetCurrentMethod().Name);
		}
#endif

		revisionListLock.ExitWriteLock();
	}

	public WriteAccessHandle GetHandleForWriting()
	{
		return new WriteAccessHandle(this);
	}

	public ReadAccessHandle GetHandleForReading()
	{
#if UNITY_EDITOR
		Debug.AssertFormat(latestRevision.referenceObj.revisionId.GetRevisionId() == latestRevisionId, "{0}.{1}: Object being passed to read handle is not the latest revision.", GetType().Name, MethodBase.GetCurrentMethod().Name);
		Debug.AssertFormat(revisionList.Contains(latestRevision.referenceObj), "{0}.{1}: Latest reference object not in reference list.", GetType().Name, MethodBase.GetCurrentMethod().Name);
#endif
		// Get Read lock on reference list (make sure latest version doesn't change during setup
		return new ReadAccessHandle(in latestRevision);
	}

	// Counts the number of external references to the object, excluding any held by the object itself (i.e. the latest revision)
	public int GetExternalRefCount()
	{
		int extRefCount = 0;
		for (int i = 0; i < revisionList.Count; ++i)
		{
			extRefCount += revisionList[i].refCount.GetReferenceCount();
			if (revisionList[i] == latestRevision.referenceObj)
			{
				--extRefCount; // subtract one for the reference the class itself keeps to the revision internally
			}
		}

		if (workingObjLock.IsWriteLockHeld)
		{
			// Something has taken out a WriteAccessHandle
			++extRefCount;
		}

		return extRefCount;
	}

	public int GetStaleRevisionsCount()
	{
		return staleList.Count;
	}

	public void FreeStaleRevisions()
	{

	}

	#region IDisposable Support
	private bool disposedValue = false; // To detect redundant calls

	protected virtual void Dispose(bool disposing)
	{
		if (!disposedValue)
		{
			Debug.Assert(!workingObjLock.IsReadLockHeld && !workingObjLock.IsWriteLockHeld, "Disposing of CopyOnWriteObject while write lock is held");
			Debug.Assert(!revisionListLock.IsReadLockHeld && !revisionListLock.IsWriteLockHeld, "Disposing of CopyOnWriteObject while revision list is locked");

			latestRevision.ReleaseHandle();

			for (int i = 0; i < revisionList.Count; ++i)
			{
				revisionList[i].cowObj.Dispose();
			}
			revisionList.Clear();

			for (int i = 0; i < staleList.Count; ++i)
			{
				staleList[i].cowObj.Dispose();
			}
			staleList.Clear();

			workingObjLock = null;
			revisionListLock = null;

			disposedValue = true;
		}
	}


	~CopyOnWriteObject()
	{
		// Do not change this code. Put cleanup code in Dispose(bool disposing) above.
		Dispose(false);
	}

	public void Dispose()
	{
		// Do not change this code. Put cleanup code in Dispose(bool disposing) above.
		Dispose(true);
		GC.SuppressFinalize(this);
	}
	#endregion

	// Private rather than protected to prevent extensions of this object trying to circumvent using AccessHandles (like the MechTerraformTerrainChunk could do)

	// Locked for duration of editing by WriteAccessHandle to prevent multiple threads editing the object at the same time
	// Don't think this needs to be read/write - as will only ever be write locked.
	// Note - in worlds/g5 - grid would be edited on background thread, then LAM would manage replacement of reference object on foreground thread once BG edit job finished 
	private ReaderWriterLockSlim workingObjLock = new ReaderWriterLockSlim();

	// Locks the latest reference, reference list and stale list
	// Supports Recursion as need to be able to support a 2nd write lock on the same thread if updating the latest revision with working data causes previous revision to go stale
	private ReaderWriterLockSlim revisionListLock = new ReaderWriterLockSlim(LockRecursionPolicy.SupportsRecursion);

	// NOTE - Feel like shouldn't need to have workingObj here as should only need to exist whilst a WriteAccessHandle is open. But might need to move back here for error checking.
	// Copy the reference obj T to the workingObj when someone attempts to edit the obj T
	// Only one working object may be present at time. Working object becomes the reference obj once writing is finished
	//private T workingObj = null;

	// The stable version of the obj (the reference version that is read/copied)
	// Store with UpdateableReadAccess to prevent becoming stale and allow easy update
	private readonly UpdateableReadAccess latestRevision;

	// The list of objects T which are currently being referenced (a ReadAccessHandle<T> exists for them)
	private List<Admin> revisionList = new List<Admin>();

	// The list of objects T which are no longer referenced (gone stale) and can be safely disposed of
	// Should probably use this to free up tower memory quickly (rather than waiting for GC), don't necessarily need to call IDispose
	private List<Admin> staleList = new List<Admin>();

	private int latestRevisionId = RevisionId.UnsetRevision;
}