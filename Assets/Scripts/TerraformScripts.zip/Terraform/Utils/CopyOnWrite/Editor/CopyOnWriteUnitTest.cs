﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using NUnit.Framework;
using Unity.Collections;
using Unity.Jobs;
using Random = System.Random;

namespace Tests
{
	// Tests
	// Single threaded tests
	// - Multiple Read object
	// - Multiple Read object whilst editing
	// - Write object whilst being read
	// - Read object whilst being written
	// - Write object becomes latest revision, maintaining existing read refs
	// - Discard unwanted working object
	// - Unreferenced objects move to stale grid
	// - number of external references - useful for when system to manage destruction exists

	// Multi-threaded tests
	// - Block write, whilst writing

	namespace CopyOnWriteUnitTests
	{
		namespace CopyOnWriteIntTests
		{
			struct CopyOnWriteInt : ICopyFrom<CopyOnWriteInt>, IDisposable
			{
				public override int GetHashCode()
				{
					return objValue; // just return the value
				}

				public static CopyOnWriteObject<CopyOnWriteInt> InitCowObject(int initValue)
				{
					var cowObject = new CopyOnWriteObject<CopyOnWriteInt>();

					CopyOnWriteObject<CopyOnWriteInt>.WriteAccessHandle writeHandle = cowObject.GetHandleForWriting();
					writeHandle.Get().objValue = initValue;
					writeHandle.ReleaseHandle(); // writeHandle should get disposed, update ref value in cowObject

					return cowObject;
				}

				public void CopyFrom(in CopyOnWriteInt src)
				{
					objValue = src.objValue;
				}

				public void Dispose()
				{

				}

				public int objValue;
			}

			public class SingleThreadedTests
			{
				[Test]
				public void CloneIntObject()
				{
					var origInt = new CopyOnWriteInt()
					{
						objValue = 5,
					};

					var copyInt = origInt;

					Assert.AreEqual(5, origInt.objValue);
					Assert.AreEqual(5, copyInt.objValue);
				}


				[Test]
				public void GetInitialHandle()
				{
					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						var readHandle = cowObject.GetHandleForReading();
						Assert.AreEqual(0, readHandle.Get().objValue);
						readHandle.ReleaseHandle();
					}
				}

				[Test]
				public void ChangeValue()
				{
					const int finalValue = 42;

					using (var cowObject = CopyOnWriteInt.InitCowObject(finalValue))
					{
						var readHandle = cowObject.GetHandleForReading();

						Assert.AreNotEqual(null, readHandle);
						Assert.AreNotEqual(null, readHandle.Get());
						Assert.AreEqual(finalValue, readHandle.Get().objValue);

						readHandle.ReleaseHandle();
					}
				}

				[Test]
				public void MultipleRevisionsTest()
				{
					int[] finalValues = new int[] { 0, 42, 666, 13, 1, 895747, 3098, 890, 1337, -1, int.MinValue, int.MaxValue };
					var readHandles = new CopyOnWriteObject<CopyOnWriteInt>.ReadAccessHandle[finalValues.Length];

					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						readHandles[0] = cowObject.GetHandleForReading();

						for (var i = 1; i < finalValues.Length; ++i)
						{
							CopyOnWriteObject<CopyOnWriteInt>.WriteAccessHandle writeHandle = cowObject.GetHandleForWriting();
							writeHandle.Get().objValue = finalValues[i];
							writeHandle.ReleaseHandle(); // writeHandle should get disposed, update ref value in cowObject

							readHandles[i] = cowObject.GetHandleForReading();
							Assert.IsTrue(readHandles[i].IsLatestRevision()); // new read handles should always reference the latest revision of the object
						}

						for (var i = 0; i < finalValues.Length; ++i)
						{
							Assert.AreEqual(finalValues[i], readHandles[i].Get().objValue);
							Assert.AreEqual(i, readHandles[i].GetRevisionId());
							Assert.AreEqual(i == (finalValues.Length - 1), readHandles[i].IsLatestRevision()); // only the last handle should be the latest revision
							readHandles[i].ReleaseHandle();
						}
					}
				}

				[Test]
				public void ReadWhilstWriting()
				{
					const int initValue = 329054854;
					const int finalValue = int.MinValue;

					using (var cowObject = CopyOnWriteInt.InitCowObject(initValue))
					{
						var writeHandle = cowObject.GetHandleForWriting();
						writeHandle.Get().objValue = finalValue;
						var readHandle = cowObject.GetHandleForReading();
						Assert.AreEqual(initValue, readHandle.Get().objValue);
						writeHandle.ReleaseHandle();
						readHandle.ReleaseHandle();

						readHandle = cowObject.GetHandleForReading();
						Assert.AreEqual(finalValue, readHandle.Get().objValue);
						readHandle.ReleaseHandle();
					}
				}

				[Test]
				public void DiscardWrite()
				{
					const int finalValue = 244654;
					const int lostValue = 9308423;

					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						// Test initial expected values
						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(0, readHandle.Get().objValue);
							Assert.AreEqual(0, readHandle.GetRevisionId());
							readHandle.ReleaseHandle();
						}

						{
							var writeHandle = cowObject.GetHandleForWriting();
							writeHandle.Get().objValue = finalValue;
							Assert.AreEqual(RevisionId.UnsetRevision, writeHandle.GetRevisionId()); // writeable obj should not have a revision
							writeHandle.ReleaseHandle();
						}

						// Test revision id bumped when value changed
						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(finalValue, readHandle.Get().objValue);
							Assert.AreEqual(1, readHandle.GetRevisionId());
							readHandle.ReleaseHandle();
						}

						{
							var writeHandle = cowObject.GetHandleForWriting();
							writeHandle.Get().objValue = finalValue;
							writeHandle.ReleaseHandle();
						}

						// Value hasn't changed, so write handle should be discarded automatically
						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(finalValue, readHandle.Get().objValue);
							Assert.AreEqual(1, readHandle.GetRevisionId());
							readHandle.ReleaseHandle();
						}

						{
							var writeHandle = cowObject.GetHandleForWriting();
							writeHandle.Get().objValue = lostValue;
							writeHandle.DiscardChanges();
							writeHandle.ReleaseHandle();
						}

						// Requested discard
						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(finalValue, readHandle.Get().objValue);
							Assert.AreEqual(1, readHandle.GetRevisionId());
							readHandle.ReleaseHandle();
						}
					}
				}

				[Test]
				public void ReferenceCounting()
				{
					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						Assert.AreEqual(0, cowObject.GetExternalRefCount());

						{
							var readHandle = cowObject.GetHandleForReading();

							Assert.AreEqual(1, cowObject.GetExternalRefCount());
							Assert.AreEqual(2, readHandle.GetReferenceCount()); // Should be referenced by this readHandle, and the by cowObject as the latest revision
							Assert.IsTrue(readHandle.IsLatestRevision());

							// Taking a write handle should increase the external reference count
							// The write object only exists inside the write handle, so should only ever have one ref, but need to do refactor the interface to guarantee that
							{
								var writeHandle = cowObject.GetHandleForWriting();
								Assert.AreEqual(2, cowObject.GetExternalRefCount());
								Assert.AreEqual(1, writeHandle.GetReferenceCount());
								Assert.AreEqual(2, readHandle.GetReferenceCount()); // Should be referenced by this readHandle, and the by cowObject as the latest revision
								writeHandle.ReleaseHandle();
							}

							// unchanged obj should have been discarded
							Assert.AreEqual(1, cowObject.GetExternalRefCount());
							Assert.AreEqual(2, readHandle.GetReferenceCount()); // Should be referenced by this readHandle, and the by cowObject as the latest revision
							Assert.IsTrue(readHandle.IsLatestRevision());

							{
								var writeHandle = cowObject.GetHandleForWriting();
								++writeHandle.Get().objValue;
								writeHandle.ReleaseHandle();
							}

							// readHandle is no longer the latest revision
							Assert.AreEqual(1, cowObject.GetExternalRefCount());
							Assert.AreEqual(1, readHandle.GetReferenceCount()); // Should be referenced by this readHandle
							Assert.IsFalse(readHandle.IsLatestRevision());

							// Take another read handle to the old revision
							{
								var duplicateHandle = new CopyOnWriteObject<CopyOnWriteInt>.ReadAccessHandle(readHandle);
								Assert.AreEqual(2, cowObject.GetExternalRefCount());
								Assert.AreEqual(2, readHandle.GetReferenceCount()); // Should be referenced by readHandle and duplicateHandle
								Assert.AreEqual(2, duplicateHandle.GetReferenceCount()); // Should be referenced by readHandle and duplicateHandle
								Assert.IsFalse(readHandle.IsLatestRevision());
								Assert.IsFalse(duplicateHandle.IsLatestRevision());
								duplicateHandle.ReleaseHandle();
							}

							Assert.AreEqual(1, cowObject.GetExternalRefCount());
							Assert.AreEqual(1, readHandle.GetReferenceCount()); // Should be referenced by readHandle

							readHandle.ReleaseHandle();
						}

						Assert.AreEqual(0, cowObject.GetExternalRefCount());
					}
				}

				[Test]
				public void StaleRevisions()
				{
					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						int staleCount = 0;

						Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // no stale revisions to begin with

						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // no stale revisions to begin with

							{
								var writeHandle = cowObject.GetHandleForWriting();
								Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // no stale revisions to begin with
								writeHandle.ReleaseHandle();
							}

							staleCount++;
							Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid

							{
								var writeHandle = cowObject.GetHandleForWriting();
								writeHandle.Get().objValue++;
								writeHandle.ReleaseHandle();
							}

							// The writeHandle obj should've become the latestRevision this time
							Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid
							readHandle.ReleaseHandle();
						}

						// The disposed readHandle should have been moved to the stale list, as no longer the latest reference
						staleCount++;
						Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid, 1 previous revision

						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid, 1 previous revision
							readHandle.ReleaseHandle();
						}

						// Just released handle is still latest reference, so shouldn't be on stale list
						Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid, 1 previous revision


						var readHandleA = cowObject.GetHandleForReading();

						{
							var writeHandle = cowObject.GetHandleForWriting();
							writeHandle.Get().objValue++;
							writeHandle.ReleaseHandle();
						}

						Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid, 1 previous revision

						// readHandlesA and B point to old revisions
						var readHandleB = new CopyOnWriteObject<CopyOnWriteInt>.ReadAccessHandle(readHandleA);

						readHandleA.ReleaseHandle();
						Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid, 1 previous revision
						readHandleB.ReleaseHandle();
						staleCount++;
						Assert.AreEqual(staleCount, cowObject.GetStaleRevisionsCount()); // the unused working grid, 2 previous revisions
					}
				}
			}

			public class MultiThreadedTests
			{
				[Test]
				public void WriteOnBgThread()
				{
					const int firstValue = 13;
					const int secondValue = 823573;

					void BGThreadProc(object obj)
					{
						var threadData = obj as Tuple<int, CopyOnWriteObject<CopyOnWriteInt>>;
						var writeHandle = threadData.Item2.GetHandleForWriting();
						writeHandle.Get().objValue = threadData.Item1;
						writeHandle.ReleaseHandle();
					}

					void SetValueOnBgThread(int value, CopyOnWriteObject<CopyOnWriteInt> sharedCow)
					{
						Thread bgThread = new Thread(BGThreadProc);
						bgThread.Start(Tuple.Create(value, sharedCow));
						bgThread.Join();
					}

					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(0, readHandle.Get().objValue); // default value for object
							readHandle.ReleaseHandle();
						}

						// Start a 2nd thread, have it edit the value, then read on main thread
						SetValueOnBgThread(firstValue, cowObject);

						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(firstValue, readHandle.Get().objValue); // now pickup value from 2nd thread
							readHandle.ReleaseHandle();
						}

						// Let's do that again with a read handle open
						{
							var readHandle = cowObject.GetHandleForReading();
							SetValueOnBgThread(secondValue, cowObject);
							Assert.AreEqual(firstValue, readHandle.Get().objValue); // should still be first value cause took read handle before writing
							readHandle.ReleaseHandle();
						}

						{
							var readHandle = cowObject.GetHandleForReading();
							Assert.AreEqual(secondValue, readHandle.Get().objValue); // now pickup value from 2nd thread
							readHandle.ReleaseHandle();
						}
					}
				}

				[Test]
				public void WriteOnMultipleThreads()
				{
					// Primarily want to test that only one thread can have write access at a time
					var fgThreadSleep = 1000;
					var bgThreadSleep = 750;

					var blockTimeOnFgThread = 0.0f;
					var blockTimeOnBgThread = 0.0f;

					var sw = new Stopwatch();

					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						var blockedThread = new Thread(
							(object obj) =>
							{
								var sharedCow = obj as CopyOnWriteObject<CopyOnWriteInt>;
								var bgWriteHandle = sharedCow.GetHandleForWriting(); // should block whilst fg thread has lock
								blockTimeOnBgThread = sw.ElapsedMilliseconds;
								bgWriteHandle.ReleaseHandle();
							});

						{
							// Main thread has write lock, start a 2nd thread and take lock immediately. make sure the thread is blocked until fg thread releases the write lock
							var fgWriteHandle = cowObject.GetHandleForWriting();
							sw.Start();
							blockedThread.Start(cowObject);
							Thread.Sleep(fgThreadSleep);
							fgWriteHandle.ReleaseHandle();
						}

						blockedThread.Join();

						Assert.GreaterOrEqual(blockTimeOnBgThread, fgThreadSleep);

						// And now the reverse
						var delay = 1; //ms
						var blockingThread = new Thread(
							(object obj) =>
							{
								var sharedCow = obj as CopyOnWriteObject<CopyOnWriteInt>;
								var bgWriteHandle = sharedCow.GetHandleForWriting();
								Thread.Sleep(bgThreadSleep + delay); // Delay to account for fg thread delay (see below)
								bgWriteHandle.ReleaseHandle();
							});

						blockingThread.Start(cowObject);
						sw.Reset();
						sw.Start();

						Thread.Sleep(delay); // Sleep for a little bit to allow thread time to get write lock

						{
							var fgWriteHandle = cowObject.GetHandleForWriting();
							sw.Stop();
							blockTimeOnFgThread = sw.ElapsedMilliseconds;
							fgWriteHandle.ReleaseHandle();
						}
						blockingThread.Join();

						Assert.GreaterOrEqual(blockTimeOnFgThread, bgThreadSleep);
					}
				}

				struct WriteJob : IJob
				{
					public GCHandle cowHandle;
					public int jobValue;
					
					public void Execute()
					{
						var cowObject = (CopyOnWriteObject<CopyOnWriteInt>) cowHandle.Target;
						var writeHandle = cowObject.GetHandleForWriting();
						writeHandle.Get().objValue = jobValue;
						writeHandle.ReleaseHandle();
					}

					public void OnComplete()
					{
						cowHandle.Free();
					}
				}

				[Test]
				public void UseInUnityJob()
				{
					var finalValue = 7428934;
					using (var cowObject = new CopyOnWriteObject<CopyOnWriteInt>())
					{
						var job = new WriteJob()
						{
							cowHandle = GCHandle.Alloc(cowObject, GCHandleType.Pinned),
							jobValue = finalValue,
						};

						JobHandle jobHandle = job.Schedule();
						jobHandle.Complete();
						job.OnComplete();

						var readHandle = cowObject.GetHandleForReading();
						Assert.AreEqual(finalValue, readHandle.Get().objValue);
						readHandle.ReleaseHandle();
					}
				}

			}
		}

		namespace CopyOnWriteNativeArrayTests
		{
			struct CopyOnWriteNativeArray : ICopyFrom<CopyOnWriteNativeArray>, IDisposable
			{
				public override int GetHashCode()
				{
					return values.GetHashCode();
				}

				public void CopyFrom(in CopyOnWriteNativeArray src)
				{
					if (values.Length > 0)
					{
						values.Dispose();
					}

					values =  (src.values.Length > 0) ? new NativeArray<int>(src.values, Allocator.Persistent)
														: values = new NativeArray<int>();
				}

				public static CopyOnWriteObject<CopyOnWriteNativeArray> InitCowObject(in int[] initValue)
				{
					var cowObject = new CopyOnWriteObject<CopyOnWriteNativeArray>();

					{
						var writeHandle = cowObject.GetHandleForWriting();
						writeHandle.Get().values = new NativeArray<int>(initValue, Allocator.Persistent);
						writeHandle.ReleaseHandle();
					} // writeHandle should get disposed, update ref value in cowObject

					return cowObject;
				}

				public void Dispose()
				{
					if (values.Length > 0)
					{
						values.Dispose();
					}
				}

				public NativeArray<int> values;
			}

			class SingleThreadedTests
			{
				[Test]
				public void InitialiseArray()
				{
					using (var cowObject = new CopyOnWriteObject<CopyOnWriteNativeArray>())
					{
						var readHandle = cowObject.GetHandleForReading();
						Assert.AreEqual(0, readHandle.Get().values.Length);
						readHandle.ReleaseHandle();
					}
				}

				[Test]
				public void WriteToArray()
				{
					int[] finalValues = new[] { 45, 235, 542, 21, 325, 456, 454, 42, 1337 };

					using (var cowObject = CopyOnWriteNativeArray.InitCowObject(finalValues))
					{
						var readHandle = cowObject.GetHandleForReading();
						Assert.AreEqual(finalValues.Length, readHandle.Get().values.Length);
						for (int i = 0; i < finalValues.Length; ++i)
						{
							Assert.AreEqual(finalValues[i], readHandle.Get().values[i]);
						}
						readHandle.ReleaseHandle();
					}
				}

				[Test]
				public void ReadWhilstWriting()
				{
					const int testValues = 10;
					int[] initValue = new int[testValues];
					int[] finalValue = new int[testValues];

					Random rand = new Random();
					for (int i = 0; i < testValues; ++i)
					{
						initValue[i] = rand.Next();
						finalValue[i] = rand.Next();
					}

					using (var cowObject = CopyOnWriteNativeArray.InitCowObject(initValue))
					{
						var writeHandle = cowObject.GetHandleForWriting();
						writeHandle.Get().values.CopyFrom(finalValue);
						var readHandle = cowObject.GetHandleForReading();
						for (int i = 0; i < testValues; ++i)
						{
							Assert.AreEqual(initValue[i], readHandle.Get().values[i]);
						}
						readHandle.ReleaseHandle();
						writeHandle.ReleaseHandle();

						readHandle = cowObject.GetHandleForReading();
						for (int i = 0; i < testValues; ++i)
						{
							Assert.AreEqual(finalValue[i], readHandle.Get().values[i]);
						}
						readHandle.ReleaseHandle();
					}
				}
			}
		}
	}
}

