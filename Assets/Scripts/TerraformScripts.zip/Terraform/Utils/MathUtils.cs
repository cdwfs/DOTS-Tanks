﻿    /* ======================================================================
File:            MathUtils.cs
Author:          Adrian Gordon
Date:            12/03/2019

Description: Place to put extra math utils
=====================================================================*/

using Unity.Mathematics;

public sealed class MathUtils
{
    public static float SeekHalfLife(float Val, float Target, float PowVal)
    {
        float Delta = Target - Val;
        Val += (Delta * PowVal);
        return Val;
    }

    public static float3 SeekHalfLife(float3 Val, float3 Target, float PowVal)
    {
        float x = SeekHalfLife(Val.x, Target.x, PowVal);
        float y = SeekHalfLife(Val.y, Target.y, PowVal);
        float z = SeekHalfLife(Val.z, Target.z, PowVal);

        return new float3(x, y, z);
    }

    public static quaternion SeekHalfLife(quaternion Val, quaternion Target, float PowVal)
    {
        float x = SeekHalfLife(Val.value.x, Target.value.x, PowVal);
        float y = SeekHalfLife(Val.value.y, Target.value.y, PowVal);
        float z = SeekHalfLife(Val.value.z, Target.value.z, PowVal);
        float w = SeekHalfLife(Val.value.w, Target.value.w, PowVal);

        return new quaternion(x, y, z, w);
    }

    public static float3 RotateAroundPoint(float3 point, float3 rotateAround, float3 axis, float delta)
    {
        float3 pitchDiffVec = rotateAround - point;
        quaternion pitchQuat = quaternion.AxisAngle(axis, delta);
        float3 diffPitchVec = math.mul(pitchQuat, pitchDiffVec);
        float3 rotatedVec = point;
        rotatedVec += pitchDiffVec;
        rotatedVec -= diffPitchVec;

        return rotatedVec;
    }
}
