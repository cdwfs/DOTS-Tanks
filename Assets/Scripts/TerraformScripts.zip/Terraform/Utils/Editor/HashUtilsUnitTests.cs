﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Tests
{
    namespace HashUtilsUnitTests
    {
        public class Tests
        {
            void ZOrder2DTest(ushort x, ushort z)
            {
                UInt32 x32 = (UInt32)x;
                UInt32 z32 = (UInt32)z;

                UInt32 hash = HashUtils.CalcZOrder(x, z);

                // x bit test
                for (int i = 0; i < 16; ++i)
                {
                    UInt32 mask32 = 1;
                    mask32 = mask32 << i * 2;
                    UInt32 mask16 = 1;
                    mask16 = mask16 << i;

                    bool testCase = (x32 & mask16) != 0;
                    Assert.AreEqual(testCase, (hash & mask32) != 0, "hash is not correct for x value");
                }

                // z bit test
                for (int i = 0; i < 16; ++i)
                {
                    UInt32 mask32 = 1;
                    mask32 = mask32 << (i * 2) + 1;
                    UInt32 mask16 = 1;
                    mask16 = mask16 << i;

                    bool testCase = (z32 & mask16) != 0;
                    Assert.AreEqual(testCase, (hash & mask32) != 0, "hash is not correct for z value");
                }
            }

            [Test]
            public void ZOrder2D()
            {
                ZOrder2DTest(43756, 7567);
                ZOrder2DTest(354, 59545);
                ZOrder2DTest(3456, 242);
                ZOrder2DTest(45365, 31232);
                ZOrder2DTest(3, 2354);
                ZOrder2DTest(5345, 4353);
                ZOrder2DTest(234, 456);
                ZOrder2DTest(9, 56);
                ZOrder2DTest(0, ushort.MaxValue);
                ZOrder2DTest(ushort.MaxValue, ushort.MaxValue);
                ZOrder2DTest(0, 0);
                ZOrder2DTest(ushort.MaxValue, 0);
            }
        }
    }
}
