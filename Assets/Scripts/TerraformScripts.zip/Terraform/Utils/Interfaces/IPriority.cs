﻿
/// <summary>
/// interface that defines a function for returning a priority value. 
/// </summary>
public interface IPriority
{
    int Priority();
}