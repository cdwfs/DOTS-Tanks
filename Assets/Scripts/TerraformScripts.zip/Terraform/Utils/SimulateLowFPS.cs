﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimulateLowFPS : MonoBehaviour
{
    [SerializeField] public int FrameRate = 30;
    void Awake()
    {
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = FrameRate;
    }
}
