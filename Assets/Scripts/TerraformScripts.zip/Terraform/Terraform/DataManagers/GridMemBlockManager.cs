﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using MemoryUtils;
using System;

namespace Terraform
{
    /// <summary>
    /// references a block of memory of tower link data for a grid, and the index data that maps out the towers in that grid. 
    /// </summary>
    public struct GridMemData
    {
        public static readonly GridMemData NULL = new GridMemData() { linkData = MemoryBlock<TowerLinkData>.NULL, indexData = MemoryBlockFixed<ushort>.NULL };

        public NativeSlice<TowerLinkData> linkData;     // entire collection of tower link data for a grid. 
        public NativeSlice<ushort> indexData;           // data that maps out the starting data index for each tower in the link data. 
        
        public bool IsNull
        {
            get
            {
                return (linkData.Length == 0);
            }
        }

        public bool IsCreated
        {
            get
            {
                return !IsNull;
            }
        }

        /// <summary>
        /// copies the passed link data into a new memory block for this grid memory data. Same for the index data that is passed. 
        /// if existing data is already present for the grid memory data then the memory is freed. 
        /// </summary>
        public void CopyIntoNew(in NativeSlice<TowerLinkData> copyLinkData, in NativeArray<ushort> copyIndexData, GridMemBlockManager memBlockManager)
        {
            if (IsCreated)
            {
                Free(memBlockManager);
            }
            
            this = memBlockManager.GetData(copyLinkData.Length);

            linkData.CopyFrom(copyLinkData);
            indexData.CopyFrom(copyIndexData);
        }

        public NativeSlice<TowerLinkData> GetTowerData(in int towerIndex)
        {
            int sIndex = indexData[towerIndex];
            int eIndex = towerIndex == (Settings.TowersPerChunk - 1) ? indexData[towerIndex] : indexData[towerIndex + 1];
            
            return new NativeSlice<TowerLinkData>(linkData, sIndex, GetNumLinksInTower(towerIndex));
        }

        public int GetNumLinksInTower(in int towerIndex)
        {
            int sIndex = indexData[towerIndex];
            int eIndex = towerIndex == (Settings.TowersPerChunk - 1) ? indexData[towerIndex] : indexData[towerIndex + 1];

            if (sIndex == eIndex)
            {
                return 1;
            }

            return eIndex - sIndex;
        }

        public void Free(GridMemBlockManager memBlockManager)
        {
            memBlockManager.PushData(ref this);
        }
    }

    public class GridMemBlockManager : SingletonBase<GridMemBlockManager>
    {
        DynMemoryBlock<TowerLinkData> towerDataBlock;
        DynMemoryBlockFixed<ushort> indexDataBlock;

        protected override void OnInit()
        {
            towerDataBlock = new DynMemoryBlock<TowerLinkData>(999999);
            indexDataBlock = new DynMemoryBlockFixed<ushort>(9999, Settings.TowersPerChunk);
        }

        public GridMemData GetData(in int size)
        {
            NativeSlice<TowerLinkData> linkData;
            NativeSlice<ushort> indexData;

            towerDataBlock.GetData(size, out linkData);
            indexDataBlock.GetData(out indexData);

            return new GridMemData()
            {
                linkData = linkData,
                indexData = indexData
            };
        }

        public void PushData(ref GridMemData data)
        {
            towerDataBlock.PushData(ref data.linkData);
            indexDataBlock.PushData(ref data.indexData);
        }
    }
}
