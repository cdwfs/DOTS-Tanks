﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using MemoryUtils;
using System;

namespace Terraform
{
    public class TowerLinkMemoryBlockManager : SingletonBase<TowerLinkMemoryBlockManager>
    {
        List<DynMemoryBlockFixed<TowerLinkData>> m_towerPools = new List<DynMemoryBlockFixed<TowerLinkData>>();

        protected override void OnInit()
        {
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(999999, 32));
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(4, 64));
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(4, 128));
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(4, 256));
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(4, 512));
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(4, 1024));
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(4, 2048));
            m_towerPools.Add(new DynMemoryBlockFixed<TowerLinkData>(4, 4096));
        }

        public bool GetTowerData(UInt16 linkCount, out NativeSlice<TowerLinkData> slice)
        {
            if (linkCount <= 32)
            {
                return m_towerPools[0].GetData(out slice);
            }
            if (linkCount <= 64)
            {
                return m_towerPools[1].GetData(out slice);
            }
            if (linkCount <= 128)
            {
                return m_towerPools[2].GetData(out slice);
            }
            if (linkCount <= 256)
            {
                return m_towerPools[3].GetData(out slice);
            }
            if (linkCount <= 512)
            {
                return m_towerPools[4].GetData(out slice);
            }
            if (linkCount <= 1024)
            {
                return m_towerPools[5].GetData(out slice);
            }
            if (linkCount <= 2048)
            {
                return m_towerPools[6].GetData(out slice);
            }
            if (linkCount <= 4096)
            {
                return m_towerPools[7].GetData(out slice);
            }
            else
            {
#if UNITY_EDITOR

                Debug.LogError("requested a tower size greater than that can be given. Max size is 4096, amounted requested was " + linkCount.ToString());

#endif
                return m_towerPools[7].GetData(out slice);  // return max slice pool as it is the best that can be given under the request. 
            }
        }

        public unsafe bool GetTowerData(UInt16 linkCount, out void* slicePtr)
        {
            NativeSlice<TowerLinkData> slice;
            if (GetTowerData(linkCount, out slice))
            {
                slicePtr = NativeSliceUnsafeUtility.GetUnsafePtr<TowerLinkData>(slice);
            }

            slicePtr = null;
            return false;
        }

        public bool PushTowerData(ref NativeSlice<TowerLinkData> slice)
        {
            int linkCount = slice.Length;
            switch (linkCount)
            {
                case 32:
                    return m_towerPools[0].PushData(ref slice);
                case 64:
                    return m_towerPools[1].PushData(ref slice);
                case 128:
                    return m_towerPools[2].PushData(ref slice);
                case 256:
                    return m_towerPools[3].PushData(ref slice);
                case 512:
                    return m_towerPools[4].PushData(ref slice);
                case 1024:
                    return m_towerPools[5].PushData(ref slice);
                case 2048:
                    return m_towerPools[6].PushData(ref slice);
                case 4096:
                    return m_towerPools[7].PushData(ref slice);
            }

            return false;
        }

        public NativeSlice<TowerLinkData> UpgradeTower(in NativeSlice<TowerLinkData> tower, in TowerLinkData[] link)
        {
            int poolIndex = GetPoolIndexForTowerSize(tower.Length);

            UInt16 maxTowerSize = (UInt16)(tower.Length * 2);
            NativeSlice<TowerLinkData> newTower;
            GetTowerData(maxTowerSize, out newTower);

            CopyTowerData(in tower, ref newTower, in link);

            return newTower;
        }

        int GetPoolIndexForTowerSize(int towerSize)
        {
            return 0;
        }

        void CopyTowerData(in NativeSlice<TowerLinkData> from, ref NativeSlice<TowerLinkData> to)
        {
            // copy data over
        }

        void CopyTowerData(in NativeSlice<TowerLinkData> from, ref NativeSlice<TowerLinkData> to, in TowerLinkData[] link)
        {
            // copy data over and add new link data
        }
    }
}
