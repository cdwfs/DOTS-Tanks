﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Collections;

namespace Terraform
{
    /// <summary>
    /// a manager to hold terra obj data hierarchies, and allow access to any loaded terra objs. 
    /// </summary>
    public class TerraformObjDataManager : SingletonBase<TerraformObjDataManager>
    {
        Dictionary<int, TerraformObjData> data;

        protected override void OnInit()
        {
        }

        public int loadedCount
        {
            get
            {
                return data.Count;
            }
        }

        public TerraformObjDataManager()
        {
            data = new Dictionary<int, TerraformObjData>();
        }

        public bool GetTerraObjData (in int id, out TerraformObjData tObj)
        {
            return data.TryGetValue(id, out tObj);
        }

        public bool CreateTerraformDataObj(in TerraformObjGenParams genParams, out TerraformObjData terrain)
        {
            data.Add(genParams.id, new TerraformObjData(in genParams));
            return data.TryGetValue(genParams.id, out terrain);
        }
    }
}
