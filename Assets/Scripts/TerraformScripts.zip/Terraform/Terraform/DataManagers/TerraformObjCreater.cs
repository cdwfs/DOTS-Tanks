﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;
using Terraform.Component;

namespace Terraform
{
    public struct TerraformObjCreaterRequest
    {
        public readonly ushort id;

        public TerraformObjCreaterRequest(ushort id)
        {
            this.id = id;
        }
    }

    /// <summary>
    /// currently a simple manager for gatekeeping the creating of a terra obj. 
    /// </summary>
    public class TerraformObjCreater : SingletonBase<TerraformObjCreater>
    {
        public Stack<TerraformObjCreaterRequest> genRequests = new Stack<TerraformObjCreaterRequest>(8);

        protected override void OnInit()
        {
        }

        void Update()
        {
            while (genRequests.Count != 0)
            {
                TerraformObjCreaterRequest genRequest = genRequests.Pop();

                Generate(genRequest);
            }
        }

        public void Generate(TerraformObjCreaterRequest request)
        {
            TerraformObjData tObjData;
            if (TerraformObjDataManager.Instance.GetTerraObjData(request.id, out tObjData))
            {
                World.Active.EntityManager.SetComponentData<TerraformObj>(tObjData.entity, new TerraformObj(tObjData.genParams));
            }
        }
    }
}
