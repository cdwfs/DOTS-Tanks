﻿
using System;
using Terraform.ECS.Systems;
using Terraform.Jobs;
using Unity.Entities;

namespace Terraform.LAM
{
    /// <summary>
    /// manages queues for lam cells that require generation requests, or LAMCells that have no trackers and are waiting to be culled. 
    /// </summary>
    public class PriorityQueue : SingletonBase<PriorityQueue>
    {
        PriorityLinkedList<Cell> createQueue = new PriorityLinkedList<Cell>();
        public PriorityLinkedList<Cell> cullQueue = new PriorityLinkedList<Cell>();
        
        public int createQueueCount
        {
            get
            {
                return createQueue.count;
            }
        }

        public int cullQueueCount
        {
            get
            {
                return cullQueue.count;
            }
        }

        private JobSystem jobQueue;
        
        protected override void OnInit()
        {
	        jobQueue = World.Active.GetOrCreateSystem<JobSystem>();
        }

        public void AddToCreateQueue(Cell cell)
        {
	        if (createQueue.count == 0)
	        {
		        enabled = true;
	        }

	        if (cell.priorityNode == null)
            {
                cell.AddToPriorityQueue(ref createQueue);
            }
            else if (cell.priorityNode.parent != createQueue)
            {
                cell.RemoveFromPriorityQueue();
                cell.AddToPriorityQueue(ref createQueue);
            }
        }

        public void AddToCullQueue(Cell cell)
        {
            if (cell.priorityNode == null)
            {
                cell.AddToPriorityQueue(ref cullQueue);
            }
            else if (cell.priorityNode.parent != cullQueue)
            {
                cell.RemoveFromPriorityQueue();
                cell.AddToPriorityQueue(ref cullQueue);
            }
        }

        public Cell PopCreateQueue()
        {
            if (createQueue.count == 0)
            {
                return null;
            }

            Cell cell = createQueue.PopFront();
            cell.ConsumeAllRequests();
            cell.RemoveFromPriorityQueue();

            if (createQueue.count == 0 && enabled)
            {
	            enabled = false;
            }
            
            return cell;
        }

        public Cell PopCullQueue()
        {
            if (cullQueue.count == 0)
            {
                return null;
            }

            Cell cell = cullQueue.PopFront();
            cell.Remove();

            return cell;
        }

        public bool IsInCreateQueue(ref PriorityLinkedList<Cell>.Node node)
        {
            if (node == null || node.parent == null)
            {
                return false;
            }

            return (node.parent == createQueue);
        }
        
        public bool IsInCullQueue(ref PriorityLinkedList<Cell>.Node node)
        {
            if (node == null || node.parent == null)
            {
                return false;
            }

            return (node.parent == cullQueue);
        }

        public Cell PeekCullQueue()
        {
            return cullQueue.PeekFront();
        }

        public Cell PeekCreateQueue()
        {
            return createQueue.PeekFront();
        }

        private void Update()
        {
	        const int feedCellsPerFrame = 10;
	        int cellsToFeed = feedCellsPerFrame;

	        while (cellsToFeed > 0 && createQueue.count > 0)
	        {
		        var lamCell = PopCreateQueue();
		        jobQueue.AddGenerationCell(lamCell);
		        --cellsToFeed;
	        }
        }
    }
}