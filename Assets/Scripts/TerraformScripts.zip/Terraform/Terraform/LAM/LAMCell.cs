﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using Unity.Entities;
using Unity.Transforms;
using UnityEngine;

namespace Terraform.LAM
{
    public enum CellGenFlags
    {
        DataGen,
        RenderGen,
        CollisionGen,

        Count
    }

    /// <summary>
    /// defines desired state of a chunk within the terraObj a lam is representing. 
    /// </summary>
    public class Cell : IPriority
    {
        public readonly LAM parent;
        public readonly ChunkData chunk;
        public ChunkCoord coord { get { return chunk.coord; } }

        public PriorityLinkedList<Cell>.Node priorityNode;                   

        HashSet<TrackerEntry> trackers = new HashSet<TrackerEntry>();  // which trackers are currently effecting this lam cell.
        public int priority;                            // lower the value the higher the priority. in a create queue the priority is based chunk distance. In a cull queue the priority is based on framecount. 
        BitVector32 flags;
        
        static BitVector32.Section requests;            // flags for things that are requested to be generated. 
        static BitVector32.Section consumedRequests;    // tells us which of the flags in the request have been consumed.

        static Cell()
        {
            requests = BitVector32.CreateSection((short)CellGenFlags.Count);
            consumedRequests = BitVector32.CreateSection((short)CellGenFlags.Count, requests);
        }

        public Cell(ChunkData chunk, LAM parent, int priority = int.MaxValue)
        {
            this.chunk = chunk;
            this.parent = parent;
            this.priority = priority;
        }

        // updates the cells priority and requests based on the trackers it has as references. 
        public void UpdateCell()
        {
            if (IsDead())
            {
                priority = Time.frameCount; // this way the oldest chunks on the priority queue cull first, and the youngest cull last.

                if (!PriorityQueue.Instance.IsInCullQueue(ref priorityNode))
                {
                    RemoveFromPriorityQueue();
                    PriorityQueue.Instance.AddToCullQueue(this);
                }
                else
                {
                    priorityNode.Sort();
                }
            }
            else
            {
                priority = int.MaxValue;

                foreach (TrackerEntry entry in trackers)
                {
                    int val = Mathf.FloorToInt((coord - entry.pos).magnitude);
                    if (val < priority)
                    {
                        priority = val;
                    }
                }

                SetRequest(CellGenFlags.DataGen, true);
                SetRequest(CellGenFlags.RenderGen, true);
                SetRequest(CellGenFlags.CollisionGen, true);

                if (!PriorityQueue.Instance.IsInCreateQueue(ref priorityNode))
                {
                    RemoveFromPriorityQueue();
                }

                if (!InPriorityQueue())
                {
                    // if we have non consumed gen requests then add to queue
                    if (HasRequestsToConsume())
                    {
                        RemoveFromPriorityQueue();
                        PriorityQueue.Instance.AddToCreateQueue(this);
                    }
                }
                else
                {
                    priorityNode.Sort();
                }
            }
        }

        public void AddTracker(TrackerEntry tracker)
        {
            trackers.Add(tracker);
        }

        public void RemoveTracker(TrackerEntry tracker)
        {
            trackers.Remove(tracker);
        }

        public bool SetRequest(in CellGenFlags flag, in bool val)
        {
            return flags[1 << (requests.Offset + (int)flag)] = val;
        }

        public bool GetRequest(in CellGenFlags flag)
        {
            return flags[1 << (requests.Offset + (int)flag)];
        }

        public bool HasRequestsToConsume()
        {
            for (CellGenFlags i = 0; i < CellGenFlags.Count; ++i)
            {
                if (GetRequest(i) && !IsRequestConsumed(i))
                {
                    return true;
                }
            }

            return false;
        }

        public bool IsRequestConsumed(in CellGenFlags flag)
        {
            return flags[1 << (consumedRequests.Offset + (int)flag)];
        }

        public bool ConsumeRequest(in CellGenFlags flag)
        {
            // cannot consume a request that has not been made or is no longer valid. 
            if (!GetRequest(flag))
            {
                return false;
            }

            flags[1 << (consumedRequests.Offset + (int)flag)] = true;

            return true;
        }
        
        public void ConsumeAllRequests()
        {
            for (CellGenFlags i = 0; i < CellGenFlags.Count; ++i)
            {
                ConsumeRequest(i);
            }
        }

        /// <summary>
        /// lam cell is considered dead when it no longer has a use e.g. no trackers are referencing it. 
        /// </summary>
        public bool IsDead()
        {
            return (trackers.Count == 0);
        }

        public void AddToPriorityQueue(ref PriorityLinkedList<Cell> linkedList)
        {
            if (InPriorityQueue())
            {
                return;
            }

            priorityNode = linkedList.Insert(this);
        }

        public void RemoveFromPriorityQueue()
        {
            if (InPriorityQueue())
            {
                priorityNode.Remove();
                priorityNode = null;
            }
        }

        public bool InPriorityQueue()
        {
            return (priorityNode != null);
        }

        public void Remove()
        {
            RemoveFromPriorityQueue();
            parent.cells.Remove(Utils.HashChunkCoord(coord));
        }

        public int Priority()
        {
            return priority;
        }
    }
}
