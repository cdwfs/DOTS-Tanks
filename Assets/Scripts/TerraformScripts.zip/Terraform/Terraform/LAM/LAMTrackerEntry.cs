﻿using System.Collections.Generic;
using UnityEngine;
using Terraform.Component;

namespace Terraform.LAM
{
    /// <summary>
    /// this exist within a LAM and track which trackers are registered to which LAM cells.
    /// </summary>
    public class TrackerEntry
    {
        public ChunkCoord pos;
        public ChunkAreaInc area;

        private int _cellRefCount;
        public int cellRefCount { get { return _cellRefCount; } }
        public Cell[] cells;

        public TrackerEntry(in LAMTracker tracker, in ChunkCoord pos)
        {
            this.pos = pos;

            ChunkCoord min = pos - new ChunkCoord(tracker.areaSize, tracker.areaSize);
            ChunkCoord max = pos + new ChunkCoord(tracker.areaSize, tracker.areaSize);
            area = new ChunkAreaInc(min, max);

            _cellRefCount = 0;
            cells = new Cell[area.size];
        }

        public bool AddCellRef(ref Cell cell)
        {
            if (_cellRefCount == cells.Length)
            {
                return false;
            }

            cell.AddTracker(this);
            cells[_cellRefCount] = cell;
            ++_cellRefCount;

            return true;
        }

        public bool RemoveCellRef(ref Cell cell)
        {
            for (int i = 0; i < _cellRefCount; ++i)
            {
                if (cells[i] == cell)
                {
                    return RemoveCellRef(i);
                }
            }

            return false;
        }

        public bool RemoveCellRef(in int index)
        {
#if UNITY_EDITOR

            if (index > _cellRefCount - 1)
            {
                Debug.LogError("attempting to remove cell ref within LAMTrackerEntry at invalid index. index - " + index + " .max index available - " + (_cellRefCount - 1));
                return false;
            }

#endif

            Cell cell = cells[index];

            // remove and shuffle the referenced cells so there are no gaps. 
            int maxIndex = _cellRefCount - 1;
            cells[index] = cells[maxIndex];
            cells[maxIndex] = null;

            --_cellRefCount;

            // remove references from cell removed.
            cell.RemoveTracker(this);

            return true;
        }

        public void Clear()
        {
            for (int i = 0; i < _cellRefCount; ++i)
            {
                cells[i].RemoveTracker(this);
            }

            _cellRefCount = 0;
        }

        /// <summary>
        /// clears. but also adds to an update set used in the LAM when updating cells.
        /// </summary>
        public void Clear(ref HashSet<Cell> updateSet)
        {
            for (int i = 0; i < _cellRefCount; ++i)
            {
                cells[i].RemoveTracker(this);
                updateSet.Add(cells[i]);
            }

            _cellRefCount = 0;
        }
    }
}