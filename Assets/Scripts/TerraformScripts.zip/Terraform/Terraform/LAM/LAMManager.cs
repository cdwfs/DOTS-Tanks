﻿using System.Collections.Generic;
using Unity.Entities;
using Unity.Transforms;
using Terraform.Component;

namespace Terraform.LAM
{
    public class Manager : SingletonBase<Manager>
    {
        public Dictionary<ushort, LAM> lams = new Dictionary<ushort, LAM>(4);  // key is terraform obj id. 

        protected override void OnInit()
        {
        }

        public void GetOrCreateLAM(in TerraformObjGenParams terra, out LAM lam)
        {
            if (!lams.TryGetValue(terra.id, out lam))
            {
                if (TerraformObjDataManager.Instance.GetTerraObjData(terra.id, out TerraformObjData tData))
                {
                    lam = new LAM(tData);
                    lams.Add(terra.id, lam);
                }
            }
        }

        public void UpdateLAMs(in EntityQueryBuilder entities)
        {
            EntityQueryBuilder trackerQB = entities.WithAll<LAMTracker, Translation>();
            EntityQuery trackerQ = trackerQB.ToEntityQuery();

            entities.ForEach((ref TerraformObj terraObj, ref Translation terraTrans) =>
            {
                LAM lam;
                GetOrCreateLAM(terraObj.tParams, out lam);

                lam.UpdateLAM(terraObj, terraTrans.Value);
                lam.UpdateTrackers(trackerQ);
            });
        }
    }
}
