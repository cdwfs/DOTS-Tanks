﻿using System;
using System.Collections.Generic;
using Terraform.Jobs;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using Terraform.Component;
using Terraform.ECS.Systems;

namespace Terraform.LAM
{
    /// <summary>
    /// defines play areas within an active terraObj, with priority values for each chunk of the play area. There should only be 1 LAM per terrain, and multiple LAM trackers can be managed from that 1 LAM.
    /// </summary>
    public class LAM
    {
        public readonly TerraformObjData terraData;
        public float3 terraObjPos;

        public Dictionary<ushort, TrackerEntry> trackers = new Dictionary<ushort, TrackerEntry>(32);      // key is the unique id stored in a LAMTracker component.
        public Dictionary<Int64, Cell> cells = new Dictionary<Int64, Cell>(1024);                         // key is TerraformUtils.HashChunkCoords()  

        public LAM(TerraformObjData terraData)
        {
            this.terraData = terraData;
        }

        public void UpdateLAM(in TerraformObj terraObj, in float3 terraObjPos)
        {
            this.terraObjPos = terraObjPos;
        }

        public void UpdateTrackers(in EntityQuery trackerQuery)
        {
            HashSet<Cell> updateSet = new HashSet<Cell>();
            HashSet<ushort> trackersActive = new HashSet<ushort>();

            NativeArray<LAMTracker> lamTrackers = trackerQuery.ToComponentDataArray<LAMTracker>(Allocator.TempJob);
            NativeArray<Translation> trackerTrans = trackerQuery.ToComponentDataArray<Translation>(Allocator.TempJob);

            // update trackers, and if they have moved they can recalculate themselves, and push cells into the updateSet.
            for (int i = 0; i < lamTrackers.Length; ++i)
            {
                trackersActive.Add(lamTrackers[i].id);
                float3 position = trackerTrans[i].Value;
                UpdateTracker(lamTrackers[i], position, in terraObjPos, ref updateSet);
            }

            lamTrackers.Dispose();
            trackerTrans.Dispose();

            Stack<KeyValuePair<ushort, TrackerEntry>> cullTrackers = new Stack<KeyValuePair<ushort, TrackerEntry>>();

            // for any trackers that are not active we need to remove there entry and there references to cells.
            foreach (KeyValuePair<ushort, TrackerEntry> entry in trackers)
            {
                if (!trackersActive.Contains(entry.Key))
                {
                    cullTrackers.Push(entry);
                }
            }

            while(cullTrackers.Count != 0)
            {
                CullTracker(cullTrackers.Pop(), ref updateSet);
            }

            // loop through the updateSet and update the state of any cells within them.
            UpdateCells(ref updateSet);
        }

        private void UpdateTracker(in LAMTracker tracker, in float3 trackerPos, in float3 terraObjPos, ref HashSet<Cell> updateSet)
        {
            ChunkCoord trackerCnkPos = Utils.CalcOccupyingChunk(trackerPos, terraObjPos);
            
            // check to see if the tracker exists as an entry. else add it as one.
            if (trackers.TryGetValue(tracker.id, out TrackerEntry entry))
            {
                // if the track has moved then we need to update the play area it defines. 
                if (trackerCnkPos != entry.pos)
                {
                    ChunkCoord newMin = trackerCnkPos - new ChunkCoord(tracker.areaSize, tracker.areaSize);
                    ChunkCoord newMax = trackerCnkPos + new ChunkCoord(tracker.areaSize, tracker.areaSize);
                    ChunkAreaInc newArea = new ChunkAreaInc(newMin, newMax);

                    ChunkAreaInc overlap = entry.area & newArea;    // the overlap defines chunk spaces that are shared between the old and the new areas.
                    
                    // add all cells of the old area to the update set.
                    for (int i = 0; i < entry.cellRefCount; ++i)
                    {
                        updateSet.Add(entry.cells[i]);
                    }

                    // loop through old area and remove references to cells that are not part of the new area.
                    Stack<int> cellsToRemove = new Stack<int>();

                    for (int i = 0; i < entry.cellRefCount; ++i)
                    {
                        Cell cell = entry.cells[i];
                        if (!overlap.Contains(cell.coord))
                        {
                            cellsToRemove.Push(i);
                            updateSet.Add(cell);
                        }
                    }

                    while (cellsToRemove.Count != 0)
                    {
                        entry.RemoveCellRef(cellsToRemove.Pop());
                    }

                    // loop through new area and add references to cells that are part of the new area and not the old.
                    for (int z = newArea.min.z; z <= newArea.max.z; ++z)
                    {
                        for (int x = newArea.min.x; x <= newArea.max.x; ++x)
                        {
                            ChunkCoord coord = new ChunkCoord(x, z);
                            if (!overlap.Contains(coord))
                            {
                                AddCellRef(coord, ref entry, ref updateSet);
                            }
                        }
                    }

                    // update entry with new info.
                    entry.area = newArea;
                    entry.pos = trackerCnkPos;
                }
            }
            else
            {
                entry = new TrackerEntry(tracker, trackerCnkPos);
                trackers.Add(tracker.id, entry);

                for (int z = entry.area.min.z; z <= entry.area.max.z; ++z)
                {
                    for (int x = entry.area.min.x; x <= entry.area.max.x; ++x)
                    {
                        ChunkCoord coord = new ChunkCoord(x, z);

                        AddCellRef(coord, ref entry, ref updateSet);
                    }
                }
            }
        }

        private void AddCellRef(in ChunkCoord coord, ref TrackerEntry entry, ref HashSet<Cell> updateSet)
        {
            if (!terraData.genParams.IsChunkCoordValid(coord))
            {
                return;
            }

            Cell cell;

            // if we cannot find the existing cell then add it.
            if (!cells.TryGetValue(Utils.HashChunkCoord(coord), out cell))
            {
                cell = new Cell(terraData.GetOrCreateChunkDataRef(coord), this);
                cells.Add(Utils.HashChunkCoord(coord), cell);
            }

            entry.AddCellRef(ref cell);
            updateSet.Add(cell);
        }

        private void CullTracker(in KeyValuePair<ushort, TrackerEntry> entry, ref HashSet<Cell> updateSet)
        {
            entry.Value.Clear(ref updateSet);

            trackers.Remove(entry.Key);
        }

        private void UpdateCells(ref HashSet<Cell> updateSet)
        {
            foreach (Cell cell in updateSet)
            {
                {
                    cell.UpdateCell();
                }
            }

            if (updateSet.Count > 0)
            {
	            World.Active.GetOrCreateSystem<JobSystem>().LamsUpdated();   
            }
        }
    }
}
