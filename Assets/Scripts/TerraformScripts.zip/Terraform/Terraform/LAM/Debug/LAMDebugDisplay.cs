﻿using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;

#if UNITY_EDITOR

namespace Terraform.LAM
{
    public class LAMDebugDisplay : MonoBehaviour
    {
	    public bool drawCells = false;
        public bool drawTrackers = false;
        public bool drawPriority = false;
        public bool drawCoords = false;
        public bool drawCullQueue = false;

        private void OnDrawGizmos()
        {
	        if (drawCells)
	        {
		        var chunkSize = new float2(Settings.ChunkSpacingX, Settings.ChunkSpacingZ);
                foreach (KeyValuePair<ushort, LAM> lam in Manager.Instance.lams)
                {
	                foreach (KeyValuePair<ushort, TrackerEntry> tracker in lam.Value.trackers)
	                {
		                float2 lamMin = Utils.chunkCoordToWorldSpace(tracker.Value.area.min);
		                float2 lamMax = Utils.chunkCoordToWorldSpace(tracker.Value.area.max) + chunkSize;

		                // X-Axis
		                float z = lamMin.y;
		                int zSize = tracker.Value.area.max.z - tracker.Value.area.min.z + 1;
		                for (int i = 0; i <= zSize; ++i)
		                {
			                var p0 = new Vector3(lamMin.x, 0.0f, z);
			                var p1 = new Vector3(lamMax.x, 0.0f, z);
			                Debug.DrawLine(p0, p1, Color.yellow);
			                z += Settings.ChunkSpacingZ;
		                }
                        
		                // Z-Axis
		                float x = lamMin.x;
		                int xSize = tracker.Value.area.max.x - tracker.Value.area.min.x + 1;
		                for (int i = 0; i <= xSize; ++i)
		                {
			                var p0 = new Vector3(x, 0.0f, lamMin.y);
			                var p1 = new Vector3(x, 0.0f, lamMax.y);
			                Debug.DrawLine(p0, p1, Color.yellow);
			                x += Settings.ChunkSpacingX;
		                }
	                }
                }
            }
            if (drawTrackers)
            {
                foreach (KeyValuePair<ushort, LAM> lam in Manager.Instance.lams)
                {
                    foreach (KeyValuePair<ushort, TrackerEntry> tracker in lam.Value.trackers)
                    {
                        float2 min = Utils.chunkCoordToWorldSpace(tracker.Value.pos);
                        float2 max = min + new float2(Settings.ChunkSpacingX, Settings.ChunkSpacingZ);

                        /*
                         *      p0----------p1
                         *      |           |
                         *      |           |
                         *      |           |
                         *      p2----------p3
                         */
                        Vector3 p0 = new Vector3(min.x, 0.1f, max.y);
                        Vector3 p1 = new Vector3(max.x, 0.1f, max.y);
                        Vector3 p2 = new Vector3(min.x, 0.1f, min.y);
                        Vector3 p3 = new Vector3(max.x, 0.1f, min.y);

                        Debug.DrawLine(p0, p2, Color.blue);
                        Debug.DrawLine(p0, p1, Color.blue);
                        Debug.DrawLine(p1, p3, Color.blue);
                        Debug.DrawLine(p3, p2, Color.blue);
                    }
                }
            }

            if (drawPriority)
            {
                foreach (KeyValuePair<ushort, LAM> lam in Manager.Instance.lams)
                {
                    foreach (KeyValuePair<Int64, Cell> cell in lam.Value.cells)
                    {
                        float2 min = Utils.chunkCoordToWorldSpace(cell.Value.coord);
                        float2 max = min + new float2(Settings.ChunkSpacingX, Settings.ChunkSpacingZ);
                        float2 centre = math.lerp(min, max, 0.5f);

                        Vector3 pri1 = new Vector3(centre.x, 0.0f, centre.y);
                        Vector3 pri2 = new Vector3(centre.x, cell.Value.priority, centre.y);
                        Debug.DrawLine(pri1, pri2, Color.magenta);
                    }
                }
            }
            
	        if (drawCoords)
	        {
		        var halfChunk = new float2(Settings.ChunkSpacingX / 2.0f, Settings.ChunkSpacingZ / 2.0f);
		        foreach (var lam in Manager.Instance.lams)
		        {
			        foreach (var cell in lam.Value.cells)
			        {
				        var xz = Utils.chunkCoordToWorldSpace(cell.Value.chunk.coord) + halfChunk;

				        string coord = $"{cell.Value.chunk.coord.x},{cell.Value.chunk.coord.z}";
				        Handles.Label(new Vector3(xz.x, 0.0f, xz.y), coord);
			        }
		        }
	        }

	        if (drawCullQueue)
	        {
		        PriorityLinkedList<Cell>.Node node = PriorityQueue.Instance.cullQueue.front;

		        for (; node != null; node = node.next)
		        {
			        float2 min = Utils.chunkCoordToWorldSpace(node.val.coord);
			        float2 max = min + new float2(Settings.ChunkSpacingX, Settings.ChunkSpacingZ);
			        float2 centre = math.lerp(min, max, 0.5f);

			        Vector3 pri1 = new Vector3(centre.x, 0.0f, centre.y);
			        Vector3 pri2 = new Vector3(centre.x, node.val.priority, centre.y);
			        Debug.DrawLine(pri1, pri2, Color.magenta);
		        }
	        }
        }
    }
}

#endif