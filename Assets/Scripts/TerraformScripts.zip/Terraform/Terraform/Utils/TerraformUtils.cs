﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Unity.Mathematics;

namespace Terraform
{
    public static class Utils
    {
        public static Int64 HashChunkCoord(in ChunkCoord coords)
        {
            Int64 x = coords.x;
            Int64 z = coords.z;
            Int64 hash = x + (z << 32);
            return hash;
        }

        /// <summary>
        /// for terraformObj entities that are assumed to have there orientation locked.
        /// </summary>
        public static ChunkCoord CalcOccupyingChunk(in float3 pos, in float3 terraformObjPos)
        {
            float3 val = pos - terraformObjPos;
            return new ChunkCoord(Mathf.FloorToInt(val.x / Settings.ChunkSpacingX), Mathf.FloorToInt(val.z / Settings.ChunkSpacingZ));
        }

        public static float2 chunkCoordToWorldSpace(in ChunkCoord coord)
        {
            return new float2(coord.x * Settings.ChunkSpacingX, coord.z * Settings.ChunkSpacingZ);
        }
    }
}
