﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Terraform
{
    public struct TerraformObjGenParams
    {
        static ushort idCount = 0;

        public readonly int length;
        public readonly int width;
        public readonly ushort id;
        
        public TerraformObjGenParams(int length, int width)
        {
            this.id = ++idCount;
            this.length = length;
            this.width = width;
        }

        public bool IsChunkCoordValid(in ChunkCoord coord)
        {
            return true;
//            int halfW = width >> 1;
//            int halfL = length >> 1;
//
//            return (coord.x >= -halfL && coord.x <= halfL && coord.z >= -halfW && coord.z <= halfW);
        }
    }
}
