﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Terraform
{
    public struct ChunkGenParams
    {
        public readonly ChunkCoord coords;

        public ChunkGenParams(in ChunkCoord coords)
        {
            this.coords = coords;
        }
    }
}
