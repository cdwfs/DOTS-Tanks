﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Collections;
using Unity.Collections.LowLevel;
using Unity.Collections.LowLevel.Unsafe;
using System;
using Unity.Entities;

namespace Terraform
{
    public static class GenerationUtils
    {
        public static void GenerateChunk(in ChunkGenParams genParams, ref ChunkData chunk)
        {
            // old implementation
            //chunk.grid = new TowerGridData(Settings.ChunkWidth, Settings.ChunkDepth);

            // new implementation.
            chunk.grid = new TowerGridData();

            chunk.grid.towerData = GridMemBlockManager.Instance.GetData(Settings.TowersPerChunk);   // currently 1 link data per tower for testing.
            
            for (int z = 0; z < Settings.ChunkWidth; ++z)
            {
                for (int x = 0; x < Settings.ChunkWidth; ++x)
                {
                    int index = (z * Settings.ChunkWidth) + x;
                    UInt16 towerLength = 32;

                    TowerData tData = new TowerData();

                    float seed = 465.354f;
                    float pnX = ((genParams.coords.x * Settings.ChunkWidth) + x) / 16.0f;
                    float pnZ = ((genParams.coords.z * Settings.ChunkWidth) + z) / 16.0f;
                    float noise = Mathf.PerlinNoise(pnX, pnZ);

                    // new implementation.
                    chunk.grid.towerData.indexData[index] = (ushort)index;
                    chunk.grid.towerData.linkData[index] = new TowerLinkData((int)(16 + (noise * 16)));

                    // old implementation.
                    //TowerLinkMemoryBlockManager.Instance.GetTowerData(towerLength, out tData.linkData);
                    //tData.numLinks = 1; // all empty
                    //tData.linkData[0] = new TowerLinkData((int)(16 + (noise * 16)));
                    //chunk.grid.towers[index] = tData;
                }
            }
        }
    }
}
