﻿using System;

namespace Terraform
{
    class Settings
    {
        public const float GameScale = 8; // World is 100 times bigger than real LEGO
        public const float additionYScale = 0.5f;
        public const int ChunkWidth = 32;
        public const int ChunkDepth = 32;
        public const int TowersPerChunk = ChunkWidth * ChunkDepth;
        public const float ChunkSpacingX = BrickWidth * ChunkWidth;
        public const float ChunkSpacingZ = BrickDepth * ChunkDepth;
        public const float BrickWidth = 0.08f * GameScale;
        public const float BrickDepth = BrickWidth;
        public const float BrickPlateHeight = 0.032f * GameScale * additionYScale;
        public const float BrickHeight = BrickPlateHeight * 3.0f;
        public const float DefaultLinksPerTower = 32;
    }
}
