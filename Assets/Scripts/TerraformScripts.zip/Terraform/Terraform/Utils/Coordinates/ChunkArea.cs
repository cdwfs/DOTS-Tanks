﻿
namespace Terraform
{
    /// <summary>
    ///  defines a chunk area inclusively. Which means it is not possible to have an area that represents nothing. As even an area where min == max will still include the chunk space of min/max.
    /// </summary>
    public struct ChunkAreaInc
    {
        public static readonly ChunkAreaInc Zero = new ChunkAreaInc(ChunkCoord.Zero, ChunkCoord.Zero);
        public static readonly ChunkAreaInc Null = new ChunkAreaInc() { _min = new ChunkCoord(int.MaxValue, int.MaxValue), _max = new ChunkCoord(int.MinValue, int.MinValue) };

        private ChunkCoord _min;
        public ChunkCoord min { get { return _min; } }

        private ChunkCoord _max;
        public ChunkCoord max { get { return _max; } }

        public readonly int size;

        public ChunkAreaInc(in ChunkCoord min, in ChunkCoord max)
        {
            if (min > max)
            {
                this._min = max;
                this._max = min;
            }
            else
            {
                this._min = min;
                this._max = max;
            }

            this.size = (_max.x - _min.x + 1) * (_max.z - _min.z + 1); // add 1 as in a situation of min == max the size would still be 1.
        }

        public bool Contains(in ChunkCoord coord)
        {
            if (coord.x >= min.x && coord.x <= max.x &&
                coord.z >= min.z && coord.z <= max.z)
            {
                return true;
            }

            return false;
        }

        public static bool Overlap(in ChunkAreaInc a, in ChunkAreaInc b)
        {
            if (a.max.x >= b.min.x && a.max.x <= b.max.x &&
                a.max.z >= b.min.z && a.max.z <= b.max.z)
            {
                return true;
            }

            if (a.min.x >= b.min.x && a.min.x <= b.max.x &&
                a.min.z >= b.min.z && a.min.z <= b.max.z)
            {
                return true;
            }

            return false;
        }

        public static ChunkCoord[] operator -(in ChunkAreaInc a, in ChunkAreaInc b)
        {
            ChunkAreaInc overlap = a & b;

            int count = a.size - overlap.size;
            if (count <= 0)
            {
                return new ChunkCoord[0];
            }

            ChunkCoord[] coords = new ChunkCoord[count];

            int index = 0;
            for (int z = a.min.z; z <= a.max.z; ++z)
            {
                for (int x = a.min.x; z <= a.max.x; ++x)
                {
                    ChunkCoord coord = new ChunkCoord(x, z);
                    if (!b.Contains(coord))
                    {
                        coords[index] = coord;
                    }

                    ++index;
                }
            }

            return coords;
        }

        public static ChunkAreaInc operator &(in ChunkAreaInc a, in ChunkAreaInc b)
        {
            if (!Overlap(a, b))
            {
                return ChunkAreaInc.Null;
            }

            ChunkCoord min = new ChunkCoord()
            {
                x = a.min.x >= b.min.x ? a.min.x : b.min.x,
                z = a.min.z >= b.min.z ? a.min.z : b.min.z
            };

            ChunkCoord max = new ChunkCoord()
            {
                x = a.max.x <= b.max.x ? a.max.x : b.max.x,
                z = a.max.z <= b.max.z ? a.max.z : b.max.z
            };

            return new ChunkAreaInc(min, max);
        }

        public static bool operator ==(in ChunkAreaInc a, in ChunkAreaInc b)
        {
            return (a.min == b.min && a.max == b.max);
        }

        public static bool operator !=(in ChunkAreaInc a, in ChunkAreaInc b)
        {
            return (a.min != b.min || a.max != b.max);
        }
    }
}
