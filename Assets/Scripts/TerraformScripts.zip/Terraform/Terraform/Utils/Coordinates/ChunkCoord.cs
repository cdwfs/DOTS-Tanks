﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace Terraform
{
    public struct ChunkCoord
    {
        public static readonly ChunkCoord Zero = new ChunkCoord(0, 0);
        public static readonly ChunkCoord Null = new ChunkCoord(int.MinValue, int.MinValue);

        public int x;
        public int z;

        public float magnitude
        {
            get
            {
                return Mathf.Sqrt((x * x) + (z * z));
            }
        }

        public ChunkCoord(int x, int z)
        {
            this.x = x;
            this.z = z;
        }

        public static ChunkCoord operator+ (ChunkCoord a, ChunkCoord b)
        {
            return new ChunkCoord(a.x + b.x, a.z + b.z);
        }
        
        public static ChunkCoord operator -(ChunkCoord a, ChunkCoord b)
        {
            return new ChunkCoord(a.x - b.x, a.z - b.z);
        }

        public static bool operator ==(ChunkCoord a, ChunkCoord b)
        {
            return (a.x == b.x && a.z == b.z);
        }

        public static bool operator !=(ChunkCoord a, ChunkCoord b)
        {
            return (a.x != b.x || a.z != b.z);
        }

        public static bool operator <(ChunkCoord a, ChunkCoord b)
        {
            return (a.x < b.x && a.z <= b.z) || (a.x <= b.x && a.z < b.z);
        }

        public static bool operator >(ChunkCoord a, ChunkCoord b)
        {
            return (a.x > b.x && a.z >= b.z) || (a.x >= b.x && a.z > b.z);
        }

        public static bool operator >=(ChunkCoord a, ChunkCoord b)
        {
            return (a.x >= b.x && a.z >= b.z);
        }

        public static bool operator <=(ChunkCoord a, ChunkCoord b)
        {
            return (a.x <= b.x && a.z <= b.z);
        }
    }
}