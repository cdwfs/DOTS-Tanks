﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Terraform.ECS.Systems;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using UnityEngine;
using UnityEngine.Profiling;

namespace Terraform.Jobs
{
	public class JobHolder
	{
		public bool CanStartNow()
		{
			if (dependencies == null)
			{
				return true;
			}

			for (int i = 0; i < dependencies.Count; ++i)
			{
				// Separating for possible code coverage tests in the future
				if (!dependencies[i].IsScheduled)
				{
					return false;
				}

				if (!dependencies[i].IsFinished() && shouldBlockIfNotFinished)
				{
					return false;
				}
			}
			
			return true;
		}

		public bool IsScheduled { get; private set; }

		public bool IsFinished()
		{
			return IsScheduled && scheduledJob.IsCompleted;
		}

		public void AddDependency(JobHolder job)
		{
			if (job == null)
			{
				return;
			}

			if (dependencies == null)
			{
				dependencies = new List<JobHolder>();
			}

			dependencies.Add(job);
		}

		private JobHandle GetDependencies()
		{
			var jobHandle = new JobHandle();

			if (dependencies == null)
			{
				return jobHandle;
			}
			
			if (!CanStartNow())
			{
				Debug.LogError("Attempting to create dependency JobHandle for unscheduled jobs");
				Debug.LogException(new InvalidOperationException());
			}
			
			for (int i = 0; i < dependencies.Count; ++i)
			{
				jobHandle = JobHandle.CombineDependencies(jobHandle, dependencies[i].scheduledJob);
			}

			return jobHandle;
		}

		public static JobHolder GetDependentJobToRun(JobHolder srcJob)
		{
			foreach (var job in srcJob.dependencies)
			{
				if (job.IsScheduled)
				{
					continue;
				}

				if (job.CanStartNow())
				{
					return job;						
				}

				var dependentJob = GetDependentJobToRun(job);
				if (dependentJob != null)
				{
					return dependentJob;					
				}
			}
			
			return null;
		}

		public JobHandle Schedule(JobHandle externalDependencies = new JobHandle())
		{
			scheduledJob = ScheduleJob(this, JobHandle.CombineDependencies(GetDependencies(), externalDependencies));
			IsScheduled = true;

            parentRequest.chunkData.genJobHndls.Add(scheduledJob);

			return scheduledJob;
		}

		public JobFactory.GenerationRequest parentRequest;
		public GenerationStage jobStage;
		public JobHandle scheduledJob;

		private List<JobHolder> dependencies = null;
		public bool shouldBlockIfNotFinished = false; // intend to use with file i/o (data load job)

		public bool hasGenerationWorld = false;
		public World generationWorld;

		private static JobHandle ScheduleJob(JobHolder jobDefinition, JobHandle dependancies)
		{
			switch (jobDefinition.jobStage)
			{
				case GenerationStage.HeightMap:
				{
					jobDefinition.parentRequest.chunkData.heightMap = new NativeArray<float>(Settings.ChunkWidth * Settings.ChunkDepth, Allocator.Persistent);
					var job = new HeightMapJob
					{
						chunkWidth = Settings.ChunkWidth,
						chunkDepth = Settings.ChunkDepth,
						chunkCoord = jobDefinition.parentRequest.chunkData.coord,
						heightMap = jobDefinition.parentRequest.chunkData.heightMap
					};

					return job.Schedule(Settings.ChunkWidth * Settings.ChunkDepth, Settings.ChunkWidth, dependancies);
				}

				case GenerationStage.Composition:
				{
					jobDefinition.parentRequest.chunkData.grid = new TowerGridData();
					//jobDefinition.parentRequest.chunkData.grid.towerData = GridMemBlockManager.Instance.GetData(1024); // allocating outside because doing so inside job is failing.

					//var job = new CompositionJob
					//{
					//    chunkWidth = Settings.ChunkWidth,
					//    chunkDepth = Settings.ChunkDepth,
					//    heightMap = jobDefinition.parentRequest.chunkData.heightMap,
					//    gridData = jobDefinition.parentRequest.chunkData.grid,
					//    towerMemAllocatorHandle =
					//        GCHandle.Alloc(TowerLinkMemoryBlockManager.Instance,
					//            GCHandleType
					//                .Pinned) // hopefully the fact this is a singleton means we can pin it without much penalty
					//};

					var job = new CompositionJob
					{
                        chunkWidth = Settings.ChunkWidth,
                        chunkDepth = Settings.ChunkDepth,
                        heightMap = jobDefinition.parentRequest.chunkData.heightMap,
                        //gridData = jobDefinition.parentRequest.chunkData.grid,
                        gridMemAllocatorHandle = GCHandle.Alloc(GridMemBlockManager.Instance, GCHandleType.Weak), // hopefully the fact this is a singleton means we can pin it without much penalty
                        chunkDataHandle = GCHandle.Alloc(jobDefinition.parentRequest.chunkData, GCHandleType.Weak)
                    };

					return job.Schedule(dependancies);
				}

				case GenerationStage.Render:
				{
					var job = new GenerateChunkRenderJob
					{
						linkRenderArch = jobDefinition.generationWorld.EntityManager.CreateArchetype(ChunkRenderBuildSystem.LinkRenderArchetype.components),
                        parentArch = jobDefinition.generationWorld.EntityManager.CreateArchetype(Archetype.ChunkRenderParent.Components),
						//towerData = jobDefinition.parentRequest.chunkData.grid.towers,
						generationWorld = jobDefinition.generationWorld.EntityManager.BeginExclusiveEntityTransaction(),
                        chunkDataHndl = GCHandle.Alloc(jobDefinition.parentRequest.chunkData, GCHandleType.Weak)
                    };

					return job.Schedule(dependancies); 
				}
				
				case GenerationStage.Physics:
				{
					var job = new GenerateChunkPhysicsJob
					{
						linkCollisionArch = jobDefinition.generationWorld.EntityManager.CreateArchetype(ChunkCollisionBuildSystem.LinkCollisionArchetype.components),
                        parentArch = jobDefinition.generationWorld.EntityManager.CreateArchetype(Archetype.ChunkPhysicsParent.Components),
						//towerData = jobDefinition.parentRequest.chunkData.grid.towers,
                        linkColliders = JobSystem.BoxColliders,
                        generationWorld = jobDefinition.generationWorld.EntityManager.BeginExclusiveEntityTransaction(),
                        chunkDataHndl = GCHandle.Alloc(jobDefinition.parentRequest.chunkData, GCHandleType.Weak)
                    };

					return job.Schedule(dependancies);
				}

#if UNITY_EDITOR
				default:
					Debug.LogError("Requesting unknown/invalid job type be scheduled");
					break;
#endif
			}

			return new JobHandle();
		}
	}
}