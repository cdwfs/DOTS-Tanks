﻿using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Terraform.Component;
using Terraform.LAM;

namespace Terraform.Jobs
{
    public enum GenerationStage
    {
        //DataLoad = 0,
        //DataBuild = 1,
        HeightMap = 0,
        Composition,
        Render,
        Physics,
        //NavMesh,
        Max,
        
        Complete = Physics,
        None = -1,
    }
    
    public class JobFactory
    {
		public class GenerationRequest : IComparable<GenerationRequest>
		{
			public Cell lamCell;
		    public ChunkData chunkData;

		    public GenerationStage targetGenStage = GenerationStage.Complete;
		    
			public readonly LinkedList<JobHolder> jobsToSchedule = new LinkedList<JobHolder>();
			public readonly LinkedList<JobHolder> allJobs = new LinkedList<JobHolder>(); // keep around so got access to the unity job handles once scheduled
			
			public int CompareTo(GenerationRequest other)
			{
#if UNITY_EDITOR				
				Debug.Assert(lamCell != null, "Generation Request in priority queue without LAM cell");
#endif
				return lamCell.priority - other.lamCell.priority;
			}

			public bool IsTargetStateReached()
			{
				return allJobs.Last.Value.IsFinished();
			}

			public JobHolder GetJobForStage(GenerationStage genStage)
			{
				foreach (var job in allJobs)
				{
					if (job.jobStage == genStage)
					{
						return job;
					}
				}

				return null;
			}

			public void RemoveJob(GenerationStage genStage)
			{
				JobHolder jobToRemove = null;

				foreach (var job in allJobs)
				{
					if (job.jobStage == genStage)
					{
						jobToRemove = job;
					}
				}

				allJobs.Remove(jobToRemove);
				jobsToSchedule.Remove(jobToRemove);
			}
		}

		// Used to loop through N,E,S,W neighbouring chunks - static so not hitting GC all the time.
		// hopefully .net standard 2.1 will come along and we can alloc arrays on the stack in safe contexts
		private static readonly int[] xOffset = {0, 1, 0, -1}; 
	    private static readonly int[] zOffset = {1, 0, -1, 0};

	    // Received from JobSystem
	    private readonly Dictionary<Int64, GenerationRequest> _genRequests = new Dictionary<Int64, GenerationRequest>();

	    public JobFactory(Dictionary<Int64, GenerationRequest> generationRequests)
	    {
		    _genRequests = generationRequests;
	    }

	    public GenerationRequest GenerateJobsForChunk(TerraformObjData terraformObjData, ChunkData chunkData, GenerationStage targetStage, Cell lamCell = null)
        {
	        Debug.Assert(chunkData != null, "No chunk data associated with request.");
	        
	        // Is there already a request for this chunk
	        Int64 hashCode = Utils.HashChunkCoord(chunkData.coord);
	        bool isPreviousRequest = _genRequests.TryGetValue(hashCode, out var genRequest);

	        if (genRequest != null)
	        {
		        genRequest.targetGenStage = (GenerationStage) Math.Max((int)targetStage, (int)genRequest.targetGenStage);

		        if (lamCell != null)
		        {
#if UNITY_EDITOR
			        Debug.Assert(genRequest.lamCell == null || genRequest.lamCell == lamCell,"Previous Generation Request is for different lam cell"); // In theory should always be true
#endif
			        genRequest.lamCell = lamCell;			        
		        }
	        }
	        else
	        {
		        genRequest = new GenerationRequest
		        {
			        chunkData = chunkData, 
			        lamCell = lamCell, 
			        targetGenStage = targetStage
		        };
	        }
	        
	        // Assess what jobs already exist for the request
	        var chunkJobs = new JobHolder[(int)GenerationStage.Max];
	        foreach (var job in genRequest.allJobs)
	        {
		        if (!job.IsFinished())
		        {
			        chunkJobs[(int)job.jobStage] = job;
		        }
	        }

	        // Build any new jobs that are needed for the request
	        if (genRequest.targetGenStage >= GenerationStage.HeightMap && !genRequest.chunkData.heightMap.IsCreated && chunkJobs[(int)GenerationStage.HeightMap] == null)
	        {
		        var job = new JobHolder
		        {
			        parentRequest = genRequest,
			        jobStage = GenerationStage.HeightMap,
			        scheduledJob = new JobHandle(),
			        shouldBlockIfNotFinished = false
		        };
		        chunkJobs[(int)GenerationStage.HeightMap] = job;
		        genRequest.jobsToSchedule.AddLast(job);
		        genRequest.allJobs.AddLast(job);
	        }

	        if (genRequest.targetGenStage >= GenerationStage.Composition && !genRequest.chunkData.grid.towerData.IsCreated && chunkJobs[(int)GenerationStage.Composition] == null)
	        {
		        var compositionJob = new JobHolder
		        {
			        parentRequest = genRequest,
			        jobStage = GenerationStage.Composition,
			        scheduledJob = new JobHandle(),
			        shouldBlockIfNotFinished = false,
		        };

		        compositionJob.AddDependency(chunkJobs[(int)GenerationStage.HeightMap]);
		        chunkJobs[(int)GenerationStage.Composition] = compositionJob;
		        genRequest.jobsToSchedule.AddLast(compositionJob);
		        genRequest.allJobs.AddLast(compositionJob);
	        }
	        

	        if (genRequest.targetGenStage >= GenerationStage.Render && genRequest.chunkData.renderEntity == Entity.Null && chunkJobs[(int)GenerationStage.Render] == null)
	        {
		        // and add the render gen job
				var renderJob = new JobHolder
				{
					shouldBlockIfNotFinished = false,
					hasGenerationWorld = true,
					parentRequest = genRequest,
					jobStage = GenerationStage.Render,
					scheduledJob = new JobHandle()
				};
				
				renderJob.AddDependency(chunkJobs[(int)GenerationStage.Composition]);
		        
//#if FALSE
		        // Make sure generation requests are in for grids in the neighbouring chunks
		        for (int i = 0; i < xOffset.Length; ++i)
				{
					var neighbourCoord = new ChunkCoord(genRequest.chunkData.coord.x + xOffset[i], genRequest.chunkData.coord.z + zOffset[i]);
					var neighbourChunk = terraformObjData.GetOrCreateChunkDataRef(neighbourCoord);

					if (!neighbourChunk.grid.towerData.IsCreated)
					{
						var neighbourGenRequest = GenerateJobsForChunk(terraformObjData, neighbourChunk, GenerationStage.Composition);
						if (neighbourGenRequest != null)
						{
							renderJob.AddDependency(neighbourGenRequest.GetJobForStage(GenerationStage.Composition));
						}
					}
				}
//#endif
				
				chunkJobs[(int)GenerationStage.Render] = renderJob;
				genRequest.jobsToSchedule.AddLast(renderJob);
				genRequest.allJobs.AddLast(renderJob);
	        }

	        if (genRequest.targetGenStage >= GenerationStage.Physics && genRequest.chunkData.physicsEntity == Entity.Null && chunkJobs[(int)GenerationStage.Physics] == null)
	        {
		        var physicsJob = new JobHolder
		        {
			        shouldBlockIfNotFinished = false,
			        hasGenerationWorld = true,
			        parentRequest = genRequest,
			        jobStage = GenerationStage.Physics,
			        scheduledJob = new JobHandle()
		        };
		        
		        physicsJob.AddDependency(chunkJobs[(int)GenerationStage.Render]);
		        chunkJobs[(int)GenerationStage.Physics] = physicsJob;
		        genRequest.jobsToSchedule.AddLast(physicsJob);
		        genRequest.allJobs.AddLast(physicsJob);
	        }

	        if (genRequest.jobsToSchedule.Count == 0)
	        {
		        // Apparently, chunk is generated to required stage
		        //_genRequests.Remove(hashCode); // let job queue tidy up, might need still be in priority queue
		        genRequest = null;
	        }
	        else if (!isPreviousRequest)
	        {
		        _genRequests.Add(hashCode, genRequest);
	        }

	        return genRequest;
        }
    }
}