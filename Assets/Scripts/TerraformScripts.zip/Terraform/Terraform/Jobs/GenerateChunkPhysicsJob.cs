﻿using System.Runtime.InteropServices;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Transforms;
using Terraform.Component;

namespace Terraform.Jobs
{
    /// <summary>
    /// generates physics representation of the passed chunk. At the moment this creates a bunch of collision entities for each piece of link data.
    /// </summary>
    struct GenerateChunkPhysicsJob : IJob
    {
        public ExclusiveEntityTransaction generationWorld;
        //[ReadOnly] public NativeArray<TowerData> towerData;
        [ReadOnly] public NativeArray<BlobAssetReference<Collider>> linkColliders;
        [ReadOnly] public EntityArchetype linkCollisionArch;
        [ReadOnly] public EntityArchetype parentArch;
        public GCHandle chunkDataHndl;

        public void Execute()
        {
            var chunkData = chunkDataHndl.Target as ChunkData;
            chunkDataHndl.Free(); // shouldn't need now got the reference

            var parentEntity = generationWorld.CreateEntity(parentArch);
            DynamicBuffer<ChildPhysics> children = generationWorld.GetBuffer<ChildPhysics>(parentEntity);
#if UNITY_EDITOR
            UnityEngine.Debug.Assert(parentEntity.Index == 0, "Chunk Entity is not located at index 0");
#endif

	        //generationWorld.AddComponent(cnkEntity, typeof(Parent));
	        //generationWorld.SetComponentData(parentEntity,
		       // new Translation
		       // {
			      //  Value = new float3(0.0f, 0.0f, 0.0f)
		       // });
	        generationWorld.SetComponentData(parentEntity,
		        new Chunk { coord = chunkData.coord });
	        
	        
	        float zPos = chunkData.coord.z * Settings.ChunkSpacingZ;
	        
            for (int z = 0; z < Settings.ChunkWidth; ++z)
            {
	            float xPos = chunkData.coord.x * Settings.ChunkSpacingZ;
	            
                for (int x = 0; x < Settings.ChunkWidth; ++x)
                {
                    int towerI = (z * Settings.ChunkWidth) + x;
                    int h = 0;

                    int linkCount = chunkData.grid.towerData.GetNumLinksInTower(towerI);
                    NativeSlice<TowerLinkData> linkData = chunkData.grid.towerData.GetTowerData(towerI);
                    //for (int l = 0; l < towerData[towerI].numLinks; ++l)
                    for (int l = 0; l < linkCount; ++l)
                    {
                        Entity linkCol = generationWorld.CreateEntity(linkCollisionArch);
                        //int yMin = (int)towerData[towerI].linkData[l].GetComponentData(TowerLinkComponents.Ymin);
                        int yMin = (int)linkData[l].GetComponentData(TowerLinkComponents.Ymin);
                        float halfYMin = yMin / 2.0f;

                        var scale = new float3(Settings.BrickWidth, Settings.BrickHeight * yMin, Settings.BrickDepth);

                        children.Add(new ChildPhysics() { Value = linkCol });
                        
                        generationWorld.SetComponentData(linkCol, new Translation() { Value = (new float3(xPos, h + (Settings.BrickHeight * halfYMin), zPos)) });
                        generationWorld.SetComponentData(linkCol, new Rotation() { Value = quaternion.identity } );
                        generationWorld.SetComponentData(linkCol, new NonUniformScale() { Value = scale });

                        if (yMin != 0)
                        {
                            generationWorld.SetComponentData(linkCol, new PhysicsCollider()
                            {
                                Value = linkColliders[yMin - 1]
                            });
                        }

                        h += yMin;
                    }
                    
                    xPos += Settings.BrickWidth;
                }
                
                zPos += Settings.BrickWidth;
            }
        }
    }
}