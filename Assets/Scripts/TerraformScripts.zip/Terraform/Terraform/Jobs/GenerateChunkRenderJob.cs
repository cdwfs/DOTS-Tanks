﻿using System.Runtime.InteropServices;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Rendering;
using Unity.Transforms;
using UnityEngine;
using Terraform.Component;

namespace Terraform.Jobs
{
	/// <summary>
	/// generates render mesh representation of the passed chunk. At the moment this creates a bunch of rendered entities for each piece of link data.
	/// </summary>
	struct GenerateChunkRenderJob : IJob
	{
	    public ExclusiveEntityTransaction generationWorld;
	    //[ReadOnly] public NativeArray<TowerData> towerData;
	    [ReadOnly] public EntityArchetype linkRenderArch;
	    [ReadOnly] public EntityArchetype parentArch;
        public GCHandle chunkDataHndl;

        public void Execute()
        {
            var chunkData = chunkDataHndl.Target as ChunkData;

            chunkDataHndl.Free(); // shouldn't need now got the reference

            var parentEntity = generationWorld.CreateEntity(parentArch);
            DynamicBuffer<ChildRender> children = generationWorld.GetBuffer<ChildRender>(parentEntity);
#if UNITY_EDITOR
            Debug.Assert(parentEntity.Index == 0, "Chunk Entity is not located at index 0");
#endif

		    //generationWorld.AddComponent(cnkEntity, typeof(Parent));
		    //generationWorld.SetComponentData(parentEntity,
			   // new Translation
			   // {
				  //  Value = new float3(0.0f, 0.0f, 0.0f)
			   // });
		    generationWorld.SetComponentData(parentEntity,
			    new Chunk { coord = chunkData.coord });

		    float zPos = chunkData.coord.z * Settings.ChunkSpacingZ;
		    
		    for (int z = 0; z < Settings.ChunkWidth; ++z)
	        {
		        float xPos = chunkData.coord.x * Settings.ChunkSpacingX;
		        
	            for (int x = 0; x < Settings.ChunkWidth; ++x)
	            {
				    int towerI = (z * Settings.ChunkWidth) + x;
	                int h = 0;

                    int linkCount = chunkData.grid.towerData.GetNumLinksInTower(towerI);
                    NativeSlice<TowerLinkData> linkData = chunkData.grid.towerData.GetTowerData(towerI);
                    //for (int l = 0; l < towerData[towerI].numLinks; ++l)
                    for (int l = 0; l < linkCount; ++l)
                    {
                        var linkRender = generationWorld.CreateEntity(linkRenderArch);
                        //int yMin = (int)towerData[towerI].linkData[l].GetComponentData(TowerLinkComponents.Ymin);
                        int yMin = (int)linkData[l].GetComponentData(TowerLinkComponents.Ymin);
                        float halfYMin = yMin / 2.0f;

                        children.Add(new ChildRender() { Value = linkRender });
                        
	                    generationWorld.SetComponentData(linkRender, new Translation() { Value = new float3(xPos, h + (Settings.BrickHeight * halfYMin), zPos) });
	                    generationWorld.SetComponentData(linkRender, new NonUniformScale() { Value = new float3(Settings.BrickWidth, Settings.BrickHeight * yMin, Settings.BrickDepth) });
	                    generationWorld.SetSharedComponentData(linkRender, new RenderMesh()
	                    {
							mesh = TerraformBootStrapTest.sLinkMesh,
							material = TerraformBootStrapTest.sLinkMat,
							castShadows = UnityEngine.Rendering.ShadowCastingMode.Off
	                    });

	                    h += yMin;
	                }
	                
	                xPos += Settings.BrickWidth;
	            }
	            
	            zPos += Settings.BrickDepth;
	        }
	    }
	}	
}