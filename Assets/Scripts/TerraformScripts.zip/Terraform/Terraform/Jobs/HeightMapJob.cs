﻿using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;

namespace Terraform.Jobs
{
	[BurstCompile]
	public struct HeightMapJob : IJobParallelFor
	{
		[ReadOnly] public int seed;
		[ReadOnly] public ChunkCoord chunkCoord;
		[ReadOnly] public int chunkWidth;
		[ReadOnly] public int chunkDepth;
		public NativeArray<float> heightMap;

		public void Execute(int i)
		{
			int z = i / chunkWidth;
			int x = i - (z * chunkWidth);
//			int index = (z * chunkWidth) + x;
			float pnX = ((chunkCoord.x * chunkWidth) + x) / 64.0f;
			float pnZ = ((chunkCoord.z * chunkDepth) + z) / 64.0f;
			heightMap[i] = FastNoise.SinglePerlin(seed, FastNoise.Interp.Hermite, pnX, pnZ);
            heightMap[i] = heightMap[i] < 0.0f ? 0.0f : heightMap[i]; // create perfectly flat places inbetween bumps as the characrter cannot jump at the moment.
        }
	}
}