﻿using System.Runtime.InteropServices;
using Unity.Collections;
using Unity.Jobs;

namespace Terraform.Jobs
{
    public struct CompositionJob : IJob
    {
        [ReadOnly] public int chunkWidth;
        [ReadOnly] public int chunkDepth;
        [ReadOnly] public NativeArray<float> heightMap;
        //public TowerGridData gridData;
        //public GCHandle towerMemAllocatorHandle;
        public GCHandle gridMemAllocatorHandle;
        public GCHandle chunkDataHandle;

        public void Execute()
        {
	        // old implementation
	        //var towerMemAllocator = towerMemAllocatorHandle.Target as TowerLinkMemoryBlockManager;
	        //towerMemAllocatorHandle.Free(); // shouldn't need now got the reference
	        //
	        //if (towerMemAllocator == null)
	        //{
            //    Debug.LogError("No tower memory manager provided.");
            //    return;
	        //}
            //
            //int linkDataCount = 0;
            //for (int z = 0; z < chunkDepth; ++z)
	        //{
		    //    for (int x = 0; x < chunkWidth; ++x)
		    //    {
			//        int index = (z * chunkWidth) + x;
			//        float height = heightMap[index];
            //
            //        // old implementation
            //        var tData = new TowerData();
            //        towerMemAllocator.GetTowerData(towerLength, out tData.linkData);
            //        tData.numLinks = 1; // all empty
            //        tData.linkData[0] = new TowerLinkData((int)(16 + (height * 16)));
            //        gridData.towers[index] = tData;
            //    }
	        //}

            var gridMemAllocator = gridMemAllocatorHandle.Target as GridMemBlockManager;
            gridMemAllocatorHandle.Free(); // shouldn't need now got the reference

            var chunkData = chunkDataHandle.Target as ChunkData;
            chunkDataHandle.Free(); // shouldn't need now got the reference

            if (gridMemAllocator == null)
            {
                return;
            }

            int tempBlockMemSize = (TowerLinkData.maxTowerHeight * Settings.TowersPerChunk) / 10;
            NativeArray<TowerLinkData> tempLinkData = new NativeArray<TowerLinkData>(tempBlockMemSize, Allocator.Temp);
            NativeArray<ushort> tempIndexData = new NativeArray<ushort>(Settings.TowersPerChunk, Allocator.Temp);

            int linkDataCount = 0;
            for (int z = 0; z < chunkDepth; ++z)
            {
                for (int x = 0; x < chunkWidth; ++x)
                {
                    int index = (z * chunkWidth) + x;
                    float height = heightMap[index];

                    tempIndexData[index] = (ushort)index;
                    tempLinkData[index] = new TowerLinkData((int)(32 + (height * 64)));

                    ++linkDataCount;
                }
            }

            NativeSlice<TowerLinkData> linkDataSlice = new NativeSlice<TowerLinkData>(tempLinkData, 0, linkDataCount);  // slice of the memory block we used. 
            chunkData.grid.towerData.CopyIntoNew(in linkDataSlice, tempIndexData, gridMemAllocator);

            //gridData.towerData.indexData.CopyFrom(tempIndexData);
            //gridData.towerData.linkData.CopyFrom(linkDataSlice);

            // free the temp memory blocks.
            tempLinkData.Dispose();
            tempIndexData.Dispose();
        }
    }
}

