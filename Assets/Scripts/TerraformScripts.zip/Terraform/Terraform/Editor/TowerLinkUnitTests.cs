﻿using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace Terraform
{
    namespace Tests
    {
        namespace TowerLinkUnitTests
        {
            public class Tests
            {
                [Test]
                public void TowerLinkTest()
                {
                    TowerLinkData link = new TowerLinkData();

                    Int64 brickId = 432;
                    Int64 col = 8772;
                    Int64 xoffset = 3;
                    Int64 zoffset = 2;
                    Int64 rot = 2;
                    Int64 state = 5;
                    Int64 ymin = 549;
                    Int64 exposed = 1;
                    Int64 cellTypeId = 212;
                    Int64 userset = 1;
                    
                    link.SetComponentData(TowerLinkComponents.BrickID, brickId);
                    link.SetComponentData(TowerLinkComponents.Colour, col);
                    link.SetComponentData(TowerLinkComponents.XOffsetInBrick, xoffset);
                    link.SetComponentData(TowerLinkComponents.ZOffsetInBrick, zoffset);
                    link.SetComponentData(TowerLinkComponents.Rot, rot);
                    link.SetComponentData(TowerLinkComponents.State, state);
                    link.SetComponentData(TowerLinkComponents.Ymin, ymin);
                    link.SetComponentData(TowerLinkComponents.Exposed, exposed);
                    link.SetComponentData(TowerLinkComponents.CellTypeID, cellTypeId);
                    link.SetComponentData(TowerLinkComponents.UserSet, userset);

                    Assert.AreEqual(brickId, link.GetComponentData(TowerLinkComponents.BrickID), "brick id is not equal");
                    Assert.AreEqual(col, link.GetComponentData(TowerLinkComponents.Colour), "colour is not equal");
                    Assert.AreEqual(xoffset, link.GetComponentData(TowerLinkComponents.XOffsetInBrick), "x offset is not equal");
                    Assert.AreEqual(zoffset, link.GetComponentData(TowerLinkComponents.ZOffsetInBrick), "z offset is not equal");
                    Assert.AreEqual(rot, link.GetComponentData(TowerLinkComponents.Rot), "rot is not equal");
                    Assert.AreEqual(state, link.GetComponentData(TowerLinkComponents.State), "state is not equal");
                    Assert.AreEqual(ymin, link.GetComponentData(TowerLinkComponents.Ymin), "ymin is not equal");
                    Assert.AreEqual(exposed, link.GetComponentData(TowerLinkComponents.Exposed), "exposed is not equal");
                    Assert.AreEqual(cellTypeId, link.GetComponentData(TowerLinkComponents.CellTypeID), "celltype is not equal");
                    Assert.AreEqual(userset, link.GetComponentData(TowerLinkComponents.UserSet), "userset is not equal");
                }
            }
        }
    }
}