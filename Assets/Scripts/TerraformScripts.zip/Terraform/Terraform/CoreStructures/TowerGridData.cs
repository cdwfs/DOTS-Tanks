﻿using System;
using System.Runtime.InteropServices;
using Unity.Collections;

namespace Terraform
{
    //public struct TowerGridData
    //{
    //    [MarshalAs(UnmanagedType.ByValArray, SizeConst = Settings.TowersPerChunk)]
    //    public TowerData[] towers;

    //    public TowerGridData(int xSize, int zSize)
    //    {
    //        towers = new TowerData[xSize * zSize];
    //    }

    //    public void AddLinkData(in TowerLinkData[] links, int towerIndex)
    //    {
    //        towers[towerIndex].AddLinkData(in links);
    //    } 
    //}

    public struct TowerGridData 
    {
        public GridMemData towerData;
    }
}