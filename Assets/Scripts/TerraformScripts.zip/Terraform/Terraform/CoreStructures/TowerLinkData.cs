﻿using System;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using UnityEngine;

namespace Terraform
{
    // enum order also defines order in 64 bit packed value. Components at the top are at the front, and those at the bottom are at the back.
    public enum TowerLinkComponents
    {
        Colour,
        Exposed,
        Ymin,
        State,
        UserSet,
        CellTypeID,
        XOffsetInBrick,
        ZOffsetInBrick,
        BrickID,
        Rot,
        Spare,

        Count
    }

    public struct TowerLinkData
    {
        // must total 64.
        static readonly int[] bitsPerComponent = new int[]
        {
            15,     // Colour
            1,      // Exposed
            12,     // Ymin
            3,      // State
            1,      // UserSet
            8,      // CellTypeID
            5,      // XOffsetInBrick
            5,      // ZOffsetInBrick
            9,      // BrickId
            2,      // Rot
            3       // Spare
        };

        static readonly Int64[] componentMasks = new Int64[(int)TowerLinkComponents.Count];
        static readonly int[] bitOffsets = new int[(int)TowerLinkComponents.Count];

        static readonly public int maxTowerHeight;

        Int64 data;
        
        public TowerLinkData(in Int64 yMin)
        {
            data = 0;
            SetComponentData(TowerLinkComponents.Ymin, yMin);
        }

        static TowerLinkData()
        {
            InitMasks();

            maxTowerHeight = Mathf.FloorToInt(Mathf.Pow(2, bitsPerComponent[(int)TowerLinkComponents.Ymin]));
        }
        
        public static void InitMasks()
        {
#if UNITY_EDITOR
            int totalBits = 0;

            for (int i = 0; i < (int)TowerLinkComponents.Count; ++i)
            {
                totalBits += bitsPerComponent[i];
            }

            Debug.Assert(totalBits == 64, "total number of bits within tower link data does not equal 64");
#endif

            // calculate the bit masks for each component
            int bitTracker = 0;
            for (int i = 0; i < (int)TowerLinkComponents.Count; ++i)
            {
                int bitCount = bitsPerComponent[i];

                Int64 mask = 0;
                for (int b = 0; b < bitCount; ++b)
                {
                    mask = mask << 1;
                    mask++;
                }

                componentMasks[i] = mask << bitTracker;

                bitOffsets[i] = bitTracker;
                bitTracker += bitCount;
            }
        }

        public Int64 GetComponentData(in TowerLinkComponents component)
        {
            Int64 cData = data & componentMasks[(int)component];
            cData = cData >> bitOffsets[(int)component];

            return cData;
        }
        
        public void SetComponentData(in TowerLinkComponents component, in Int64 val)
        {
            Int64 mask = ~componentMasks[(int)component];
            data &= mask;
            data += (val << bitOffsets[(int)component]);
        }
    }
}