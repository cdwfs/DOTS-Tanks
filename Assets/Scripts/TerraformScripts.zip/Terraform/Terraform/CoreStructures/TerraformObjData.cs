﻿using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Entities;
using Terraform.Component;

namespace Terraform
{
    public class TerraformObjData
    {
        public readonly TerraformObjGenParams genParams;
        public readonly ushort id;
        public readonly Entity entity;

        public Dictionary<Int64, ChunkData> chunks;
        
        public TerraformObjData(in TerraformObjGenParams genParams)
        {
            this.genParams = genParams; 
            this.chunks = new Dictionary<Int64, ChunkData>(100);
            id = genParams.id;
            entity = World.Active.EntityManager.CreateEntity(Archetype.TerraformObj.Value);
        }

        public bool GetChunkData(in ChunkCoord coord, out ChunkData data)
        {
            return chunks.TryGetValue(Utils.HashChunkCoord(coord), out data);
        }

        public ChunkData GetOrCreateChunkDataRef(in ChunkCoord coord)
        {
            Int64 key = Utils.HashChunkCoord(coord);

            ChunkData chunk;
            if (!chunks.TryGetValue(key, out chunk))
            {
                chunk = new ChunkData(coord, this);
                chunks.Add(key, chunk);
            }

            return chunk;
        }

        public void InitiateChunk(in ChunkGenParams cnkParams)
        {
            ChunkData chunk = GetOrCreateChunkDataRef(cnkParams.coords);
            
            // if chunk data exists then load it
            // LoadChunkData(newChunk);
            // else generate it
            GenerateChunkData(ref chunk, in cnkParams);
        }

        void LoadChunkData(ref ChunkData chunk)
        {

        }

        void GenerateChunkData(ref ChunkData chunk, in ChunkGenParams cnkParams)
        {
            GenerationUtils.GenerateChunk(cnkParams, ref chunk);
        }
    }
}