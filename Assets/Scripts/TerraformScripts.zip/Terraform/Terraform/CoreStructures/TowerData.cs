﻿using System;
using Unity.Collections;
using MemoryUtils;
using System.Runtime.InteropServices;

namespace Terraform
{
    [StructLayout(LayoutKind.Sequential, Pack = 2)]
    public struct TowerData
    {
        public NativeSlice<TowerLinkData> linkData;
        public UInt16 numLinks;

        public TowerData(in UInt16 maxLinks)
        {
            TowerLinkMemoryBlockManager.Instance.GetTowerData(maxLinks, out linkData);
            numLinks = maxLinks;
        }

        public int TowerMaxSize()
        {
            return linkData.Length;
        }

        public bool CanFitData(in TowerLinkData[] links)
        {
            return false;
        }

        public void AddLinkData(in TowerLinkData[] links)
        {
            // increase memory size if we could not fit the data in. 
            if (CanFitData(in links))
            {
                linkData = TowerLinkMemoryBlockManager.Instance.UpgradeTower(linkData, in links);
            }
            else
            {
                // modify link data
            }
        }
    }
}
