﻿using System.Collections.Generic;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;

namespace Terraform
{
    public class ChunkData
    {
        public TerraformObjData parent;
	    public readonly ChunkCoord coord;
        public NativeArray<float> heightMap;
        public TowerGridData grid;

        public Entity renderEntity = Entity.Null;
        public Entity physicsEntity = Entity.Null;

        public Entity parentTerraformEntity
        {
            get
            {
                return parent.entity;
            }
        }

        public List<JobHandle> genJobHndls = new List<JobHandle>(); // stores any job handles associated with the generation of this chunk that have been scheduled.
        
        public ChunkData(in ChunkCoord coord, TerraformObjData parent)
        {
            this.parent = parent;
	        this.coord = coord;
            this.grid.towerData = GridMemData.NULL;
        }

        ~ChunkData()
        {
            heightMap.Dispose();
            grid.towerData.Free(GridMemBlockManager.Instance);
        }

        public bool HasActiveJobs()
        {
            for (int i = 0; i < genJobHndls.Count; ++i)
            {
                if (!genJobHndls[i].IsCompleted)
                {
                    return true;
                }
            }

            return false;
        }
    }
}