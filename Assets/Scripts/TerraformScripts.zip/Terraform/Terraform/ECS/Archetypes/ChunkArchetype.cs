﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using Terraform.Component;

namespace Terraform.Archetype
{
    public static class Chunk
    {
        public static readonly ComponentType[] Components = new ComponentType[]
        {
            typeof(Component.Chunk)
        };

        public static readonly EntityArchetype Value = World.Active.EntityManager.CreateArchetype(Components);

		public static Entity CreateChunkEntity(World targetWorld, Entity parentEntity, in ChunkCoord coord )
        {
	        var chunkEntity = targetWorld.EntityManager.CreateEntity(Value);

	        targetWorld.EntityManager.AddComponentData(chunkEntity,
		        new Parent { Value = parentEntity });
	        targetWorld.EntityManager.SetComponentData(chunkEntity,
		        new Translation
		        {
			        Value = new float3(coord.x * Settings.ChunkSpacingX, 0.0f, coord.z * Settings.ChunkSpacingZ)
		        });
	        targetWorld.EntityManager.SetComponentData(chunkEntity,
		        new Component.Chunk { coord = coord });

	        return chunkEntity;
        }
    }
}
