﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
using Unity.Transforms;
using Terraform.Component;

namespace Terraform.Archetype
{
    public static class TerraformObj
    {
        public static readonly ComponentType[] Components = new ComponentType[]
        {
            typeof(Translation),
            typeof(StreamableObj),
            typeof(Component.TerraformObj)
        };

        public static readonly EntityArchetype Value = World.Active.EntityManager.CreateArchetype(Components);
    }
}
