﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Transforms;
using UnityEngine;
using Terraform.Component;

namespace Terraform.Archetype
{
    public static class ChunkPhysicsParent
    {
        public static readonly ComponentType[] Components = new ComponentType[]
        {
            typeof(Component.Chunk),
            typeof(ChildPhysics)
        };

        public static readonly EntityArchetype Value = World.Active.EntityManager.CreateArchetype(Components);
    }
}
