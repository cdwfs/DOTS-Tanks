﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Terraform.Component;
using Terraform.Jobs;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace Terraform.ECS.Systems
{
	// TODO - Consider making this a job component system
	// TODO - Move to a point in the frame where scheduling/moving entities has minimal affect on Game play jobs 
	[UpdateAfter(typeof(LAM.UpdateSystem))]
	public partial class JobSystem : ComponentSystem
	{
		private readonly Dictionary<Int64, JobFactory.GenerationRequest> _genRequests = new Dictionary<Int64, JobFactory.GenerationRequest>();
		private readonly List<JobFactory.GenerationRequest> _priorityList = new List<JobFactory.GenerationRequest>();
		private readonly List<JobHolder> _scheduledJobs = new List<JobHolder>();
		
#if UNITY_EDITOR
		// transferring entities from worlds has to be done on foreground thread, so limit number of jobs processed per frame 
		private readonly int _maxWorldGenJobsPerFrame = 1;
#else
		private readonly int _maxWorldGenJobsPerFrame = int.MaxValue;
#endif
		// Scheduled jobs that use a generation world on the background thread
		// need to call MoveEntitiesFrom on the foreground, so hold onto till the job is complete
		private readonly List<JobHolder> _worldGenJobs = new List<JobHolder>();

		// Creating/Disposing worlds is quite expensive in the editor, less so in standalone
		// but probably best to recycle worlds and avoid the GC hits as well
		private const int MaxGenerationWorlds = 10;
		private List<World> _spareGenerationWorlds;
	    
		// To prevent composition jobs trying to allocate from the same memory, maintain a dependency on the last scheduled
		// composition job to prevent them running at same time
		private JobHandle _compositionJobs;
	    
		// TODO - remove when brick lib is setup
		public static NativeArray<BlobAssetReference<Unity.Physics.Collider>> BoxColliders;

		// TODO Implemented here temporarily - can remove when proper brick lib setup
		protected override void OnCreate()
		{
			_jobFactory = new JobFactory(_genRequests);
			_spareGenerationWorlds = new List<World>(MaxGenerationWorlds);

			for (int i = 0; i < MaxGenerationWorlds; ++i)
			{
				_spareGenerationWorlds.Add(new World("GenerationWorld"));
			}
	        
			BoxColliders = new NativeArray<BlobAssetReference<Unity.Physics.Collider>>(4096, Allocator.Persistent);

			// create colliders for link gen
			for (int i = 0; i < BoxColliders.Length; ++i)
			{
				var scale = new float3(Settings.BrickWidth, Settings.BrickHeight * (i + 1), Settings.BrickDepth);

				BoxColliders[i] = Unity.Physics.BoxCollider.Create(
					float3.zero,
					quaternion.identity,
					scale,
					0.0f);
			}
		}

		protected override void OnDestroy()
		{
			for (int i = 0; i < _scheduledJobs.Count; ++i)
			{
				_scheduledJobs[i].scheduledJob.Complete();
			}
	        
			for (int i = 0; i < _spareGenerationWorlds.Count; ++i)
			{
				_spareGenerationWorlds[i].Dispose();
			}
	        
			// It might not be necessary to do this here, all worlds should be disposed. Need more info on entity transactions
			for (int i = 0; i < _worldGenJobs.Count; ++i)
			{
				_worldGenJobs[i].scheduledJob.Complete();
				_worldGenJobs[i].generationWorld.EntityManager.EndExclusiveEntityTransaction();
				_worldGenJobs[i].generationWorld.Dispose();
			}
	        
			BoxColliders.Dispose();
		}
		
		protected override void OnUpdate()
        {
	        // Process finished jobs
	        if (_scheduledJobs.Count > 0)
	        {
		        for (int i = _scheduledJobs.Count - 1; i >= 0; --i)
		        {
			        if (_scheduledJobs[i].IsFinished())
			        {
				        _scheduledJobs[i].scheduledJob.Complete(); // Solves a lot of problems
				        RemoveFinishedRequests(_scheduledJobs[i].parentRequest, _scheduledJobs[i]);
				        _scheduledJobs.RemoveAt(i);
			        }
		        }
	        }
	        
			// For any completed jobs which generate entities on bg threads, move those entities into default world
			{
				int i = 0;
				int numWorldsToProcess = _maxWorldGenJobsPerFrame;
				
				while (numWorldsToProcess > 0 && i < _worldGenJobs.Count)
				{
					if (!_worldGenJobs[i].IsFinished())
					{
						++i;
						continue;
					}

					var job = _worldGenJobs[i];
					job.scheduledJob.Complete();
					_worldGenJobs.RemoveAt(i);
					--numWorldsToProcess;

					job.generationWorld.EntityManager.EndExclusiveEntityTransaction();
					
					if (job.parentRequest.lamCell == null || job.parentRequest.lamCell.IsDead())
					{
						// Unity botches the cleanup on the Destroy all entities, leaving the next free entity index to be non-zero
						// recreate world for now
						//job.generationWorld.EntityManager.DestroyEntity(job.generationWorld.EntityManager.GetAllEntities());
						job.generationWorld.Dispose();
						job.generationWorld = new World("GenerationWorld");
					}
					else if (job.jobStage == GenerationStage.Render)
					{
						job.parentRequest.chunkData.renderEntity = HandleWorldGenJobCompleted(job.generationWorld, job.parentRequest.chunkData.parentTerraformEntity);
					}
					else
					{
						job.parentRequest.chunkData.physicsEntity = HandleWorldGenJobCompleted(job.generationWorld, job.parentRequest.chunkData.parentTerraformEntity);
					}
					
					_spareGenerationWorlds.Add(job.generationWorld); // return world to spare list
				}
			}
			
			
			int numJobsToSchedule = 10;

			for (int i = 0; i < _priorityList.Count; ++i)
			{
				if (numJobsToSchedule == 0)
				{
					break;
				}
				var currentRequest = _priorityList[i];

				while (numJobsToSchedule > 0 && currentRequest.jobsToSchedule.Count > 0)
				{
#if UNITY_EDITOR
					Debug.AssertFormat(!currentRequest.lamCell.IsDead(), "Request for dead lam cell in job queue ({0},{1})", currentRequest.lamCell.chunk.coord.x, currentRequest.lamCell.chunk.coord.z);
#endif

					var job = currentRequest.jobsToSchedule.First.Value;

					JobHolder jobToSchedule;

					bool canStartNow = job.CanStartNow();
					if (canStartNow)
					{
						jobToSchedule = job;
					}
					else
					{
						jobToSchedule = JobHolder.GetDependentJobToRun(job);

						if (jobToSchedule == null)
						{
							break; // Generation is blocked waiting for another job to finish
						}

						--numJobsToSchedule;
					}


					if (jobToSchedule.hasGenerationWorld)
					{
						if (_spareGenerationWorlds.Count > 0)
						{
							jobToSchedule.generationWorld = _spareGenerationWorlds[0];
							_spareGenerationWorlds.RemoveAt(0);
							_worldGenJobs.Add(jobToSchedule);
						}
						else
						{
							break;
						}
					}
					
					--numJobsToSchedule;
					var dependencies = jobToSchedule.jobStage == GenerationStage.Composition ? _compositionJobs : new JobHandle();
					var jobHandle = jobToSchedule.Schedule(dependencies);
					_scheduledJobs.Add(jobToSchedule);
					jobToSchedule.parentRequest.jobsToSchedule.Remove(jobToSchedule);
					
					if (jobToSchedule.jobStage == GenerationStage.Composition)
					{
						_compositionJobs = jobHandle;
					}
				}
			}
			
			//JobHandle.ScheduleBatchedJobs();
        }
		
		// Used to loop through N,E,S,W neighbouring chunks - static so not hitting GC all the time.
		// hopefully .net standard 2.1 will come along and we can alloc arrays on the stack in safe contexts
		private static readonly int[] XOffset = {0, 1, 0, -1};
		private static readonly int[] ZOffset = {1, 0, -1, 0};
		
		private bool IsGenerationRedundant(JobFactory.GenerationRequest genRequest)
		{
			if (genRequest.lamCell != null)
			{
				return true;
			}
		    
			// check if neighbour chunks are still referencing it
			for (int i = 0; i < XOffset.Length; ++i)
			{
				var coord = new ChunkCoord(genRequest.chunkData.coord.x + XOffset[i], genRequest.chunkData.coord.z + ZOffset[i]);
				var hashCode = Utils.HashChunkCoord(coord);
				var neighbourRequest = _genRequests.ContainsKey(hashCode) ? _genRequests[hashCode] : null;

				if (neighbourRequest?.lamCell != null && neighbourRequest.chunkData.renderEntity == Entity.Null)
				{
					return false;
				}
			}

			return true;
		}
		
		private Entity HandleWorldGenJobCompleted(World srcWorld, Entity parentEntity)
		{
			var remapArray = srcWorld.EntityManager.CreateEntityRemapArray(Allocator.TempJob);
			Debug.Assert(srcWorld.EntityManager.Debug.EntityCount == 1 + (Settings.ChunkWidth * Settings.ChunkDepth), "Unexpected number of entities in generation world");
			World.Active.EntityManager.MoveEntitiesFrom(srcWorld.EntityManager, remapArray);
			var chunkEntity = remapArray[0].Target; // first entity should be the chunk entity
			remapArray.Dispose();

			// parent chunk to its terraform obj
			//World.Active.EntityManager.SetComponentData(chunkEntity, new Parent { Value = parentEntity });
	        
#if UNITY_EDITOR
			Debug.Assert(World.Active.EntityManager.HasComponent<Chunk>(chunkEntity), "Invalid Chunk Entity");
#endif
	        
			return chunkEntity;
		}

		private void RemoveFinishedRequests(JobFactory.GenerationRequest genRequest, JobHolder finishedJob)
		{
			// Remove any finished jobs - might be easier with Ricardo's priority list
			if (!genRequest.IsTargetStateReached() || finishedJob.jobStage < genRequest.targetGenStage)
			{
				return;
			}

			var hashCode = Utils.HashChunkCoord(genRequest.chunkData.coord);

#if UNITY_EDITOR
			if (!_genRequests.TryGetValue(hashCode, out var temp))
			{
				Debug.LogErrorFormat("Gen Request {0},{1} not in dictionary", genRequest.chunkData.coord.x, genRequest.chunkData.coord.z);
			}

			if (genRequest.lamCell != null && !_priorityList.Contains(genRequest))
			{
				Debug.LogErrorFormat("Gen Request {0},{1} not in priority list", genRequest.chunkData.coord.x, genRequest.chunkData.coord.z);
			}
#endif

			_genRequests.Remove(hashCode);
			_priorityList.Remove(genRequest);
		}

		#if UNITY_EDITOR
		private bool Validate()
		{
			for (int i = 0; i < _priorityList.Count; ++i)
			{
				Int64 hashCode = Utils.HashChunkCoord(_priorityList[i].chunkData.coord);

				if (_genRequests.TryGetValue(hashCode, out var generationRequest))
				{
					continue;
				}

				Debug.LogErrorFormat("GenerationRequest in priority queue that is not in Dictionary {0},{1}", _priorityList[i].chunkData.coord.x, _priorityList[i].chunkData.coord.z);
				return false;
			}

			return true;
		}
		#endif
	}
}
