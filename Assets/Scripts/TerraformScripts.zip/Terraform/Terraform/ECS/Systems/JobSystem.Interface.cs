﻿using System;
using System.Collections.Generic;
using Terraform.Jobs;
using Terraform.LAM;
using Unity.Collections;
using UnityEngine;

namespace Terraform.ECS.Systems
{
	public partial class JobSystem
	{
		private JobFactory _jobFactory;

		public void AddGenerationCell(Cell newCell)
		{
			if (newCell == null)
			{
				Debug.LogError("Adding null lam cell");
				return;
			}
			    
			if (!TerraformObjDataManager.Instance.GetTerraObjData(newCell.parent.terraData.id, out var terraformObjData))
			{
				Debug.LogError("LAM cell does not have valid Terraform Obj Data");
			}
			
#if UNITY_EDITOR
			// If generation request already exists, it was for composition only job
			Int64 hashCode = Utils.HashChunkCoord(newCell.chunk.coord);
			var prevRequest = _genRequests.ContainsKey(hashCode) ? _genRequests[hashCode] : null;
			Debug.Assert(prevRequest?.lamCell == null, "Duplicate LAM Cell generation requested");
			Debug.Assert(prevRequest == null || !_priorityList.Contains(prevRequest), "LAM Cell requested for generation twice");
#endif

			var genRequest = _jobFactory.GenerateJobsForChunk(terraformObjData, newCell.chunk, GenerationStage.Complete, newCell);

			if (genRequest != null)
			{
				
#if UNITY_EDITOR
				Debug.Assert(_genRequests.TryGetValue(hashCode, out var temp), "Generation Request is not in dictionary");
				Debug.Assert(genRequest.lamCell != null, "Generation Request for lam cell does not reference lam cell");
				Debug.Assert(!_priorityList.Contains(genRequest), "Generation Request already in priority queue");
#endif
				_priorityList.Add(genRequest); 
			}
		}
		    
		public void LamsUpdated()
		{
			int requestCount = _genRequests.Count;
			int deadRequestCount = 0;
			if (requestCount == 0)
			{
				return;
			}
			
			#if UNITY_EDITOR
			//Validate();
			#endif
			
			// Remove any requests that are no longer needed
			NativeArray<Int64> deadRequests = new NativeArray<Int64>(requestCount, Allocator.Temp, NativeArrayOptions.UninitializedMemory);

			foreach (KeyValuePair<Int64, JobFactory.GenerationRequest> genRequest in _genRequests)
			{
				// do something with entry.Value or entry.Key
				if (genRequest.Value.lamCell == null)
				{
#if UNITY_EDITOR
					Debug.Assert(!_priorityList.Contains(genRequest.Value),
						"Generation Request with no LAM cell in priority queue");
#endif
					if (!IsGenerationRedundant(genRequest.Value))
					{
						continue;
					}

					var hashCode = Utils.HashChunkCoord(genRequest.Value.chunkData.coord);
					deadRequests[deadRequestCount] = hashCode;
					++deadRequestCount;
				}
				else if (genRequest.Value.lamCell.IsDead())
				{
					var deadRequest = genRequest.Value;

#if UNITY_EDITOR
					Debug.Assert(_priorityList.Contains(deadRequest),
						"Generation Request with LAM cell not in priority queue");
#endif
					_priorityList.Remove(deadRequest);

					if (IsGenerationRedundant(deadRequest))
					{
						var hashCode = Utils.HashChunkCoord(deadRequest.chunkData.coord);
						deadRequests[deadRequestCount] = hashCode;
						++deadRequestCount;
					}
					else
					{
						deadRequest.targetGenStage = GenerationStage.Composition;
						deadRequest.RemoveJob(GenerationStage.Render);
						deadRequest.RemoveJob(GenerationStage.Physics);
						deadRequest.lamCell = null;
					}
				}
				#if UNITY_EDITOR
				else
				{
					Debug.Assert(_priorityList.Contains(genRequest.Value), "Generation Request with LAM cell not in priority queue");
				}
				#endif
			}

			for (int i = 0; i < deadRequestCount; ++i)
			{
				_genRequests.Remove(deadRequests[i]);
			}
			deadRequests.Dispose();
			
			// Resort based on new priorities
			_priorityList.Sort();
		}
	}
}
