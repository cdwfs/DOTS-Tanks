﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Jobs;
using UnityEngine;
using System;
using Unity.Collections;
using System.Runtime.InteropServices;

namespace Terraform
{
    public class ChunkGenerationSystem : JobComponentSystem
    {
        struct GenerateChunk : IJobParallelFor
        {
            public EntityCommandBuffer.Concurrent commandBuffer;
            
            public void Execute(int index)
            {
            }
        }

        protected override JobHandle OnUpdate(JobHandle inputDeps)
        {
            //var commandBufferSystem = World.Active.GetOrCreateManager<EntityCommandBufferSystem>();
            //EntityManager entityManager = World.Active.GetOrCreateManager<EntityManager>();

            //var job = new GenerateChunk()
            //{
            //    commandBuffer = commandBufferSystem.CreateCommandBuffer().ToConcurrent()
            //};

            //var jobHandle = job.Schedule(chunkData.Length, 0, inputDeps);
            //commandBufferSystem.AddJobHandleForProducer(jobHandle);

            //return jobHandle;

            return inputDeps;
        }
    }
}
