﻿using Unity.Jobs;
using Unity.Collections;
using Unity.Transforms;
using Unity.Entities;
using Terraform.Jobs;
using Unity.Physics;

namespace Terraform
{
    /// <summary>
    /// system that creates render representation of a terra obj chunk. 
    /// </summary>
    public class ChunkCollisionBuildSystem : JobComponentSystem
    {
        /// <summary>
        /// archetype for the link data render used in the job GenerateChunkRender.
        /// </summary>
        public static class LinkCollisionArchetype
        {
            public static readonly ComponentType[] components = new ComponentType[]
            {
				//typeof(Parent),
                //typeof(LocalToParent),
                typeof(LocalToWorld),
                typeof(Translation),
                typeof(Rotation),
                typeof(NonUniformScale),
                typeof(PhysicsCollider)
            };

            public static readonly EntityArchetype archetype = World.Active.EntityManager.CreateArchetype(components);
        }

        protected override JobHandle OnUpdate(JobHandle inputDeps)
        {
            //// create query for chunk entities with a GenChunkCollision component.
            //EntityQuery query = EntityManager.CreateEntityQuery(new ComponentType[] { typeof(Chunk), typeof(GenChunkCollision), typeof(Parent) });

            //if (query.CalculateLength() == 0)
            //{
            //    return inputDeps;
            //}

            //EntityCommandBufferSystem ecbSystem = World.Active.GetOrCreateSystem<EntityCommandBufferSystem>();

            //NativeArray<Parent> parents = query.ToComponentDataArray<Parent>(Allocator.TempJob);
            //NativeArray<Chunk> chunks = query.ToComponentDataArray<Chunk>(Allocator.TempJob);
            //NativeArray<Entity> cnkEntities = query.ToEntityArray(Allocator.TempJob);

            JobHandle lastHndl = inputDeps;

            //// loop through all gen requests and create a job for it.
            //for (int i = 0; i < parents.Length; ++i)
            //{
            //    TerraformObj terraObj = EntityManager.GetComponentData<TerraformObj>(parents[i].Value);

            //    TerraformObjData tData;
            //    TerraformObjDataManager.Instance.GetTerraObjData(terraObj.tParams.id, out tData);

            //    ChunkData cnkData;
            //    tData.GetChunkData(chunks[i].coord, out cnkData);

            //    GenerateChunkPhysicsJob job = new GenerateChunkPhysicsJob()
            //    {
            //        buffer = World.Active.GetOrCreateSystem<EntityCommandBufferSystem>().CreateCommandBuffer().ToConcurrent(),
            //        linkRenderArch = LinkCollisionArchetype.archetype,
            //        towerData = cnkData.grid.towers,
            //        cnkEntity = cnkEntities[i],
            //        coord = chunks[i].coord
            //    };

            //    JobHandle hndl = job.Schedule(lastHndl);
            //    lastHndl = hndl;
            //    ecbSystem.AddJobHandleForProducer(hndl);

            //    EntityManager.RemoveComponent<GenChunkCollision>(cnkEntities[i]);
            //}


            //parents.Dispose();
            //chunks.Dispose();
            //cnkEntities.Dispose();

            return lastHndl;
        }
    }
}