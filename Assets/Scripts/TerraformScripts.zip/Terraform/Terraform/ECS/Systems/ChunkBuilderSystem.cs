﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Jobs;
using UnityEngine;
using System;
using Unity.Collections;
using System.Runtime.InteropServices;
using Unity.Transforms;
using Unity.Mathematics;
using Terraform.Component;

namespace Terraform
{
    public struct ChunkBuildRequest
    {
        public static readonly ChunkBuildRequest NULL = new ChunkBuildRequest(ushort.MaxValue, new ChunkCoord(int.MinValue, int.MinValue));
        
        public readonly ushort terraId;
        public readonly ChunkCoord cnkCoord;

        public ChunkBuildRequest(ushort terraId, ChunkCoord cnkCoord)
        {
            this.terraId = terraId;
            this.cnkCoord = cnkCoord;
        }        

        public static bool operator==(ChunkBuildRequest c1, ChunkBuildRequest c2)
        {
            return (c1.terraId == c2.terraId && c1.cnkCoord == c2.cnkCoord);
        }

        public static bool operator !=(ChunkBuildRequest c1, ChunkBuildRequest c2)
        {
            return (c1.terraId != c2.terraId || c1.cnkCoord != c2.cnkCoord);
        }
    }

    /// <summary>
    /// place to store and pull build requests for chunks.
    /// </summary>
    public class ChunkBuildRequestsManager
    {
        public List<ChunkBuildRequest> requests = new List<ChunkBuildRequest>(128);

        public static ChunkBuildRequestsManager Instance = new ChunkBuildRequestsManager();    // need a singleton class that doesn't inherit from mono. This is temp.

        public bool HasRequests()
        {
            return (requests.Count != 0);
        }
        
        public void AddRequest(ChunkBuildRequest request)
        {
            requests.Add(request);
        }

        public List<ChunkBuildRequest> PopAllRequests()
        {
            List<ChunkBuildRequest> r = requests;
            requests = new List<ChunkBuildRequest>(128);
            return r;
        }
    }

    /// <summary>
    /// responsible for the creation of a chunk entity.
    /// </summary>
    public class ChunkBuilderSystem : ComponentSystem
    {
        protected override void OnUpdate()
        {
            if (ChunkBuildRequestsManager.Instance.HasRequests())
            {
                EntityQuery terrainQuery = GetEntityQuery(new ComponentType[] { typeof(TerraformObj) });
                NativeArray<Entity> entities = terrainQuery.ToEntityArray(Allocator.TempJob);
                NativeArray<TerraformObj> terraformObjs = terrainQuery.ToComponentDataArray<TerraformObj>(Allocator.TempJob);

                List< ChunkBuildRequest> requests = ChunkBuildRequestsManager.Instance.PopAllRequests();
                
                for (int r = 0; r < requests.Count; ++r)
                {
                    ChunkBuildRequest request = requests[r];
                    
                    TerraformObjData tData;
                    TerraformObjDataManager.Instance.GetTerraObjData(request.terraId, out tData);

                    // need to find the terraform entity for the request.
                    Entity matchedTEntity = Entity.Null;
                    TerraformObj matchedTCom = new TerraformObj();

                    ChunkData cnkData;
                    tData.GetChunkData(request.cnkCoord, out cnkData);

                    for (int i = 0; i < terraformObjs.Length; ++i)
                    {
                        if (terraformObjs[i].tParams.id == request.terraId)
                        {
                            matchedTEntity = entities[i];
                            matchedTCom = terraformObjs[i];
                        }
                    }

                    // could not find terraform entity for the request.
                    if (matchedTEntity == Entity.Null)
                        continue;

                    Entity newCnk = EntityManager.CreateEntity(Archetype.Chunk.Value);

                    EntityManager.AddComponentData<Parent>(newCnk, new Parent() { Value = matchedTEntity });
                    EntityManager.SetComponentData<Translation>(newCnk, new Translation() { Value = new float3(request.cnkCoord.x * Settings.ChunkSpacingX, 0.0f, request.cnkCoord.z * Settings.ChunkSpacingZ) });
                    EntityManager.SetComponentData<Chunk>(newCnk, new Chunk()
                    {
                        coord = request.cnkCoord
                    });
                }

                terraformObjs.Dispose();
                entities.Dispose();
            }
        }
    }
}
