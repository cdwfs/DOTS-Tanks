﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Jobs;
using UnityEngine;
using System;
using Unity.Collections;
using System.Runtime.InteropServices;
using Unity.Transforms;
using Unity.Mathematics;
using Unity.Rendering;
using Unity.Physics;
using Unity.Physics.Authoring;
using Terraform.Component;

namespace Terraform
{
    /// <summary>
    /// system that creates render representation of a terra obj chunk. 
    /// </summary>
    public class ChunkCollisionCullSystem : ComponentSystem
    {
        protected override void OnUpdate()
        {
            Entities.WithAll<Chunk, CullChunkCollision>().ForEach((Entity e, DynamicBuffer<Child> children) =>
            {
                PostUpdateCommands.RemoveComponent<CullChunkCollision>(e);

                for (int i = 0; i < children.Length; ++i)
                {
                    if (EntityManager.HasComponent<PhysicsCollider>(children[i].Value))
                    {
                        PostUpdateCommands.DestroyEntity(children[i].Value);
                    }
                }
            });
        }
    }
}