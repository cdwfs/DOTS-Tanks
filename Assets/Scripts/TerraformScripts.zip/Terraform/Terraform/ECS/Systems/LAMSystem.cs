﻿using Unity.Entities;

namespace Terraform.LAM
{
    public class UpdateSystem : ComponentSystem
    {
        protected override void OnUpdate()
        {
            Manager.Instance.UpdateLAMs(Entities);
        }
    }
}
