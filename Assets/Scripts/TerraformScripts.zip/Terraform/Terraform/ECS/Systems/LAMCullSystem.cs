﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
using Unity.Transforms;
using Terraform.Component;

namespace Terraform.LAM
{
    /// <summary>
    /// uses the LAM priority queue cull container to get the chunks that need culling. 
    /// </summary>
    [UpdateBefore(typeof(Jobs.JobFactory))] // needs to update BEFORE job factory. if this runs after job factory then generations can occur after a cull has been performed. 
    public class CullSystem : ComponentSystem
    {
        protected override void OnUpdate()
        {
            const int MaxCullPerFrame = 5;

            for (int i = 0; i < MaxCullPerFrame; ++i)
            {
                if (PriorityQueue.Instance.cullQueueCount == 0)
                {
                    return;
                }

                Cell cell = PriorityQueue.Instance.PeekCullQueue();

                if (cell.chunk.HasActiveJobs())
                {
                    return;
                }

                if (cell.chunk.physicsEntity != Entity.Null &&
                    !EntityManager.HasComponent<ChildPhysics>(cell.chunk.physicsEntity))
                {
	                return;
                }
                
                if (cell.chunk.renderEntity != Entity.Null &&
                    !EntityManager.HasComponent<ChildRender>(cell.chunk.renderEntity))
                {
	                return;
                }

                if (cell.chunk.physicsEntity != Entity.Null)
                {
	                Debug.Assert(EntityManager.Exists(cell.chunk.physicsEntity), "Entity doesn't exist");
                    
                    DynamicBuffer<ChildPhysics> children = EntityManager.GetBuffer<ChildPhysics>(cell.chunk.physicsEntity);

                    Debug.Assert(children.Length == Settings.ChunkWidth * Settings.ChunkDepth, "wrong number physics");
                    for (int c = 0; c < children.Length; ++c)
                    {
                        Debug.Assert(EntityManager.Exists(children[c].Value), "Entity doesn't exist");
                        PostUpdateCommands.DestroyEntity(children[c].Value);
                    }

                    children.Clear();
                    PostUpdateCommands.DestroyEntity(cell.chunk.physicsEntity);
                    cell.chunk.physicsEntity = Entity.Null;
                }
                
                if (cell.chunk.renderEntity != Entity.Null)
                {
	                Debug.Assert(EntityManager.Exists(cell.chunk.renderEntity), "Entity doesn't exist");
	      
	                DynamicBuffer<ChildRender> children = EntityManager.GetBuffer<ChildRender>(cell.chunk.renderEntity);

                    Debug.Assert(children.Length == Settings.ChunkWidth * Settings.ChunkDepth, "wrong number ");
                    for (int c = 0; c < children.Length; ++c)
                    {
                        Debug.Assert(EntityManager.Exists(children[c].Value), "Entity doesn't exist");
                        PostUpdateCommands.DestroyEntity(children[c].Value);
                    }

                    children.Clear();
                    PostUpdateCommands.DestroyEntity(cell.chunk.renderEntity);
                    cell.chunk.renderEntity = Entity.Null;
                }
                
                PriorityQueue.Instance.PopCullQueue();
            }
        }
    }
}
