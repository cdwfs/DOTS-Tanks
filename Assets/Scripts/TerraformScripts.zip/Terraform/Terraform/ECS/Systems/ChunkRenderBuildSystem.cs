﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Jobs;
using UnityEngine;
using System;
using Unity.Collections;
using System.Runtime.InteropServices;
using Unity.Transforms;
using Terraform.Jobs;
using Unity.Mathematics;
using Unity.Rendering;
using Unity.Physics;
using Unity.Physics.Authoring;

namespace Terraform
{
    /// <summary>
    /// system that creates render representation of a terra obj chunk. 
    /// </summary>
    public class ChunkRenderBuildSystem : JobComponentSystem
    {
        /// <summary>
        /// archetype for the link data render used in the job GenerateChunkRender.
        /// </summary>
        public static class LinkRenderArchetype
        {
            public static readonly ComponentType[] components = new ComponentType[]
            {
	            //typeof(Parent),
                //typeof(LocalToParent),
                typeof(LocalToWorld),
                typeof(Translation),
                typeof(Rotation),
                typeof(NonUniformScale),
                typeof(RenderMesh)
            };

            public static readonly EntityArchetype archetype = World.Active.EntityManager.CreateArchetype(components);
        }
        
        protected override JobHandle OnUpdate(JobHandle inputDeps)
        {
            //// create query for chunk entities with a GenChunkRender component.
            //EntityQuery query = EntityManager.CreateEntityQuery(new ComponentType[] { typeof(Chunk), typeof(GenChunkRender), typeof(Parent) });

            //if (query.CalculateLength() == 0)
            //{
            //    return inputDeps;
            //}

            //EntityCommandBufferSystem ecbSystem = World.Active.GetOrCreateSystem<EntityCommandBufferSystem>();

            //NativeArray<Parent> parents = query.ToComponentDataArray<Parent>(Allocator.TempJob);
            //NativeArray<Chunk> chunks = query.ToComponentDataArray<Chunk>(Allocator.TempJob);
            //NativeArray<Entity> cnkEntities = query.ToEntityArray(Allocator.TempJob);

            JobHandle lastHndl = inputDeps;

            //// loop through all gen requests and create a job for it.
            //for (int i = 0; i < parents.Length; ++i)
            //{
            //    TerraformObj terraObj = EntityManager.GetComponentData<TerraformObj>(parents[i].Value);

            //    TerraformObjData tData;
            //    TerraformObjDataManager.Instance.GetTerraObjData(terraObj.tParams.id, out tData);

            //    ChunkData cnkData;
            //    tData.GetChunkData(chunks[i].coord, out cnkData);

            //    GenerateChunkRenderJob job = new GenerateChunkRenderJob()
            //    {
            //        buffer = World.Active.GetOrCreateSystem<EntityCommandBufferSystem>().CreateCommandBuffer().ToConcurrent(),
            //        linkRenderArch = LinkRenderArchetype.archetype,
            //        towerData = cnkData.grid.towers,
            //        cnkEntity = cnkEntities[i]
            //    };

            //    JobHandle hndl = job.Schedule(lastHndl);
            //    lastHndl = hndl;
            //    ecbSystem.AddJobHandleForProducer(hndl);

            //    EntityManager.RemoveComponent<GenChunkRender>(cnkEntities[i]);
            //}


            //parents.Dispose();
            //chunks.Dispose();
            //cnkEntities.Dispose();

            return lastHndl;
        }
    }
}