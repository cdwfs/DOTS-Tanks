﻿using Terraform;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Rendering;
using Unity.Transforms;
using UnityEngine;

public class TerraformBootStrapTest : MonoBehaviour
{
	public static class testArchetype
    {
        public static readonly ComponentType[] components = new ComponentType[]
        {
         typeof(LocalToWorld),
         typeof(Translation),
         typeof(Rotation),
         typeof(PhysicsCollider),
         //typeof(PhysicsStep),
         //typeof(PhysicsVelocity),
         typeof(RenderMesh)
        };

        public static readonly EntityArchetype archetype = World.Active.EntityManager.CreateArchetype(components);
    }

    public UnityEngine.Mesh linkMesh;
    public UnityEngine.Material linkMat;

    public static UnityEngine.Mesh sLinkMesh;
    public static UnityEngine.Material sLinkMat;
    
    void Start()
    {
        // so i can statically reference these when creating link render entities. 
        sLinkMesh = linkMesh;
        sLinkMat = linkMat;

        TerraformObjData tData;
        TerraformObjDataManager.Instance.CreateTerraformDataObj(new TerraformObjGenParams(10000, 10000), out tData);    // creates the terraform data
        TerraformObjCreater.Instance.Generate(new TerraformObjCreaterRequest(tData.genParams.id));                // creates a terraform entity obj that represents the terraform data.
    }
}