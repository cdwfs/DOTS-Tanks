﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
using Unity.Collections;

namespace Terraform.Component
{
    [global::System.SerializableAttribute]
    public struct LAMTracker : IComponentData
    {
        static ushort idCounter = 0;

        public ushort id;
        public int areaSize;

        public LAMTracker(int areaSize)
        {
            this.id = ++idCounter;
            this.areaSize = areaSize;
        }
    }
}
