﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
using Unity.Collections;

namespace Terraform.Component
{
    public struct Chunk : IComponentData
    {
        public ChunkCoord coord;
    }
}