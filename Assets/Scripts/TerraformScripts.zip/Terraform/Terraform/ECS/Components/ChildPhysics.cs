﻿using Unity.Entities;

namespace Terraform.Component
{
    [InternalBufferCapacity(Settings.TowersPerChunk)]
    public struct ChildPhysics : IBufferElementData
    {
        public Entity Value;
    }
}
