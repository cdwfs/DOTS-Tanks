﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;

namespace Terraform.Component
{
    public class LAMTrackerProxy : ComponentDataProxy<LAMTracker>
    {
    }
}