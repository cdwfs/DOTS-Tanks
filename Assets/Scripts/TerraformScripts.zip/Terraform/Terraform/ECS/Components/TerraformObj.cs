﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;

namespace Terraform.Component
{
    public struct TerraformObj : IComponentData
    {
        public readonly TerraformObjGenParams tParams;

        public TerraformObj(TerraformObjGenParams tParams)
        {
            this.tParams = tParams;
        }
    }
}