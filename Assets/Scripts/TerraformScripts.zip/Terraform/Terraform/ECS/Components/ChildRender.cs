﻿using Unity.Entities;

namespace Terraform.Component
{
    [InternalBufferCapacity(Settings.TowersPerChunk)]
    public struct ChildRender : IBufferElementData
    {
        public Entity Value;
    }
}
