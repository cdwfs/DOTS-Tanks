using Terraform;
using Terraform.Component;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Plugins.PlayerInput;

public class TanksTerraformSystem : ComponentSystem
{
    public int GenerationRadius = 3;
    
    private Entity player1Entity;
    private Entity player2Entity;

    public EntityQuery playersQuery;

    protected override void OnCreate()
    {
        // Query
        World.GetOrCreateSystem<GameManagerSystem>();
        playersQuery = GetEntityQuery(new EntityQueryDesc
        {
            All = new[] { ComponentType.ReadOnly<TankPlayer>() }
        });
    }
    
    protected override void OnUpdate()
    {
        if (player1Entity == Entity.Null || player2Entity == Entity.Null)
        {
            int playerCount = playersQuery.CalculateLength();
            
            if (playerCount > 0)
            {
                var players = playersQuery.ToEntityArray(Allocator.Persistent);
                ComponentDataFromEntity<TankPlayer> tankPlayers = GetComponentDataFromEntity<TankPlayer>();
                for (int i = 0; i < players.Length; i++)
                {
                    TankPlayer tankPlayer = tankPlayers[players[i]];
                    if (tankPlayer.PlayerId == 0)
                    {
                        player1Entity = players[i];
                    }
                    else if(tankPlayer.PlayerId == 1)
                    {
                        player2Entity = players[i];
                    }
                    
                    PostUpdateCommands.AddComponent(players[i], new LAMTracker
                    {
                        areaSize = GenerationRadius,
                        id = (ushort)i
                    });
//                    EntityManager.AddComponentData(players[i], new LAMTracker
//                    {
//                        areaSize = GenerationRadius
//                    });

//                    TerraformObjGenParams genparams = new TerraformObjGenParams(50000, 50000);
//                    EntityManager.AddComponentData(players[i], new TerraformObj(genparams));
                    
                    
                }
                players.Dispose();
            }

            if (playerCount == 0)
            {
                return; // no players spawned yet
            }
        }
    }
}
